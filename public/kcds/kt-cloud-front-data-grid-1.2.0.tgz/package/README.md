# @kt-cloud-front/data-grid

TanStack Table 기반 데이터 그리드(SGrid) 컴포넌트 패키지입니다.

## 개요

`@kt-cloud-front/data-grid`는 **KCDS 디자인 시스템에 맞춰 완성된 데이터 그리드**를 제공합니다.
헤드리스 로직을 담은 Core 레이어와, 툴바·페이지네이션까지 조합한 UX 레이어로 나뉩니다.

- **Core (`/core`)** — `SGridCore` + 플러그인(정렬, 페이지네이션, 행 선택, 칼럼 필터, 칼럼 고정, 리사이즈, 행 확장, 가상 스크롤, 무한 스크롤, sticky 헤더)
- **UX (`/grid`)** — `SGrid`(툴바 + 그리드 + 페이지네이션 조합), `SGridToolbar`, 빈/에러 상태, 엑셀(CSV) 다운로드

## 설치

```bash
pnpm add @kt-cloud-front/data-grid
```

peerDependencies를 함께 설치해야 합니다.

```bash
pnpm add @kt-cloud-front/ui-react @tanstack/react-table @tanstack/react-virtual react react-dom
```

## Tailwind 설정

그리드 컴포넌트는 KCDS 토큰 기반 Tailwind 클래스를 사용합니다.
빌드 시 클래스가 제거되지 않도록 전역 CSS에 패키지 경로를 `@source`로 등록하세요.

```css
@import 'tailwindcss';
@import '@kt-cloud-front/ui-style/tailwind';
@import '@kt-cloud-front/ui-style-react';

@source "../../node_modules/@kt-cloud-front/ui-react/dist/**/*.{js,cjs}";
@source "../../node_modules/@kt-cloud-front/data-grid/dist/**/*.{js,cjs}";
```

> **⚠️ `@source` 경로는 이 CSS 파일이 위치한 디렉토리 기준 상대경로입니다.**
> 위 예시는 `app/globals.css`(Next.js App Router)처럼 `node_modules`가 2단계 위에 있는 구조를 가정합니다.
> 프로젝트 소스 트리에 맞게 단계 수를 조정하세요. 경로가 어긋나면 클래스가 조용히 누락되어 컴포넌트 레이아웃이 깨집니다(콘솔 에러 없음).

## 사용법

### SGrid — 툴바·페이지네이션까지 한 번에

```tsx
import { SGrid } from '@kt-cloud-front/data-grid/grid'
import type { SGridColumn } from '@kt-cloud-front/data-grid/core'

interface Server {
  id: string
  name: string
  status: string
}

const columns: SGridColumn<Server>[] = [
  { accessorKey: 'name', header: '이름' },
  { accessorKey: 'status', header: '상태' },
]

function ServerList({ servers, onReload }: { servers: Server[]; onReload: () => void }) {
  return (
    <SGrid data={servers} columns={columns} getRowId={(row) => row.id} toolbar={{ onReload }} />
  )
}
```

검색 키워드 상태는 `SGrid`가 내부에서 관리하며, `sorting`·`pagination`을 생략하면 client 모드 20행이 기본값입니다.

### SGridCore — 직접 조립

레이아웃을 직접 제어하거나 가상/무한 스크롤을 다뤄야 할 때 사용합니다.

```tsx
import { SGridCore, useGridPagination } from '@kt-cloud-front/data-grid/core'
import { SGridToolbar } from '@kt-cloud-front/data-grid/grid'

function ServerList({ servers }: { servers: Server[] }) {
  const { pagination, onPaginationChange } = useGridPagination()
  const [keyword, setKeyword] = useState('')

  return (
    <>
      <SGridToolbar enableSearch searchValue={keyword} onSearchChange={setKeyword} />
      <SGridCore
        data={servers}
        columns={columns}
        getRowId={(row) => row.id}
        pagination={{ mode: 'client', pagination, onPaginationChange }}
      />
    </>
  )
}
```

## SGrid vs SGridCore

| | `SGrid` | `SGridCore` |
| :--- | :--- | :--- |
| 툴바 / 페이지네이션 UI | 자동 포함 | 직접 배치 |
| 검색 keyword 상태 | 내부 관리 | 직접 관리 |
| sorting / pagination | client 기본값 | 외부 관리 필수 |
| 레이아웃 자유도 | 제한적 | 완전 자유 |

표준 목록 화면은 `SGrid`로 시작하고, UX 요구가 맞지 않을 때 `SGridCore`로 내려갑니다.

## 라이선스

UNLICENSED — kt cloud 내부 및 승인된 프로젝트 전용입니다.
