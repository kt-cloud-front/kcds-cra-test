# @kt-cloud-front/data-grid

## 1.2.0

### Minor Changes

- **마이너 릴리즈**: 디자인 시스템 1.2.0 버전 업데이트

  #### ✨ 신규 기능
  - **칼럼 필터 서버 모드**: 필터 조건을 서버 조회에 넘길 수 있음
    - ([6a6bccf89](https://github.com/kt-cloud-platform/front/commit/6a6bccf89085b3680825fba81110f121053e49fe)) @nspark
  - **칼럼 정렬 `meta.align`**: `left`(기본)·`center`·`right` 로 헤더 라벨과 셀 콘텐츠의 가로 정렬을 함께 지정
    - ([bf3b5f8a4](https://github.com/kt-cloud-platform/front/commit/bf3b5f8a4a2fa838d2150b66610b361b36db976e)) @dhoh-ktc
  - **`defineColumn`**: 칼럼 정의에서 행·셀 값 타입을 추론
    - ([24d12fe6f](https://github.com/kt-cloud-platform/front/commit/24d12fe6f572c98d916ecaf88d69ddebe2aba689), [5c0d4c7e2](https://github.com/kt-cloud-platform/front/commit/5c0d4c7e2b33666a2e2d82379eb6e3cb54ad49f1)) @dhoh-ktc

  #### 🐛 버그 수정
  - 막대·툴바가 넘칠 때 잘리던 문제와 세로 스크롤이 사라지던 문제 수정, 페이지네이션을 표 바로 아래에 배치
    - ([125a225b2](https://github.com/kt-cloud-platform/front/commit/125a225b2e6a72bd4e2a7f572f55f40beef0a619), [792b5545b](https://github.com/kt-cloud-platform/front/commit/792b5545b6f151b275dfc8a96d38eb11d29a3499), [1494afcfd](https://github.com/kt-cloud-platform/front/commit/1494afcfd458628f1a72d461ac0953993963ee18)) @dhoh-ktc

- Updated dependencies
  - @kt-cloud-front/ui-react@1.2.0

## 1.0.8

### Patch Changes

- **최초 외부 배포**: 그동안 모노레포 내부 전용(`@repo/kcds-grid`)이던 SGrid 데이터 그리드를 `@kt-cloud-front/data-grid` 로 GitHub Packages 에 배포합니다.

  #### 📦 배포 스펙
  - 엔트리 2종 — `@kt-cloud-front/data-grid/core`(헤드리스 코어 + 플러그인), `@kt-cloud-front/data-grid/grid`(툴바·페이지네이션 조합 UX)
  - ESM 전용, `'use client'` 배너 포함
  - peerDependencies — `@kt-cloud-front/ui-react`, `@tanstack/react-table`, `@tanstack/react-virtual`, `react`, `react-dom`
  - Tailwind 클래스 보존을 위해 소비자 CSS 에 `@source "./node_modules/@kt-cloud-front/data-grid/dist/**/*.js";` 등록 필요 (README 참고)

  #### 🔧 내부 정비
  - `@repo/utils` 의존 제거 — 엑셀(CSV) 다운로드 헬퍼를 패키지 내부로 인라인. 파일명·인코딩(UTF-8 BOM) 동작은 동일합니다.
  - 배포본에 내부 alias 가 새지 않도록 `postbuild` 누출 가드 추가 — `dist` 에 `#kcds`·`@repo/*` 가 남으면 빌드가 실패합니다.

  모노레포 내부 소비 경로(`@repo/kcds-grid/core`, `@repo/kcds-grid/grid`)와 API 는 변경되지 않았습니다.
