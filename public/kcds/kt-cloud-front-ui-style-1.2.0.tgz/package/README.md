# @kt-cloud-front/ui-style

디자인 시스템의 스타일 토큰과 테마를 관리하는 패키지입니다.

## 🎯 주요 특징

- **하이브리드 레이어링**: 모드(light/dark)와 테마(default/magenta)를 분리하여 관리
- **런타임 테마 전환**: `data-mode`와 `data-theme` 속성을 통한 실시간 전환
- **다양한 출력 형식**: CSS, SCSS, Tailwind v4 지원
- **자동 빌드**: 통합 빌드 시스템을 통한 토큰 자동 변환
- **직관적인 구조**: `/css`, `/scss`, `/tailwind`로 명확하게 구분
- **모듈화**: 필요한 부분만 선택적으로 import 가능
- **DTCG 호환**: Design Tokens Community Group 표준 준수

## 📁 프로젝트 구조

### **개발자 관점 (빌드 전)**

```
packages/ui-style/
├── src/
│   ├── configs/                    # 빌드 설정 파일들
│   │   ├── build-tokens.js         # 통합 토큰 빌드 스크립트
│   │   ├── build-frameworks.js     # 프레임워크 빌드 스크립트
│   │   ├── build-utilities.js      # 유틸리티 클래스 빌드 스크립트
│   │   ├── builders/               # 빌더 모듈
│   │   │   ├── css-builder.js      # CSS 토큰 빌더
│   │   │   ├── scss-builder.js     # SCSS 토큰 빌더
│   │   │   ├── tailwind-builder.js # Tailwind 토큰 빌더
│   │   │   └── utilities/          # 유틸리티 클래스 빌더
│   │   │       ├── typography-builder.js  # Typography 클래스 생성
│   │   │       └── effects-builder.js     # Effects 클래스 생성
│   │   └── formats/                # 프레임워크 템플릿/포맷
│   │       ├── common/             # 공통 리소스
│   │       │   └── fonts.css      # 공통 폰트 설정
│   │       ├── css/                # CSS 프레임워크 템플릿
│   │       │   ├── index.css      # CSS 진입점
│   │       │   ├── variables.css  # 토큰 및 추가 변수
│   │       │   ├── fonts.css      # 폰트 설정
│   │       │   ├── base.css       # reset, typography 기본
│   │       │   └── utilities.css  # 커스텀 유틸리티 클래스
│   │       ├── scss/               # SCSS 프레임워크 템플릿
│   │       │   ├── index.scss     # SCSS 진입점
│   │       │   ├── _variables.scss # 토큰 매핑/추가 변수
│   │       │   ├── _mixins.scss   # 재사용 함수
│   │       │   ├── _fonts.scss    # 폰트 설정
│   │       │   └── _base.scss     # reset, typography 기본
│   │       └── tailwind/           # Tailwind v4 프레임워크 템플릿
│   │           ├── index.css      # 빌드 엔트리
│   │           ├── fonts.css      # 폰트 설정
│   │           ├── base.css       # 프리플라이트 보완
│   │           └── utilities.css  # 커스텀 유틸리티
│   └── tokens/                     # 디자인 토큰 원장
│       └── tokens.json             # 통합 토큰 파일
└── package.json
```

### **사용자 관점 (빌드 후)**

```
dist/
├── css/                    # CSS 통합 프레임워크
│   ├── index.css          # 전체 CSS 프레임워크
│   ├── tokens.css         # CSS 토큰만
│   ├── modes.css          # 모드별 토큰
│   ├── themes.css         # 테마별 토큰
│   └── fonts.css          # 폰트 설정
├── scss/                   # SCSS 통합 프레임워크
│   ├── index.scss         # 전체 SCSS 프레임워크
│   ├── tokens.scss        # SCSS 토큰만
│   ├── _modes.scss        # 모드별 토큰
│   ├── _themes.scss       # 테마별 토큰
│   └── fonts.scss         # 폰트 설정
├── tailwind/               # Tailwind 통합 프레임워크
│   ├── index.css          # 전체 Tailwind 프레임워크
│   ├── tokens.css         # Tailwind 토큰만
│   ├── modes.css          # 모드별 토큰
│   ├── themes.css         # 테마별 토큰
│   └── fonts.css          # 폰트 설정
├── meta/                   # 메타데이터
│   ├── config.json        # 빌드 설정 정보
│   ├── modes.json         # 지원 모드 정보
│   └── themes.json        # 지원 테마 정보
└── common/                 # 공통 리소스
    └── fonts.css          # 공통 폰트 설정
```

## 📦 패키지 Exports

### **CSS 프레임워크**

```css
/* 전체 CSS 프레임워크 */
@import '@kt-cloud-front/ui-style/css';

/* CSS 개별 모듈 */
@import '@kt-cloud-front/ui-style/css/base'; /* 기본 스타일 */
@import '@kt-cloud-front/ui-style/css/fonts'; /* 폰트 */
@import '@kt-cloud-front/ui-style/css/utilities'; /* 유틸리티 */
@import '@kt-cloud-front/ui-style/css/variables'; /* 추가 변수 */
@import '@kt-cloud-front/ui-style/css/tokens'; /* CSS 토큰만 (modes + themes) */
@import '@kt-cloud-front/ui-style/css/modes'; /* 모드별 토큰 */
@import '@kt-cloud-front/ui-style/css/themes'; /* 테마별 토큰 */
@import '@kt-cloud-front/ui-style/fonts'; /* 폰트 */
```

### **SCSS 프레임워크**

```scss
/* 전체 SCSS 프레임워크 (modes + themes) */
@use '@kt-cloud-front/ui-style/scss' as *;

/* SCSS 개별 모듈 */
@import '@kt-cloud-front/ui-style/scss/base'; /* 기본 스타일 */
@import '@kt-cloud-front/ui-style/scss/mixins'; /* 믹스인 */
@import '@kt-cloud-front/ui-style/scss/variables'; /* 추가 변수 */
@import '@kt-cloud-front/ui-style/scss/fonts'; /* 폰트 */
@use '@kt-cloud-front/ui-style/scss/tokens' as *; /* SCSS 토큰만 (modes + themes) */
@use '@kt-cloud-front/ui-style/scss/modes' as *; /* 모드별 토큰 */
@use '@kt-cloud-front/ui-style/scss/themes' as *; /* 테마별 토큰 */
@use '@kt-cloud-front/ui-style/fonts' as *; /* 폰트 */
```

### **Tailwind 프레임워크**

```css
/* 전체 Tailwind 프레임워크 */
@import '@kt-cloud-front/ui-style/tailwind';

/* Tailwind 개별 모듈 */
@import '@kt-cloud-front/ui-style/tailwind/base'; /* 기본 스타일 */
@import '@kt-cloud-front/ui-style/tailwind/fonts'; /* 폰트 */
@import '@kt-cloud-front/ui-style/tailwind/utilities'; /* 커스텀 유틸리티 */
@import '@kt-cloud-front/ui-style/tailwind/tokens'; /* Tailwind 토큰만 */
@import '@kt-cloud-front/ui-style/tailwind/modes'; /* 모드별 토큰 */
@import '@kt-cloud-front/ui-style/tailwind/themes'; /* 테마별 토큰 */
@import '@kt-cloud-front/ui-style/fonts'; /* 폰트 */
```

### **공통 리소스**

```css
/* 폰트 */
@import '@kt-cloud-front/ui-style/fonts';
```

## 🎨 Figma Integration

모든 디자인 토큰은 Figma에서 자동으로 추출되어 동기화됩니다.

### 토큰 동기화

```bash
# Figma 컴포넌트 정보 업데이트 (증분 업데이트)
pnpm figma:components

# 아이콘 자동 추출 (증분 업데이트)
pnpm figma:icons

# 일러스트레이션 자동 추출 (증분 업데이트)
pnpm figma:illusts
```

### 특징

- ✅ **boundVariables → CSS 변수 자동 매핑** - Figma 변수를 KCDS 토큰으로 자동 변환
- ✅ **증분 업데이트** - 변경된 에셋만 다운로드하여 API 호출 최소화
- ✅ **Prefix 자동 제거** - `icon-home` → `home.svg`, `illust-success` → `success.svg`
- ✅ **중복 감지** - Prefix 제거 후 중복되는 이름 자동 필터링

### Assets 저장 위치

```
src/assets/
├── icons/              # 아이콘 SVG 파일
│   ├── home.svg
│   ├── settings.svg
│   └── index.ts       # 아이콘 목록
├── illustrations/      # 일러스트레이션 SVG 파일
│   ├── success.svg
│   ├── error.svg
│   └── index.ts       # 일러스트 목록
└── meta/              # 메타데이터 (증분 업데이트용)
    ├── figma-icons.json
    └── figma-illustrations.json
```

## 🔧 빌드 및 개발

### **개발 워크플로우**

1. **Figma 동기화**: `pnpm figma:components` (필요 시)
2. **빌드 실행**: `pnpm build` 명령어로 빌드
3. **결과 확인**: `dist/` 폴더에서 빌드된 결과물 확인

### **빌드 명령어**

```bash
# 전체 빌드 (토큰 + 유틸리티 + 프레임워크 + 에셋)
pnpm build

# 개별 빌드
pnpm tokens        # 토큰 변환 (CSS, SCSS, Tailwind)
pnpm utilities     # 유틸리티 클래스 생성 (Typography, Effects, Helpers)
pnpm frameworks    # 프레임워크 파일 생성 (CSS, SCSS, Tailwind)
pnpm assets        # 에셋 복사 (아이콘, 폰트, 로고)

# 빌드 결과물 정리
pnpm clean
```

## 🎨 유틸리티 클래스 시스템

디자인 토큰에서 자동 생성되는 유틸리티 CSS 클래스를 제공합니다.

### **생성되는 클래스 (44개)**

| 카테고리       | 클래스 수 | 예시                                                                                                                       |
| -------------- | --------- | -------------------------------------------------------------------------------------------------------------------------- |
| **Typography** | 38개      | `.kcds-heading-xl`, `.kcds-paragraph-md-regular`, `.kcds-label-sm-bold`, `.kcds-code-lg-regular`                           |
| **Effects**    | 6개       | `.kcds-shadow-sm/md/lg`, `.kcds-focus-ring-sm/md`, `.kcds-blur-background`                                                 |
| **Helpers**    | 다수      | `.kcds-transition`, `.kcds-focus`, `.kcds-disabled`, `.kcds-truncate-*`, `.kcds-scrollbar`, `.kcds-glass`, `.kcds-sr-only` |

### **빌드 파이프라인**

```
tokens.json
    │
    ├─► typography-builder.js ─► fonts.css (Typography 클래스)
    │
    ├─► effects-builder.js ───► utilities.css (Effects 클래스)
    │
    └─► helpers.css (수동 작성) ─┘
```

### **사용 예시**

```tsx
// Typography
<h1 className="kcds-heading-xl">제목</h1>
<p className="kcds-paragraph-md-regular">본문</p>

// Effects
<div className="kcds-shadow-md">그림자</div>

// Helpers
<button className="kcds-transition kcds-hover-scale">버튼</button>
```

> 📚 상세 문서: [유틸리티 클래스 빌드 시스템](../../docs/project/utility-classes.md)

## 🎨 하이브리드 레이어링 시스템

### **모드와 테마 분리**

이 패키지는 모드(light/dark)와 테마(default/magenta)를 분리하여 관리합니다:

- **모드 (Mode)**: 라이트/다크 모드 전환
- **테마 (Theme)**: 테마 전환
- **하이브리드**: 모드와 테마를 독립적으로 조합 가능

### **런타임 전환**

```javascript
// 모드 전환
document.documentElement.setAttribute('data-mode', 'dark')

// 테마 전환
document.documentElement.setAttribute('data-theme', 'magenta')

// 조합 사용
document.documentElement.setAttribute('data-mode', 'light')
document.documentElement.setAttribute('data-theme', 'magenta')
```

### **파일 구조**

```
dist/css/
├── modes.css      # :root[data-mode="light"], :root[data-mode="dark"]
├── themes.css     # :root[data-theme="default"], :root[data-theme="magenta"]
└── tokens.css     # modes.css + themes.css 통합
```

## 📋 프로젝트 구조 개요

### **소스 코드 구조**

- **`src/tokens/`**: 디자인 토큰 원장 (tokens.json)
- **`src/configs/`**: 빌드 설정 및 빌더 스크립트
  - **`builders/`**: 프레임워크별 토큰 빌더
  - **`formats/`**: 프레임워크 템플릿/포맷 정의
- **`src/assets/`**: 폰트 등 정적 리소스

### **빌드 결과물 구조**

- **`dist/css/`**: CSS 프레임워크 및 토큰 (modes, themes, tokens)
- **`dist/scss/`**: SCSS 프레임워크 및 토큰 (modes, themes, tokens)
- **`dist/tailwind/`**: Tailwind CSS 프레임워크 및 토큰 (modes, themes, tokens)
- **`dist/meta/`**: 메타데이터 (config, modes, themes)
- **`dist/common/`**: 공통 리소스 (폰트 등)

### **패키지 구조**

- **`package.json`**: 패키지 메타데이터 및 스크립트
- **`exports`**: 외부에서 접근 가능한 파일 경로 정의

## 🌍 환경 요구사항

- **Node.js**: `>=20` (Volta 고정: 24.21.0)
- **pnpm**: `>=10.9.0`
- **Tailwind CSS**: `^4.0.0` (Tailwind 프레임워크 사용 시)

## 📚 문서 및 참조

- **전체 프로젝트 가이드**: [`AGENTS.md`](../../AGENTS.md)
- **Figma 통합**: [apps/kcds/AGENTS.md](../../apps/kcds/AGENTS.md)
- **개발 정책**: [`.claude/policies/`](../../.claude/policies/)

## 🔗 관련 패키지

- [`@kt-cloud-front/ui-style-react`](../ui-style-react/README.md) - Tailwind CSS v4 컴포넌트 스타일 (44개)
- [`@kt-cloud-front/ui-react`](../ui-react/README.md) - 완제품 컴포넌트
- [`@kt-cloud-front/ui-core-react`](../ui-core-react/README.md) - Headless UI

---

**Version**: 1.0.0  
**Last Updated**: 2026-01-07
