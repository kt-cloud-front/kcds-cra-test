// 이미지 목록 export
// PNG/JPG 등 이미지 파일들은 build-images.js 스크립트를 통해 CSS 변수로 변환됩니다

// 전체 이미지 목록
export const allImages = ['transparent-pattern', 'transparent-background'] as const

// 이미지 타입
export type ImageName = (typeof allImages)[number]
