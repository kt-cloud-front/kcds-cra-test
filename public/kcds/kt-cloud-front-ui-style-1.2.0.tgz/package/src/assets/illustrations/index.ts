// 일러스트레이션 목록만 export
// SVG 파일들은 build-illustrations.js 스크립트를 통해 CSS 변수로 변환됩니다

// 전체 일러스트레이션 목록
export const allIllustrations = [
  'input-required',
  'no-connection',
  'no-data',
  'no-search-result'
]
