#!/usr/bin/env node

/**
 * 일러스트레이션 정리 스크립트
 * ui-style/src/assets/illustrations 디렉토리의 SVG 파일들을 정리
 */

const fs = require('fs').promises
const path = require('path')

const ILLUSTRATIONS_DIR = path.join(__dirname, '..', 'assets', 'illustrations')
const META_FILE = path.join(__dirname, '..', 'assets', 'meta', 'figma-illustrations.json')

// 일러스트레이션 정리 함수
async function cleanIllustrations() {
  try {
    console.log('🧹 일러스트레이션 정리를 시작합니다...\n')

    let totalRemoved = 0

    // illustrations 디렉토리 존재 확인
    try {
      await fs.access(ILLUSTRATIONS_DIR)
    } catch (error) {
      console.log('❌ illustrations 디렉토리가 존재하지 않습니다:', ILLUSTRATIONS_DIR)
      return
    }

    // SVG 파일들 삭제
    console.log('📂 SVG 파일들 정리 중...')
    try {
      const files = await fs.readdir(ILLUSTRATIONS_DIR)
      const svgFiles = files.filter((file) => file.endsWith('.svg'))

      if (svgFiles.length > 0) {
        console.log(`   📁 ${svgFiles.length}개의 SVG 파일 발견`)

        for (const svgFile of svgFiles) {
          const filePath = path.join(ILLUSTRATIONS_DIR, svgFile)
          await fs.unlink(filePath)
          console.log(`   🗑️  삭제됨: ${svgFile}`)
          totalRemoved++
        }
      } else {
        console.log(`   📁 SVG 파일 없음`)
      }
    } catch (error) {
      console.log(`   📁 디렉토리 읽기 실패: ${error.message}`)
    }

    // index.ts 파일 삭제
    const indexPath = path.join(ILLUSTRATIONS_DIR, 'index.ts')
    try {
      await fs.access(indexPath)
      await fs.unlink(indexPath)
      console.log(`   🗑️  삭제됨: index.ts`)
      totalRemoved++
    } catch (error) {
      console.log(`   📄 index.ts: 존재하지 않음`)
    }

    // 메타데이터 파일 삭제
    try {
      await fs.access(META_FILE)
      await fs.unlink(META_FILE)
      console.log(`   🗑️  삭제됨: meta/figma-illustrations.json`)
      totalRemoved++
    } catch (error) {
      console.log(`   📄 meta/figma-illustrations.json: 존재하지 않음`)
    }

    // 빈 illustrations 디렉토리 삭제
    try {
      const files = await fs.readdir(ILLUSTRATIONS_DIR)
      if (files.length === 0) {
        await fs.rmdir(ILLUSTRATIONS_DIR)
        console.log(`   🗑️  빈 디렉토리 삭제됨: illustrations/`)
        totalRemoved++
      }
    } catch (error) {
      // 디렉토리가 없거나 삭제할 수 없으면 무시 (중요하지 않은 작업)
      console.log(`   📁 디렉토리 삭제 실패: ${error.message}`)
    }

    console.log('\n🎉 일러스트레이션 정리가 완료되었습니다!')
    console.log(`   총 ${totalRemoved}개의 파일이 삭제되었습니다.`)
    console.log(`   위치: ${ILLUSTRATIONS_DIR}`)
  } catch (error) {
    console.error('💥 일러스트레이션 정리 중 오류가 발생했습니다:', error.message)
    process.exit(1)
  }
}

// 스크립트 실행
if (require.main === module) {
  cleanIllustrations()
}

module.exports = { cleanIllustrations }
