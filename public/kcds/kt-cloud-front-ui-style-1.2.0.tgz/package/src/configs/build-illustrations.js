#!/usr/bin/env node

/**
 * 일러스트레이션 빌드 스크립트
 * SVG 파일들을 CSS 변수로 변환하여 사용할 수 있도록 빌드
 */

const fs = require('fs').promises
const path = require('path')

const ILLUSTRATIONS_DIR = path.join(__dirname, '..', 'assets', 'illustrations')
const DIST_DIR = path.join(__dirname, '..', '..', 'dist')

// SVG를 CSS 데이터 URL로 변환하는 함수 (원본 색상 유지)
function svgToDataUrl(svgContent) {
  // SVG 내용을 정리 (원본 색상 유지)
  const cleanedSvg = svgContent
    .replace(/\s+/g, ' ') // 공백 정리
    .replace(/>\s+</g, '><') // 태그 간 공백 제거
    .trim()

  // URL 인코딩
  const encoded = encodeURIComponent(cleanedSvg)
  return `data:image/svg+xml,${encoded}`
}

// SVG를 CSS 변수로 변환하는 함수
function svgToCssVariable(svgContent, illustrationName) {
  const dataUrl = svgToDataUrl(svgContent)
  return `--illust-${illustrationName}: url("${dataUrl}");`
}

// 메인 빌드 함수
async function buildIllustrations() {
  try {
    console.log('🎨 일러스트레이션 빌드를 시작합니다...\n')

    // 일러스트레이션 인덱스 파일 읽기
    const indexPath = path.join(ILLUSTRATIONS_DIR, 'index.ts')
    const indexContent = await fs.readFile(indexPath, 'utf8')

    // allIllustrations 배열 추출
    const allIllustrationsMatch = indexContent.match(
      /export const allIllustrations = \[([\s\S]*?)\]/,
    )
    if (!allIllustrationsMatch) {
      throw new Error('allIllustrations 배열을 찾을 수 없습니다.')
    }

    const allIllustrations = allIllustrationsMatch[1]
      .split(',')
      .map((illust) => illust.trim().replace(/['"]/g, ''))
      .filter((illust) => illust)

    console.log(`📋 총 ${allIllustrations.length}개의 일러스트레이션을 처리합니다.\n`)

    // CSS 변수 생성
    console.log('📝 CSS 변수를 생성하는 중...')
    const cssVariables = []

    for (const illustration of allIllustrations) {
      const svgPath = path.join(ILLUSTRATIONS_DIR, `${illustration}.svg`)

      try {
        const svgContent = await fs.readFile(svgPath, 'utf8')
        const cssVar = svgToCssVariable(svgContent, illustration)
        cssVariables.push(cssVar)
      } catch (error) {
        console.warn(`⚠️  ${illustration}.svg를 읽을 수 없습니다: ${error.message}`)
      }
    }

    // CSS 파일 생성
    const cssContent = `/* KCDS 일러스트레이션 CSS 변수 */
:root {
${cssVariables.map((variable) => `  ${variable}`).join('\n')}
}
`

    // CSS 파일 저장
    const cssPath = path.join(DIST_DIR, 'css', 'illustrations.css')
    await fs.mkdir(path.dirname(cssPath), { recursive: true })
    await fs.writeFile(cssPath, cssContent)
    console.log('✅ CSS 파일 생성 완료: dist/css/illustrations.css')

    // Tailwind CSS 파일 생성
    const tailwindContent = `/* KCDS 일러스트레이션 Tailwind CSS 변수 */
:root {
${cssVariables.map((variable) => `  ${variable}`).join('\n')}
}
`

    // Tailwind CSS 파일 저장
    const tailwindPath = path.join(DIST_DIR, 'tailwind', 'illustrations.css')
    await fs.mkdir(path.dirname(tailwindPath), { recursive: true })
    await fs.writeFile(tailwindPath, tailwindContent)
    console.log('✅ Tailwind CSS 파일 생성 완료: dist/tailwind/illustrations.css')

    console.log('\n🎉 일러스트레이션 빌드가 완료되었습니다!')
    console.log(`   총 ${allIllustrations.length}개의 일러스트레이션이 처리되었습니다.`)
  } catch (error) {
    console.error('💥 일러스트레이션 빌드 중 오류가 발생했습니다:', error.message)
    process.exit(1)
  }
}

// 스크립트 실행
if (require.main === module) {
  buildIllustrations()
}

module.exports = { buildIllustrations }
