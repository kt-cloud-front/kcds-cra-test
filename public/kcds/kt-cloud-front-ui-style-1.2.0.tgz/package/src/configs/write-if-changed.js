/**
 * 출력 파일의 콘텐츠가 timestamp 라인을 제외하고 동일하면 write 를 스킵.
 *
 * 빌더 헤더에 박는 `생성 시간: ...` 한국어 라인과 메타 JSON 의 `generatedAt`
 * 필드는 매 빌드마다 바뀌지만 실제 산출물은 동일한 경우가 많다. 그대로 쓰면
 * git tree 가 매번 dirty 상태가 되므로, 비교 시 이 패턴들을 마스킹하고
 * 콘텐츠 동일 여부를 판단한다.
 */

const fs = require('fs')

const DEFAULT_TIMESTAMP_PATTERNS = [/생성 시간:\s*[^\n*]*/g, /"generatedAt"\s*:\s*"[^"]+"/g]

function maskTimestamps(str, patterns) {
  return patterns.reduce((acc, p) => acc.replace(p, ''), str)
}

function writeIfContentChanged(filePath, newContent, patterns = DEFAULT_TIMESTAMP_PATTERNS) {
  if (fs.existsSync(filePath)) {
    const existing = fs.readFileSync(filePath, 'utf8')
    if (maskTimestamps(existing, patterns) === maskTimestamps(newContent, patterns)) {
      return false
    }
  }
  fs.writeFileSync(filePath, newContent)
  return true
}

function copyIfContentChanged(srcPath, destPath, patterns = DEFAULT_TIMESTAMP_PATTERNS) {
  const newContent = fs.readFileSync(srcPath, 'utf8')
  return writeIfContentChanged(destPath, newContent, patterns)
}

module.exports = {
  writeIfContentChanged,
  copyIfContentChanged,
  DEFAULT_TIMESTAMP_PATTERNS,
}
