/**
 * Tokens Bruecke 익스포트 정규화
 *
 * 플러그인 익스포트 옵션에 따라 tokens.json 의 표현 방식이 달라진다.
 * 빌더들이 단일 형태(DTCG 키 + 스칼라 문자열)만 다루도록 읽는 즉시 정규화한다.
 *
 * 1. `type`/`value`/`description` → `$type`/`$value`/`$description`
 *    (익스포트 옵션 useDTCG 가 꺼진 경우)
 * 2. `{ value, unit }` → `"16px"`
 *    (DTCG 2025.10 spec 의 dimension 표현)
 */

const DTCG_PROMOTABLE_KEYS = ['type', 'value', 'description']

// { value, unit } 형태의 dimension 객체인지 판별
function isDimensionObject(node) {
  return (
    typeof node.value === 'number' &&
    typeof node.unit === 'string' &&
    Object.keys(node).length === 2
  )
}

// type + value 쌍을 가진 토큰 노드인지 판별 (composite 값 내부의 value 키와 구분)
function isNonDTCGTokenNode(node) {
  return typeof node.type === 'string' && node.value !== undefined
}

function normalizeNode(node) {
  if (Array.isArray(node)) {
    return node.map(normalizeNode)
  }

  if (node === null || typeof node !== 'object') {
    return node
  }

  if (isDimensionObject(node)) {
    return `${node.value}${node.unit}`
  }

  const promoteKeys = isNonDTCGTokenNode(node)
  const result = {}
  for (const [key, value] of Object.entries(node)) {
    const normalizedKey = promoteKeys && DTCG_PROMOTABLE_KEYS.includes(key) ? `$${key}` : key
    result[normalizedKey] = normalizeNode(value)
  }
  return result
}

/**
 * tokens.json 파싱 결과를 빌더가 기대하는 형태로 정규화한다.
 *
 * @param {Object} tokensData - JSON.parse 한 tokens.json
 * @returns {Object} 정규화된 토큰 트리
 */
function normalizeTokens(tokensData) {
  return normalizeNode(tokensData)
}

module.exports = { normalizeTokens }
