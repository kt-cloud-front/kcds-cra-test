#!/usr/bin/env node

/**
 * 이미지 빌드 스크립트
 * PNG/JPG 파일들을 CSS 변수(base64 Data URL)로 변환하여 사용할 수 있도록 빌드
 */

const fs = require('fs').promises
const path = require('path')

const IMAGES_DIR = path.join(__dirname, '..', 'assets', 'images')
const DIST_DIR = path.join(__dirname, '..', '..', 'dist')

// 이미지 확장자별 MIME 타입
const MIME_TYPES = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
}

// 이미지를 base64 Data URL로 변환하는 함수
async function imageToDataUrl(imagePath) {
  const ext = path.extname(imagePath).toLowerCase()
  const mimeType = MIME_TYPES[ext]

  if (!mimeType) {
    throw new Error(`지원하지 않는 이미지 형식입니다: ${ext}`)
  }

  const imageBuffer = await fs.readFile(imagePath)
  const base64 = imageBuffer.toString('base64')
  return `data:${mimeType};base64,${base64}`
}

// 이미지를 CSS 변수로 변환하는 함수
async function imageToCssVariable(imagePath, imageName) {
  const dataUrl = await imageToDataUrl(imagePath)
  return `--image-${imageName}: url("${dataUrl}");`
}

// 메인 빌드 함수
async function buildImages() {
  try {
    console.log('🖼️  이미지 빌드를 시작합니다...\n')

    // 이미지 인덱스 파일 읽기
    const indexPath = path.join(IMAGES_DIR, 'index.ts')
    const indexContent = await fs.readFile(indexPath, 'utf8')

    // allImages 배열 추출
    const allImagesMatch = indexContent.match(/export const allImages = \[([\s\S]*?)\]/)
    if (!allImagesMatch) {
      throw new Error('allImages 배열을 찾을 수 없습니다.')
    }

    const allImages = allImagesMatch[1]
      .split(',')
      .map((img) => img.trim().replace(/['"]/g, ''))
      .filter((img) => img)

    console.log(`📋 총 ${allImages.length}개의 이미지를 처리합니다.\n`)

    // CSS 변수 생성
    console.log('📝 CSS 변수를 생성하는 중...')
    const cssVariables = []

    for (const image of allImages) {
      // 이미지 파일 찾기 (png, jpg, jpeg, gif, webp 순으로 시도)
      let imagePath = null
      for (const ext of Object.keys(MIME_TYPES)) {
        const tryPath = path.join(IMAGES_DIR, `${image}${ext}`)
        try {
          await fs.access(tryPath)
          imagePath = tryPath
          break
        } catch (error) {
          console.debug(`${image}${ext} 파일 없음: ${error.message}`)
        }
      }

      if (!imagePath) {
        console.warn(`⚠️  ${image} 이미지 파일을 찾을 수 없습니다.`)
        continue
      }

      try {
        const cssVar = await imageToCssVariable(imagePath, image)
        cssVariables.push(cssVar)
        console.log(`   ✓ ${image}`)
      } catch (error) {
        console.warn(`⚠️  ${image} 처리 중 오류: ${error.message}`)
      }
    }

    // CSS 파일 생성
    const cssContent = `/* KCDS 이미지 CSS 변수 */
:root {
${cssVariables.map((variable) => `  ${variable}`).join('\n')}
}
`

    // CSS 파일 저장
    const cssPath = path.join(DIST_DIR, 'css', 'images.css')
    await fs.mkdir(path.dirname(cssPath), { recursive: true })
    await fs.writeFile(cssPath, cssContent)
    console.log('\n✅ CSS 파일 생성 완료: dist/css/images.css')

    // Tailwind CSS 파일 생성
    const tailwindContent = `/* KCDS 이미지 Tailwind CSS 변수 */
:root {
${cssVariables.map((variable) => `  ${variable}`).join('\n')}
}
`

    // Tailwind CSS 파일 저장
    const tailwindPath = path.join(DIST_DIR, 'tailwind', 'images.css')
    await fs.mkdir(path.dirname(tailwindPath), { recursive: true })
    await fs.writeFile(tailwindPath, tailwindContent)
    console.log('✅ Tailwind CSS 파일 생성 완료: dist/tailwind/images.css')

    // JS/TS export 파일 생성 (SImage 등에서 src prop으로 사용 가능)
    console.log('📝 JS export 파일을 생성하는 중...')
    const jsExports = []

    for (const image of allImages) {
      // 이미지 파일 찾기
      let imagePath = null
      for (const ext of Object.keys(MIME_TYPES)) {
        const tryPath = path.join(IMAGES_DIR, `${image}${ext}`)
        try {
          await fs.access(tryPath)
          imagePath = tryPath
          break
        } catch (error) {
          console.debug(`${image}${ext} 파일 없음: ${error.message}`)
        }
      }

      if (imagePath) {
        try {
          const dataUrl = await imageToDataUrl(imagePath)
          // kebab-case를 camelCase로 변환
          const camelName = image.replace(/-([a-z])/g, (_, c) => c.toUpperCase())
          jsExports.push(`export const ${camelName} = '${dataUrl}'`)
        } catch (error) {
          console.warn(`⚠️  ${image} Data URL 변환 중 오류: ${error.message}`)
        }
      }
    }

    const jsContent = `// KCDS 이미지 Data URL (자동 생성됨)
// SImage 등의 src prop에서 사용 가능
${jsExports.join('\n')}
`

    const jsPath = path.join(DIST_DIR, 'assets', 'images', 'data-urls.ts')
    await fs.mkdir(path.dirname(jsPath), { recursive: true })
    await fs.writeFile(jsPath, jsContent)
    console.log('✅ JS export 파일 생성 완료: dist/assets/images/data-urls.ts')

    console.log(`\n🎉 이미지 빌드가 완료되었습니다!`)
    console.log(`   총 ${cssVariables.length}개의 이미지가 처리되었습니다.`)
  } catch (error) {
    console.error('💥 이미지 빌드 중 오류가 발생했습니다:', error.message)
    process.exit(1)
  }
}

// 스크립트 실행
if (require.main === module) {
  buildImages()
}

module.exports = { buildImages }

