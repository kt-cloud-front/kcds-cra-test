#!/usr/bin/env node

/**
 * 아이콘 빌드 스크립트
 * SVG 파일들을 CSS/SCSS/Tailwind로 변환하여 사용할 수 있도록 빌드
 */

const fs = require('fs').promises
const path = require('path')

const ICONS_DIR = path.join(__dirname, '..', 'assets', 'icons')
const DIST_DIR = path.join(__dirname, '..', '..', 'dist')

// SVG를 CSS 데이터 URL로 변환하는 함수
function svgToDataUrl(svgContent) {
  // SVG 내용을 정리하고 인코딩
  const cleanedSvg = svgContent
    .replace(/fill="#[0-9a-fA-F]{6}"/g, 'fill="currentColor"') // 하드코딩된 fill 색상을 currentColor로 변경
    .replace(/stroke="#[0-9a-fA-F]{6}"/g, 'stroke="currentColor"') // 하드코딩된 stroke 색상을 currentColor로 변경
    .replace(/\s+/g, ' ') // 공백 정리
    .replace(/>\s+</g, '><') // 태그 간 공백 제거
    .trim()

  // URL 인코딩
  const encoded = encodeURIComponent(cleanedSvg)
  return `data:image/svg+xml,${encoded}`
}

// SVG를 CSS 변수로 변환하는 함수
function svgToCssVariable(svgContent, iconName) {
  const dataUrl = svgToDataUrl(svgContent)
  return `--icon-${iconName}: url("${dataUrl}");`
}

// 카테고리별 아이콘 CSS 생성
async function generateCategoryCSS(category, icons) {
  const cssRules = []

  for (const icon of icons) {
    const svgPath = path.join(ICONS_DIR, category, `${icon}.svg`)

    try {
      const svgContent = await fs.readFile(svgPath, 'utf8')
      const cssVar = svgToCssVariable(svgContent, icon)
      cssRules.push(`  ${cssVar}`)
    } catch (error) {
      console.warn(`⚠️  ${category}/${icon}.svg를 읽을 수 없습니다: ${error.message}`)
    }
  }

  return cssRules.join('\n')
}

// 아이콘 CSS 클래스 생성
function generateIconClasses(icons) {
  const classes = []

  for (const icon of icons) {
    classes.push(`.icon-${icon} {
  background-image: var(--icon-${icon});
  background-repeat: no-repeat;
  background-position: center;
  background-size: contain;
  width: 24px;
  height: 24px;
  display: inline-block;
}`)
  }

  return classes.join('\n\n')
}

// Tailwind 아이콘 클래스 생성
function generateTailwindClasses(icons) {
  const classes = []

  for (const icon of icons) {
    classes.push(`.icon-${icon} {
  background-image: var(--icon-${icon});
  background-repeat: no-repeat;
  background-position: center;
  background-size: contain;
  display: inline-block;
}`)
  }

  return classes.join('\n\n')
}

// 아이콘 이름을 원래 카테고리와 매핑하는 함수
function getIconCategory(iconName) {
  const categoryMap = {
    // system 카테고리
    bell: 'system',
    'message-question-square': 'system',
    megaphone: 'system',
    'shield-check': 'system',
    'pen-to-square': 'system',
    lock: 'system',
    globe: 'system',
    check: 'system',
    link: 'system',
    'overlay-squares-check': 'system',
    star: 'system',
    'inbox-in': 'system',
    gear: 'system',
    cube: 'system',
    'magnifying-glass': 'system',
    'credit-card': 'system',
    funnel: 'system',
    wallet: 'system',
    power: 'system',
    'overlay-squares': 'system',
    'file-question': 'system',
    user: 'system',
    'trash-bin': 'system',
    pen: 'system',
    pin: 'system',
    house: 'system',
    'code-browser': 'system',
    'circle-pause': 'system',
    play: 'system',
    'circle-stop': 'system',
    consulting: 'system',

    // sign 카테고리
    plus: 'sign',
    minus: 'sign',
    x: 'sign',
    'arrow-turn-up-left': 'sign',
    'arrow-turn-up-right': 'sign',
    'arrow-up-down': 'sign',
    'arrow-left': 'sign',
    'arrow-up': 'sign',
    'arrow-right': 'sign',
    'arrow-down': 'sign',
    'arrow-down-left': 'sign',
    'arrow-up-left': 'sign',
    'arrow-up-right': 'sign',
    'arrow-down-right': 'sign',
    'narrow-arrow-left': 'sign',
    'narrow-arrow-right': 'sign',
    'narrow-arrow-down': 'sign',
    'arrow-narrow-down': 'sign',
    'arrow-narrow-left': 'sign',
    'arrow-narrow-right': 'sign',
    'arrow-narrow-up': 'sign',
    'narrow-arrow-down-left': 'sign',
    'narrow-arrow-up-left': 'sign',
    'narrow-arrow-up-right': 'sign',
    'narrow-arrow-down-right': 'sign',
    'arrow-rotate-right': 'sign',
    'arrow-up-right-from-square': 'sign',
    expand: 'sign',
    'filter-sort-asc': 'sign',
    'filter-sort-desc': 'sign',

    // arrow 카테고리
    'chevron-down': 'arrow',
    'chevron-right': 'arrow',
    'chevrons-down': 'arrow',
    'chevrons-right': 'arrow',
    'chevron-up': 'arrow',
    'vertical-symmetric-chevrons': 'arrow',
    'chevrons-up': 'arrow',
    'chevron-left': 'arrow',
    'chevrons-left': 'arrow',

    // attachment 카테고리
    'circle-info': 'attachment',
    'triangle-alert': 'attachment',
    'circle-alert': 'attachment',
    'circle-check': 'attachment',
    'circle-check-broken': 'attachment',
    'circle-question': 'attachment',

    // view 카테고리
    'grid-dots': 'view',
    ellipsis: 'view',
    'ellipsis-vertical': 'view',
    dot: 'view',
    bars: 'view',
    'layout-right': 'view',
    'layout-left': 'view',
    eye: 'view',
    'eye-off': 'view',

    // etc 카테고리
    calendar: 'etc',
    desktop: 'etc',
    excel: 'etc',
  }

  return categoryMap[iconName] || 'system' // 기본값은 system
}

// 메인 빌드 함수
async function buildIcons() {
  try {
    console.log('🎨 아이콘 빌드를 시작합니다...\n')

    // 아이콘 인덱스 파일 읽기
    const indexPath = path.join(ICONS_DIR, 'index.ts')
    const indexContent = await fs.readFile(indexPath, 'utf8')

    // allIcons 배열 추출
    const allIconsMatch = indexContent.match(/export const allIcons = \[([\s\S]*?)\]/)
    if (!allIconsMatch) {
      throw new Error('allIcons 배열을 찾을 수 없습니다.')
    }

    const allIcons = allIconsMatch[1]
      .split(',')
      .map((icon) => icon.trim().replace(/['"]/g, ''))
      .filter((icon) => icon)

    console.log(`📋 총 ${allIcons.length}개의 아이콘을 처리합니다.\n`)

    // CSS 변수 생성
    console.log('📝 CSS 변수를 생성하는 중...')
    const cssVariables = []

    for (const icon of allIcons) {
      // SVG 파일을 icons 디렉토리에서 직접 찾기
      const svgPath = path.join(ICONS_DIR, `${icon}.svg`)

      try {
        const svgContent = await fs.readFile(svgPath, 'utf8')
        const cssVar = svgToCssVariable(svgContent, icon)
        cssVariables.push(cssVar)
      } catch (error) {
        console.warn(`⚠️  ${icon}.svg를 읽을 수 없습니다: ${error.message}`)
      }
    }

    // CSS 파일 생성
    const cssContent = `/* KCDS 아이콘 CSS 변수 */
:root {
${cssVariables.map((variable) => `  ${variable}`).join('\n')}
}

/* 아이콘 클래스 */
${generateIconClasses(allIcons)}

/* 아이콘 유틸리티 클래스 */
.icon {
  background-repeat: no-repeat;
  background-position: center;
  background-size: contain;
  display: inline-block;
}

.icon-sm {
  width: 16px;
  height: 16px;
}

.icon-md {
  width: 24px;
  height: 24px;
}

.icon-lg {
  width: 32px;
  height: 32px;
}

.icon-xl {
  width: 48px;
  height: 48px;
}
`

    // CSS 파일 저장
    const cssPath = path.join(DIST_DIR, 'css', 'icons.css')
    await fs.mkdir(path.dirname(cssPath), { recursive: true })
    await fs.writeFile(cssPath, cssContent)
    console.log('✅ CSS 파일 생성 완료: dist/css/icons.css')

    // SCSS 파일 생성
    const scssContent = `// KCDS 아이콘 SCSS 변수
:root {
${cssVariables.map((variable) => `  ${variable}`).join('\n')}
}

// 아이콘 믹스인
@mixin icon($name, $size: 24px) {
  background-image: var(--icon-#{$name});
  background-repeat: no-repeat;
  background-position: center;
  background-size: contain;
  width: $size;
  height: $size;
  display: inline-block;
}

// 아이콘 클래스
${generateIconClasses(allIcons)}

// 아이콘 유틸리티 클래스
.icon {
  background-repeat: no-repeat;
  background-position: center;
  background-size: contain;
  display: inline-block;
}

.icon-sm {
  width: 16px;
  height: 16px;
}

.icon-md {
  width: 24px;
  height: 24px;
}

.icon-lg {
  width: 32px;
  height: 32px;
}

.icon-xl {
  width: 48px;
  height: 48px;
}
`

    // SCSS 파일 저장
    const scssPath = path.join(DIST_DIR, 'scss', '_icons.scss')
    await fs.mkdir(path.dirname(scssPath), { recursive: true })
    await fs.writeFile(scssPath, scssContent)
    console.log('✅ SCSS 파일 생성 완료: dist/scss/_icons.scss')

    // Tailwind CSS 파일 생성
    const tailwindContent = `/* KCDS 아이콘 Tailwind CSS 변수 */
:root {
${cssVariables.map((variable) => `  ${variable}`).join('\n')}
}

/* 아이콘 클래스 */
${generateTailwindClasses(allIcons)}

/* 아이콘 유틸리티 클래스 */
.icon {
  background-repeat: no-repeat;
  background-position: center;
  background-size: contain;
  display: inline-block;
}

.icon-sm {
  @apply w-4 h-4;
}

.icon-md {
  @apply w-6 h-6;
}

.icon-lg {
  @apply w-8 h-8;
}

.icon-xl {
  @apply w-12 h-12;
}
`

    // Tailwind CSS 파일 저장
    const tailwindPath = path.join(DIST_DIR, 'tailwind', 'icons.css')
    await fs.mkdir(path.dirname(tailwindPath), { recursive: true })
    await fs.writeFile(tailwindPath, tailwindContent)
    console.log('✅ Tailwind CSS 파일 생성 완료: dist/tailwind/icons.css')

    // 메타데이터 생성
    const categoryCounts = {
      system: 0,
      sign: 0,
      arrow: 0,
      attachment: 0,
      view: 0,
      etc: 0,
    }

    for (const icon of allIcons) {
      const category = getIconCategory(icon)
      if (categoryCounts.hasOwnProperty(category)) {
        categoryCounts[category]++
      }
    }

    const metadata = {
      icons: {
        total: allIcons.length,
        categories: categoryCounts,
        list: allIcons,
      },
      generatedAt: new Date().toISOString(),
    }

    const metadataPath = path.join(DIST_DIR, 'meta', 'icons.json')
    await fs.mkdir(path.dirname(metadataPath), { recursive: true })
    await fs.writeFile(metadataPath, JSON.stringify(metadata, null, 2))
    console.log('✅ 메타데이터 생성 완료: dist/meta/icons.json')

    console.log('\n🎉 아이콘 빌드가 완료되었습니다!')
    console.log(`   총 ${allIcons.length}개의 아이콘이 처리되었습니다.`)
  } catch (error) {
    console.error('💥 아이콘 빌드 중 오류가 발생했습니다:', error.message)
    process.exit(1)
  }
}

// 스크립트 실행
if (require.main === module) {
  buildIcons()
}

module.exports = { buildIcons }
