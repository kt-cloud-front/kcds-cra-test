/**
 * Unified Frameworks Builder
 *
 * 하이브리드 레이어링 방식으로 CSS, SCSS, Tailwind 파일을 생성하는 통합 빌드 스크립트
 * - CSS: modes.css, themes.css, index.css
 * - SCSS: _modes.scss, _themes.scss, _tokens.scss
 * - Tailwind: modes.css, themes.css, index.css
 * - meta/*.json: 메타데이터 파일들
 */

const fs = require('fs')
const path = require('path')

const { writeIfContentChanged } = require('./write-if-changed')
const { normalizeTokens } = require('./normalize-tokens')

// 빌더 모듈들 import
const { buildCSS } = require('./builders/css-builder')
const { buildSCSS } = require('./builders/scss-builder')
const { buildTailwind } = require('./builders/tailwind-builder')

// 토큰에서 사용 가능한 테마 추출 함수 (실제로는 $extensions.mode가 테마를 의미)
function extractAvailableThemes(tokens) {
  const themes = new Set(['default']) // 기본 테마는 항상 포함

  // theme 섹션에서 재귀적으로 $extensions.mode를 통해 테마 추출
  function extractThemesRecursively(obj, path = '') {
    if (obj && typeof obj === 'object') {
      // $extensions.mode가 있는 경우 테마 추출
      if (obj.$extensions && obj.$extensions.mode) {
        Object.keys(obj.$extensions.mode).forEach((theme) => {
          themes.add(theme)
        })
      }

      // 하위 객체들을 재귀적으로 탐색
      Object.entries(obj).forEach(([key, value]) => {
        if (value && typeof value === 'object') {
          // $type이나 $value가 있어도 $extensions가 있을 수 있으므로 계속 탐색
          extractThemesRecursively(value, path ? `${path}.${key}` : key)
        }
      })
    }
  }

  if (tokens.theme) {
    extractThemesRecursively(tokens.theme, 'theme')
  }

  return Array.from(themes).sort()
}

// 공통 메타데이터 생성 함수
function createSharedMetaData(buildConfig) {
  const { useDTCGKeys, colorMode, variableCollections } = buildConfig
  const metaDir = path.join(__dirname, '../../dist/meta')

  // package.json에서 버전 정보 읽기
  const packageJsonPath = path.join(__dirname, '../../package.json')
  const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'))
  const version = packageJson.version

  // tokens.json에서 사용 가능한 테마 추출
  const tokensPath = path.join(__dirname, '../tokens/tokens.json')
  const tokensData = JSON.parse(fs.readFileSync(tokensPath, 'utf8'))
  const availableThemes = extractAvailableThemes(tokensData)

  // 출력 디렉토리 생성
  if (!fs.existsSync(metaDir)) {
    fs.mkdirSync(metaDir, { recursive: true })
  }

  const modesJSON = {
    modes: ['light', 'dark'],
    default: 'light',
    description: 'Supported design system modes',
  }

  const themesJSON = {
    themes: availableThemes,
    default: 'default',
    description: 'Supported design system themes',
  }

  const configJSON = {
    useDTCGKeys,
    colorMode,
    variableCollections,
    supportedModes: modesJSON.modes,
    supportedThemes: themesJSON.themes,
    generatedAt: new Date().toISOString(),
    version: version,
  }

  // 공통 메타데이터 파일들 저장 (콘텐츠 동일 시 write 스킵 — config.json 의 generatedAt 만 바뀐 경우 등)
  writeIfContentChanged(path.join(metaDir, 'modes.json'), JSON.stringify(modesJSON, null, 2))
  writeIfContentChanged(path.join(metaDir, 'themes.json'), JSON.stringify(themesJSON, null, 2))
  writeIfContentChanged(path.join(metaDir, 'config.json'), JSON.stringify(configJSON, null, 2))

  console.log('✅ 공통 메타데이터가 생성되었습니다:')
  console.log(`📄 dist/meta/modes.json`)
  console.log(`📄 dist/meta/themes.json`)
  console.log(`📄 dist/meta/config.json`)
}

// tokens.json 파일 경로
const tokensFilePath = path.join(__dirname, '../tokens/tokens.json')

// tokens.json 읽기 (익스포트 형식 차이는 정규화 계층이 흡수)
const tokensData = normalizeTokens(JSON.parse(fs.readFileSync(tokensFilePath, 'utf8')))

// $extensions 정보 추출 — 정규화를 거쳤으므로 항상 DTCG 키 기준
const extensions = tokensData.$extensions?.['tokens-bruecke-meta'] || {}
const { colorMode = 'hex', variableCollections } = extensions
const useDTCGKeys = true

// 명령행 인수로 프레임워크 타입 받기
const frameworkType = process.argv[2] || 'all'

console.log(`Building hybrid layering ${frameworkType} tokens with:`)
console.log('- colorMode:', colorMode)
console.log('- variableCollections:', variableCollections)

// 지원하는 설정 검증
if (colorMode !== 'hex') {
  console.warn('⚠️  Only hex colorMode is supported in this version')
}

// 토큰 컬렉션 추출
const baseTokens = tokensData.base || {}
const themeTokens = tokensData.theme || {}
const modeTokens = tokensData.mode || {}
const dimensionTokens = tokensData.dimension || {}

// px 단위가 필요 없는 속성들
const noPxProperties = [
  'zIndex',
  'opacity',
  'font.weight',
  'font.lineHeight.unitless',
  'font.lineHeight.ratio',
  'border.radius.full',
  'shadow.offset',
  'shadow.blur',
  'shadow.spread',
  'motion.duration',
  'motion.delay',
  'breakpoint',
  'layout.column.count',
  'gridBase',
]

// 완전히 단위가 없어야 하는 속성들 (px 단위 제거)
const unitlessProperties = [
  'font.weight',
  'font.lineHeight.unitless',
  'font.lineHeight.ratio',
  'zIndex',
  'shadow.offset',
  'shadow.blur',
  'shadow.spread',
]

// 특별한 값 변환 함수
function transformSpecialValues(tokenPath, value) {
  // opacity 값을 100분율에서 0-1 범위로 변환
  if (tokenPath.includes('opacity')) {
    const numValue = parseFloat(value)
    if (!isNaN(numValue)) {
      return (numValue / 100).toString()
    }
  }

  // line-height.ratio 값에서 px 단위 제거 (비율이므로 단위 없음)
  if (tokenPath.includes('lineHeight.ratio')) {
    if (typeof value === 'string' && value.endsWith('px')) {
      return value.replace(/px$/, '')
    }
  }

  // letter-spacing 값을 px에서 em으로 변환
  if (tokenPath.includes('letterSpacing')) {
    if (typeof value === 'string' && value.endsWith('px')) {
      const numValue = parseFloat(value)
      if (!isNaN(numValue)) {
        // px를 em으로 변환 (px 값을 그대로 em으로: 0.01px → 0.01em)
        return `${numValue}em`
      }
    }
    // 이미 숫자 값인 경우 (px로 가정)
    if (typeof value === 'number') {
      return `${value}em`
    }
  }

  return value
}

// px 단위가 필요한지 확인하는 함수
function needsPxUnit(tokenPath, value) {
  // 완전히 단위가 없어야 하는 속성들 체크 (최우선)
  for (const unitlessProp of unitlessProperties) {
    if (tokenPath.includes(unitlessProp)) {
      // console.log(`🟡 Unitless for ${tokenPath} (matched: ${unitlessProp})`)
      return false
    }
  }

  // 단위가 필요 없는 속성들 체크
  for (const noPxProp of noPxProperties) {
    if (tokenPath.includes(noPxProp)) {
      // console.log(`🟡 No px unit for ${tokenPath} (matched: ${noPxProp})`)
      return false
    }
  }

  // 이미 단위가 있는 경우
  if (typeof value === 'string' && /[0-9]+(px|em|rem|%|vh|vw|deg|s|ms)$/.test(value)) {
    return false
  }

  // 숫자인 경우 px 추가
  if (typeof value === 'number') {
    return true
  }

  // 문자열이지만 단위가 없는 숫자인 경우
  if (typeof value === 'string' && /^[0-9]+$/.test(value)) {
    return true
  }

  return false
}

// 참조 해결 함수
function resolveReferences(
  value,
  baseTokens,
  themeTokens,
  modeTokens,
  dimensionTokens,
  tokenPath,
  depth = 0,
) {
  if (depth > 10) {
    console.warn(`🔴 Circular reference detected in ${tokenPath}`)
    return '#FF0000'
  }

  if (typeof value !== 'string' || !value.startsWith('{')) {
    return value
  }

  // 참조 패턴 추출: {base.color.blue.500} 또는 {theme.color.accent.default}
  const refMatch = value.match(/^\{([^}]+)\}$/)
  if (!refMatch) {
    console.warn(`🔴 Invalid reference format: ${value} in ${tokenPath}`)
    return '#FF0000'
  }

  const refPath = refMatch[1]

  // 컬렉션별로 토큰 찾기
  let current = null
  let sourceCollection = ''

  if (refPath.startsWith('base.')) {
    current = baseTokens
    sourceCollection = 'base'
    const pathParts = refPath.replace('base.', '').split('.')
    for (const part of pathParts) {
      if (current && current[part]) {
        current = current[part]
      } else {
        console.warn(`🔴 Reference not found, using red: ${refPath} in ${tokenPath}`)
        return '#FF0000'
      }
    }
  } else if (refPath.startsWith('theme.')) {
    current = themeTokens
    sourceCollection = 'theme'
    const pathParts = refPath.replace('theme.', '').split('.')
    for (const part of pathParts) {
      if (current && current[part]) {
        current = current[part]
      } else {
        console.warn(`🔴 Reference not found, using red: ${refPath} in ${tokenPath}`)
        return '#FF0000'
      }
    }
  } else if (refPath.startsWith('mode.')) {
    current = modeTokens
    sourceCollection = 'mode'
    const pathParts = refPath.replace('mode.', '').split('.')
    for (const part of pathParts) {
      if (current && current[part]) {
        current = current[part]
      } else {
        console.warn(`🔴 Reference not found, using red: ${refPath} in ${tokenPath}`)
        return '#FF0000'
      }
    }
  } else if (refPath.startsWith('dimension.')) {
    current = dimensionTokens
    sourceCollection = 'dimension'
    const pathParts = refPath.replace('dimension.', '').split('.')
    for (const part of pathParts) {
      if (current && current[part]) {
        current = current[part]
      } else {
        console.warn(`🔴 Reference not found, using red: ${refPath} in ${tokenPath}`)
        return '#FF0000'
      }
    }
  } else {
    // Design Tokens.[deprecated] 같은 특수 참조 처리
    if (refPath.includes('[deprecated]')) {
      console.warn(`🔴 Design Tokens reference replaced: ${refPath} in ${tokenPath}`)
      return '#FF0000'
    }
    console.warn(`🔴 Unknown reference format: ${refPath} in ${tokenPath}`)
    return '#FF0000'
  }

  if (current) {
    const resolvedValue = current.$value || current.value
    if (typeof resolvedValue === 'string' && resolvedValue.startsWith('{')) {
      return resolveReferences(
        resolvedValue,
        baseTokens,
        themeTokens,
        modeTokens,
        dimensionTokens,
        tokenPath,
        depth + 1,
      )
    }
    return resolvedValue
  }

  console.warn(`🔴 Reference not found, using red: ${refPath} in ${tokenPath}`)
  return '#FF0000'
}

// 토큰을 플랫하게 변환하는 함수
function flattenTokens(
  obj,
  prefix = '',
  baseTokens = {},
  themeTokens = {},
  modeTokens = {},
  dimensionTokens = {},
  tokenPath = '',
) {
  let result = {}
  for (const key in obj) {
    if (obj.hasOwnProperty(key)) {
      const newKey = prefix ? `${prefix}-${key}` : key
      const newTokenPath = tokenPath ? `${tokenPath}.${key}` : key

      if (
        obj[key] &&
        typeof obj[key] === 'object' &&
        !obj[key].hasOwnProperty(useDTCGKeys ? '$type' : 'type')
      ) {
        Object.assign(
          result,
          flattenTokens(
            obj[key],
            newKey,
            baseTokens,
            themeTokens,
            modeTokens,
            dimensionTokens,
            newTokenPath,
          ),
        )
      } else if (obj[key] && obj[key][useDTCGKeys ? '$value' : 'value'] !== undefined) {
        const tokenValue = obj[key][useDTCGKeys ? '$value' : 'value']
        const resolvedValue = resolveReferences(
          tokenValue,
          baseTokens,
          themeTokens,
          modeTokens,
          dimensionTokens,
          newTokenPath,
        )

        // 특별한 값 변환 적용
        const transformedValue = transformSpecialValues(newTokenPath, resolvedValue)

        // px 단위 추가 (필요한 경우)
        let finalValue = needsPxUnit(newTokenPath, transformedValue)
          ? `${transformedValue}px`
          : transformedValue

        // unitlessProperties에 포함된 경우 단위 제거
        for (const unitlessProp of unitlessProperties) {
          if (newTokenPath.includes(unitlessProp)) {
            finalValue = String(finalValue).replace(/px$/, '')
            break
          }
        }

        result[newKey] = finalValue
      }
    }
  }
  return result
}

// 특정 테마에 대한 토큰을 플랫하게 변환하는 함수
function flattenThemeTokens(
  obj,
  themeName,
  prefix = '',
  baseTokens = {},
  themeTokens = {},
  modeTokens = {},
  dimensionTokens = {},
  tokenPath = '',
) {
  let result = {}
  for (const key in obj) {
    if (obj.hasOwnProperty(key)) {
      const newKey = prefix ? `${prefix}-${key}` : key
      const newTokenPath = tokenPath ? `${tokenPath}.${key}` : key

      if (
        obj[key] &&
        typeof obj[key] === 'object' &&
        !obj[key].hasOwnProperty(useDTCGKeys ? '$type' : 'type')
      ) {
        Object.assign(
          result,
          flattenThemeTokens(
            obj[key],
            themeName,
            newKey,
            baseTokens,
            themeTokens,
            modeTokens,
            dimensionTokens,
            newTokenPath,
          ),
        )
      } else if (obj[key] && obj[key][useDTCGKeys ? '$value' : 'value'] !== undefined) {
        // 테마별 값이 있는지 확인
        let tokenValue = obj[key][useDTCGKeys ? '$value' : 'value']

        // $extensions.mode에서 테마별 값 찾기
        if (
          obj[key].$extensions &&
          obj[key].$extensions.mode &&
          obj[key].$extensions.mode[themeName]
        ) {
          tokenValue = obj[key].$extensions.mode[themeName]
        }

        const resolvedValue = resolveReferences(
          tokenValue,
          baseTokens,
          themeTokens,
          modeTokens,
          dimensionTokens,
          newTokenPath,
        )

        // 특별한 값 변환 적용
        const transformedValue = transformSpecialValues(newTokenPath, resolvedValue)

        // px 단위 추가 (필요한 경우)
        let finalValue = needsPxUnit(newTokenPath, transformedValue)
          ? `${transformedValue}px`
          : transformedValue

        // unitlessProperties에 포함된 경우 단위 제거
        for (const unitlessProp of unitlessProperties) {
          if (newTokenPath.includes(unitlessProp)) {
            finalValue = String(finalValue).replace(/px$/, '')
            break
          }
        }

        result[newKey] = finalValue
      }
    }
  }
  return result
}

// 특정 모드에 대한 토큰을 플랫하게 변환하는 함수
function flattenModeTokens(
  obj,
  modeName,
  prefix = '',
  baseTokens = {},
  themeTokens = {},
  modeTokens = {},
  dimensionTokens = {},
  tokenPath = '',
) {
  let result = {}
  for (const key in obj) {
    if (obj.hasOwnProperty(key)) {
      const newKey = prefix ? `${prefix}-${key}` : key
      const newTokenPath = tokenPath ? `${tokenPath}.${key}` : key

      if (
        obj[key] &&
        typeof obj[key] === 'object' &&
        !obj[key].hasOwnProperty(useDTCGKeys ? '$type' : 'type')
      ) {
        Object.assign(
          result,
          flattenModeTokens(
            obj[key],
            modeName,
            newKey,
            baseTokens,
            themeTokens,
            modeTokens,
            dimensionTokens,
            newTokenPath,
          ),
        )
      } else if (obj[key] && obj[key][useDTCGKeys ? '$value' : 'value'] !== undefined) {
        // 모드별 값이 있는지 확인
        let tokenValue = obj[key][useDTCGKeys ? '$value' : 'value']

        // $extensions.mode에서 모드별 값 찾기
        if (
          obj[key].$extensions &&
          obj[key].$extensions.mode &&
          obj[key].$extensions.mode[modeName]
        ) {
          tokenValue = obj[key].$extensions.mode[modeName]
        }

        const resolvedValue = resolveReferences(
          tokenValue,
          baseTokens,
          themeTokens,
          modeTokens,
          dimensionTokens,
          newTokenPath,
        )

        // 특별한 값 변환 적용
        const transformedValue = transformSpecialValues(newTokenPath, resolvedValue)

        // px 단위 추가 (필요한 경우)
        let finalValue = needsPxUnit(newTokenPath, transformedValue)
          ? `${transformedValue}px`
          : transformedValue

        // unitlessProperties에 포함된 경우 단위 제거
        for (const unitlessProp of unitlessProperties) {
          if (newTokenPath.includes(unitlessProp)) {
            finalValue = String(finalValue).replace(/px$/, '')
            break
          }
        }

        result[newKey] = finalValue
      }
    }
  }
  return result
}

// 토큰들을 플랫하게 변환
const baseFlat = flattenTokens(baseTokens, '', baseTokens, themeTokens, modeTokens, dimensionTokens)
const themeFlat = flattenTokens(
  themeTokens,
  '',
  baseTokens,
  themeTokens,
  modeTokens,
  dimensionTokens,
)
const modeFlat = flattenTokens(modeTokens, '', baseTokens, themeTokens, modeTokens, dimensionTokens)
const dimensionFlat = flattenTokens(
  dimensionTokens,
  '',
  baseTokens,
  themeTokens,
  modeTokens,
  dimensionTokens,
)

// 모드별 토큰 생성 (light/dark 모드별로 다른 값이 있는 토큰들)
const modeTokensByMode = {}
const availableModes = ['light', 'dark']
availableModes.forEach((modeName) => {
  // theme 섹션에서 모드별 토큰을 찾아서 생성
  modeTokensByMode[modeName] = {}

  // theme 섹션을 재귀적으로 탐색하여 모드별 토큰 찾기
  function findModeTokens(obj, prefix = '') {
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        const newKey = prefix ? `${prefix}-${key}` : key

        if (
          obj[key] &&
          typeof obj[key] === 'object' &&
          obj[key].$extensions &&
          obj[key].$extensions.mode
        ) {
          // 모드별 값이 있는 토큰 발견
          if (obj[key].$extensions.mode[modeName]) {
            const tokenValue = obj[key].$extensions.mode[modeName]
            const resolvedValue = resolveReferences(
              tokenValue,
              baseTokens,
              themeTokens,
              modeTokens,
              dimensionTokens,
              newKey,
            )
            const transformedValue = transformSpecialValues(newKey, resolvedValue)
            let finalValue = needsPxUnit(newKey, transformedValue)
              ? `${transformedValue}px`
              : transformedValue

            // unitlessProperties에 포함된 경우 단위 제거
            for (const unitlessProp of unitlessProperties) {
              if (newKey.includes(unitlessProp)) {
                finalValue = String(finalValue).replace(/px$/, '')
                break
              }
            }

            modeTokensByMode[modeName][`${newKey}`] = finalValue
          }
        } else if (obj[key] && typeof obj[key] === 'object' && !obj[key].hasOwnProperty('$type')) {
          // 하위 객체 재귀 탐색
          findModeTokens(obj[key], newKey)
        }
      }
    }
  }

  findModeTokens(modeTokens)
})

// 토큰 생성 통계
const totalTokens =
  Object.keys(baseFlat).length +
  Object.keys(themeFlat).length +
  Object.keys(modeFlat).length +
  Object.keys(dimensionFlat).length
console.log(`Generated ${totalTokens} tokens:`)
console.log(`- base: ${Object.keys(baseFlat).length}`)
console.log(`- theme: ${Object.keys(themeFlat).length}`)
console.log(`- mode: ${Object.keys(modeFlat).length}`)
console.log(`- dimension: ${Object.keys(dimensionFlat).length}`)

// 빌드 설정 객체
const buildConfig = {
  useDTCGKeys,
  colorMode,
  variableCollections,
}

// 사용 가능한 테마 목록 추출
const availableThemes = extractAvailableThemes(tokensData)

// 테마별 토큰 생성
const themeTokensByTheme = {}
availableThemes.forEach((themeName) => {
  themeTokensByTheme[themeName] = flattenThemeTokens(
    themeTokens,
    themeName,
    '',
    baseTokens,
    themeTokens,
    modeTokens,
    dimensionTokens,
  )
})

// 토큰 객체
const tokens = {
  baseFlat,
  themeFlat,
  modeFlat,
  dimensionFlat,
  themeTokensByTheme, // 테마별 토큰 추가
  modeTokensByMode, // 모드별 토큰 추가
  useDTCGKeys,
  colorMode,
  variableCollections,
  availableThemes,
  tokensData, // 원본 토큰 데이터도 전달
}

// 공통 메타데이터 생성
createSharedMetaData(buildConfig)

// 메인 실행 로직
switch (frameworkType) {
  case 'css':
    buildCSS(tokens, buildConfig)
    break
  case 'scss':
    buildSCSS(tokens, buildConfig)
    break
  case 'tailwind':
    buildTailwind(tokens, buildConfig)
    break
  case 'all':
    buildCSS(tokens, buildConfig)
    buildSCSS(tokens, buildConfig)
    buildTailwind(tokens, buildConfig)
    break
  default:
    console.error(`❌ Unknown framework type: ${frameworkType}`)
    console.log('Available frameworks: css, scss, tailwind, all')
    process.exit(1)
}

console.log(`🚀 하이브리드 레이어링 ${frameworkType} 방식으로 최적화된 구조가 완성되었습니다!`)
