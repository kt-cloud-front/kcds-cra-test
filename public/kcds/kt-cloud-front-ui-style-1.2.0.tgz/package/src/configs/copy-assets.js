#!/usr/bin/env node

/**
 * 에셋 복사 스크립트 (크로스플랫폼)
 * mkdir -p && cp -r 대체
 *
 * 사용법: node src/configs/copy-assets.js <assetType>
 * 예: node src/configs/copy-assets.js icons
 */

const { existsSync, mkdirSync, cpSync } = require('fs')
const { resolve } = require('path')

const assetType = process.argv[2]
if (!assetType) {
  console.error('❌ 에셋 타입을 지정해주세요. 예: node src/configs/copy-assets.js icons')
  process.exit(1)
}

const root = resolve(__dirname, '../..')
const src = resolve(root, 'src/assets', assetType)
const dest = resolve(root, 'dist/assets', assetType)

if (!existsSync(src)) {
  console.error(`❌ 소스 디렉토리가 없습니다: ${src}`)
  process.exit(1)
}

mkdirSync(resolve(root, 'dist/assets'), { recursive: true })
cpSync(src, dest, { recursive: true })
console.log(`✅ ${assetType} 에셋 복사 완료`)
