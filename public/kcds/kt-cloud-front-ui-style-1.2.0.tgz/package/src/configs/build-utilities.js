/**
 * Utilities Builder
 *
 * tokens.json의 Typography-styles.kcds.font, Effect-styles.kcds 섹션을 파싱하여
 * Typography, Effects 유틸리티 클래스를 자동 생성
 *
 * 출력 파일:
 * - dist/css/fonts.css (기존 @font-face + Typography 유틸리티)
 * - dist/css/utilities.css (Effects + Helpers)
 * - dist/scss/_fonts.scss
 * - dist/scss/_utilities.scss
 * - dist/tailwind/fonts.css
 * - dist/tailwind/utilities.css
 */

const fs = require('fs')
const path = require('path')

// 빌더 모듈들 import
const {
  buildTypographyClasses,
  buildTypographySCSS,
} = require('./builders/utilities/typography-builder')
const { buildEffectsClasses, buildEffectsSCSS } = require('./builders/utilities/effects-builder')
const { normalizeTokens } = require('./normalize-tokens')

// tokens.json 파일 경로
const tokensFilePath = path.join(__dirname, '../tokens/tokens.json')

// tokens.json 읽기 (익스포트 형식 차이는 정규화 계층이 흡수)
const tokensData = normalizeTokens(JSON.parse(fs.readFileSync(tokensFilePath, 'utf8')))

// 토큰 섹션 추출
const fontKcds = tokensData['Typography-styles']?.kcds?.font || {}
const effectStylesKcds = tokensData['Effect-styles']?.kcds || {}
const baseTokens = tokensData.base || {}

// 명령행 인수로 프레임워크 타입 받기
const frameworkType = process.argv[2] || 'all'

console.log(`\n🎨 Building utilities for ${frameworkType}...`)

// 출력 디렉토리
const outputDirs = {
  css: path.join(__dirname, '../../dist/css'),
  scss: path.join(__dirname, '../../dist/scss'),
  tailwind: path.join(__dirname, '../../dist/tailwind'),
}

// 포맷 디렉토리 (소스 파일)
const formatDirs = {
  css: path.join(__dirname, 'formats/css'),
  scss: path.join(__dirname, 'formats/scss'),
  tailwind: path.join(__dirname, 'formats/tailwind'),
}

/**
 * 디렉토리 생성 (없으면)
 */
function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true })
  }
}

/**
 * CSS 빌드
 */
function buildCSS() {
  ensureDir(outputDirs.css)

  // 1. Typography 클래스 생성
  const typographyClasses = buildTypographyClasses(fontKcds, 'css')

  // 2. Effects 클래스 생성
  const effectsClasses = buildEffectsClasses(effectStylesKcds, baseTokens, 'css')

  // 3. 기존 fonts.css 읽기 (formats 폴더에서)
  const fontsSourcePath = path.join(formatDirs.css, 'fonts.css')
  let fontsContent = ''
  if (fs.existsSync(fontsSourcePath)) {
    fontsContent = fs.readFileSync(fontsSourcePath, 'utf8')
  }

  // 4. fonts.css 생성 (@font-face + Typography)
  const fontsOutput = `${fontsContent}
/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Typography 유틸리티 클래스 (tokens.json 자동 생성)
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
${typographyClasses}
`
  fs.writeFileSync(path.join(outputDirs.css, 'fonts.css'), fontsOutput)
  console.log('  ✅ dist/css/fonts.css')

  // 5. helpers.css 읽기 (있으면)
  const helpersSourcePath = path.join(formatDirs.css, 'helpers.css')
  let helpersContent = ''
  if (fs.existsSync(helpersSourcePath)) {
    helpersContent = fs.readFileSync(helpersSourcePath, 'utf8')
  }

  // 6. utilities.css 생성 (Effects + Helpers)
  const utilitiesOutput = `/**
 * @kt-cloud-front/ui-style CSS Utilities
 * Auto-generated from tokens.json
 */

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Effects 유틸리티 (tokens.json 자동 생성)
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
${effectsClasses}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Helper 유틸리티 (수동 작성)
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
${helpersContent}
`
  fs.writeFileSync(path.join(outputDirs.css, 'utilities.css'), utilitiesOutput)
  console.log('  ✅ dist/css/utilities.css')
}

/**
 * SCSS 빌드
 */
function buildSCSS() {
  ensureDir(outputDirs.scss)

  // 1. Typography SCSS 생성
  const typographySCSS = buildTypographySCSS(fontKcds)

  // 2. Effects SCSS 생성
  const effectsSCSS = buildEffectsSCSS(effectStylesKcds, baseTokens)

  // 3. 기존 _fonts.scss 읽기
  const fontsSourcePath = path.join(formatDirs.scss, '_fonts.scss')
  let fontsContent = ''
  if (fs.existsSync(fontsSourcePath)) {
    fontsContent = fs.readFileSync(fontsSourcePath, 'utf8')
  }

  // 4. _fonts.scss 생성
  const fontsOutput = `${fontsContent}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// Typography 유틸리티 (tokens.json 자동 생성)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${typographySCSS}
`
  fs.writeFileSync(path.join(outputDirs.scss, '_fonts.scss'), fontsOutput)
  console.log('  ✅ dist/scss/_fonts.scss')

  // 5. _helpers.scss 읽기
  const helpersSourcePath = path.join(formatDirs.scss, '_helpers.scss')
  let helpersContent = ''
  if (fs.existsSync(helpersSourcePath)) {
    helpersContent = fs.readFileSync(helpersSourcePath, 'utf8')
  }

  // 6. _utilities.scss 생성
  const utilitiesOutput = `/**
 * @kt-cloud-front/ui-style SCSS Utilities
 * Auto-generated from tokens.json
 */

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// Effects 유틸리티 (tokens.json 자동 생성)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${effectsSCSS}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// Helper 유틸리티 (수동 작성)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${helpersContent}
`
  fs.writeFileSync(path.join(outputDirs.scss, '_utilities.scss'), utilitiesOutput)
  console.log('  ✅ dist/scss/_utilities.scss')
}

/**
 * Tailwind 빌드
 */
function buildTailwind() {
  ensureDir(outputDirs.tailwind)

  // 1. Typography 클래스 생성
  const typographyClasses = buildTypographyClasses(fontKcds, 'tailwind')

  // 2. Effects 클래스 생성
  const effectsClasses = buildEffectsClasses(effectStylesKcds, baseTokens, 'tailwind')

  // 3. 기존 fonts.css 읽기
  const fontsSourcePath = path.join(formatDirs.tailwind, 'fonts.css')
  let fontsContent = ''
  if (fs.existsSync(fontsSourcePath)) {
    fontsContent = fs.readFileSync(fontsSourcePath, 'utf8')
  }

  // 4. fonts.css 생성
  const fontsOutput = `${fontsContent}
/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Typography 유틸리티 클래스 (tokens.json 자동 생성)
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
${typographyClasses}
`
  fs.writeFileSync(path.join(outputDirs.tailwind, 'fonts.css'), fontsOutput)
  console.log('  ✅ dist/tailwind/fonts.css')

  // 5. helpers.css 읽기
  const helpersSourcePath = path.join(formatDirs.tailwind, 'helpers.css')
  let helpersContent = ''
  if (fs.existsSync(helpersSourcePath)) {
    helpersContent = fs.readFileSync(helpersSourcePath, 'utf8')
  }

  // 6. utilities.css 생성
  const utilitiesOutput = `/**
 * @kt-cloud-front/ui-style Tailwind Utilities
 * Auto-generated from tokens.json
 */

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Effects 유틸리티 (tokens.json 자동 생성)
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
${effectsClasses}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Helper 유틸리티 (수동 작성)
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
${helpersContent}
`
  fs.writeFileSync(path.join(outputDirs.tailwind, 'utilities.css'), utilitiesOutput)
  console.log('  ✅ dist/tailwind/utilities.css')
}

// 통계 출력
function printStats() {
  const headingCount = Object.keys(fontKcds.heading || {}).length
  const paragraphCount = Object.keys(fontKcds.paragraph || {}).reduce((acc, size) => {
    return acc + Object.keys(fontKcds.paragraph[size] || {}).filter((k) => k !== '$type').length
  }, 0)
  const labelCount = Object.keys(fontKcds.label || {}).reduce((acc, size) => {
    return acc + Object.keys(fontKcds.label[size] || {}).filter((k) => k !== '$type').length
  }, 0)
  const codeCount = Object.keys(fontKcds.code || {}).reduce((acc, size) => {
    return acc + Object.keys(fontKcds.code[size] || {}).filter((k) => k !== '$type').length
  }, 0)
  const numericCount = Object.keys(fontKcds.numeric || {}).reduce((acc, size) => {
    return acc + Object.keys(fontKcds.numeric[size] || {}).filter((k) => k !== '$type').length
  }, 0)
  const unitCount = Object.keys(fontKcds.unit || {}).filter((k) => k !== '$type').length

  const shadowCount = Object.keys(effectStylesKcds.elevation?.shadow || {}).length
  const focusRingCount = Object.keys(effectStylesKcds.focusRing || {}).length
  const blurCount = effectStylesKcds.elevation?.blur ? 1 : 0

  console.log('\n📊 생성된 유틸리티 클래스:')
  console.log(
    `   Typography: ${headingCount + paragraphCount + labelCount + codeCount + numericCount + unitCount}개`,
  )
  console.log(`     - heading: ${headingCount}`)
  console.log(`     - paragraph: ${paragraphCount}`)
  console.log(`     - label: ${labelCount}`)
  console.log(`     - code: ${codeCount}`)
  console.log(`     - numeric: ${numericCount}`)
  console.log(`     - unit: ${unitCount}`)
  console.log(`   Effects: ${shadowCount + focusRingCount + blurCount}개`)
  console.log(`     - shadow: ${shadowCount}`)
  console.log(`     - focusRing: ${focusRingCount}`)
  console.log(`     - blur: ${blurCount}`)
}

// 메인 실행 로직
switch (frameworkType) {
  case 'css':
    buildCSS()
    break
  case 'scss':
    buildSCSS()
    break
  case 'tailwind':
    buildTailwind()
    break
  case 'all':
    buildCSS()
    buildSCSS()
    buildTailwind()
    break
  default:
    console.error(`❌ Unknown framework type: ${frameworkType}`)
    console.log('Available frameworks: css, scss, tailwind, all')
    process.exit(1)
}

printStats()
console.log('\n🚀 유틸리티 빌드 완료!')
