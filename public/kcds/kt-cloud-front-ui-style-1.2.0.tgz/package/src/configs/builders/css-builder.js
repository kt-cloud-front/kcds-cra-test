/**
 * CSS Builder - 하이브리드 레이어링 방식
 *
 * 이 모듈은 CSS 파일 생성을 담당합니다.
 * modes.css, themes.css, index.css를 생성합니다.
 */

const fs = require('fs')
const path = require('path')

const { writeIfContentChanged } = require('../write-if-changed')

/**
 * CSS 빌드 함수
 * @param {Object} tokens - 플랫한 토큰 객체들
 * @param {Object} config - 빌드 설정
 */
function buildCSS(tokens, config) {
  const {
    baseFlat,
    themeFlat,
    modeFlat,
    dimensionFlat,
    themeTokensByTheme,
    modeTokensByMode,
    useDTCGKeys,
    colorMode,
    variableCollections,
    availableThemes,
    tokensData,
  } = tokens
  const outputDir = path.join(__dirname, '../../../dist/css')

  // 출력 디렉토리 생성
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true })
  }

  // 1. modes.css 생성 (light/dark 모드)
  let modesCSS = `/**
 * ========================================
 * Design System Modes (Light/Dark) - CSS
 * ========================================
 * 
 * 이 파일은 라이트/다크 모드별 CSS 변수를 정의합니다.
 * 
 * 🎯 사용법:
 * - 기본값: light 모드
 * - 다크 모드: document.documentElement.setAttribute('data-mode', 'dark')
 * 
 * 📁 파일 위치: @kt-cloud-front/ui-style/dist/css/modes.css
 * 📅 생성 시간: ${new Date().toLocaleString('ko-KR')}
 * ========================================
 */

/* 기본값 (Light 모드) */
:root,
:root[data-mode="light"] {
`

  // 기본 토큰들 추가 (base + mode + dimension light 모드)
  Object.keys(baseFlat).forEach((key) => {
    modesCSS += `  --${key}: ${baseFlat[key]};\n`
  })

  // mode 토큰들 추가 (light 모드)
  Object.keys(modeFlat).forEach((key) => {
    modesCSS += `  --${key}: ${modeFlat[key]};\n`
  })

  // 모드별 토큰들 추가 (light 모드)
  if (modeTokensByMode && modeTokensByMode.light) {
    Object.keys(modeTokensByMode.light).forEach((key) => {
      modesCSS += `  --${key}: ${modeTokensByMode.light[key]};\n`
    })
  }

  // dimension 토큰들 추가 (light 모드)
  Object.keys(dimensionFlat).forEach((key) => {
    modesCSS += `  --${key}: ${dimensionFlat[key]};\n`
  })

  // kcds-elevation-blur 토큰 추가 (background-blur-4 참조)
  modesCSS += `  --kcds-elevation-blur: blur(var(--background-blur-4));\n`

  modesCSS += `}

/* 다크 모드 */
:root[data-mode="dark"] {
`

  // 다크 모드 토큰들 추가 (base + mode + dimension dark 모드)
  Object.keys(baseFlat).forEach((key) => {
    modesCSS += `  --${key}: ${baseFlat[key]};\n`
  })

  // mode 토큰들 추가 (dark 모드)
  Object.keys(modeFlat).forEach((key) => {
    modesCSS += `  --${key}: ${modeFlat[key]};\n`
  })

  // 모드별 토큰들 추가 (dark 모드)
  if (modeTokensByMode && modeTokensByMode.dark) {
    Object.keys(modeTokensByMode.dark).forEach((key) => {
      modesCSS += `  --${key}: ${modeTokensByMode.dark[key]};\n`
    })
  }

  // dimension 토큰들 추가 (dark 모드)
  Object.keys(dimensionFlat).forEach((key) => {
    modesCSS += `  --${key}: ${dimensionFlat[key]};\n`
  })

  // kcds-elevation-blur 토큰 추가 (background-blur-4 참조)
  modesCSS += `  --kcds-elevation-blur: blur(var(--background-blur-4));\n`

  modesCSS += `}
`

  // 2. themes.css 생성 (동적 테마 처리)
  const themesList = availableThemes.join('/')
  let themesCSS = `/**
   * ========================================
   * Design System Themes (${themesList}) - CSS
   * ========================================
   * 
   * 이 파일은 테마별 CSS 변수를 정의합니다.
   * 
   * 🎯 사용법:
   * - 기본값: default 테마
   * - 테마 전환: document.documentElement.setAttribute('data-theme', '테마명')
   * 
   * 📁 파일 위치: @kt-cloud-front/ui-style/dist/css/themes.css
   * 📅 생성 시간: ${new Date().toLocaleString('ko-KR')}
   * ========================================
   */

/* 기본값 (Default 테마) */
:root,
:root[data-theme="default"] {
`

  // Default 테마 토큰들 추가
  if (themeTokensByTheme.default) {
    Object.keys(themeTokensByTheme.default).forEach((key) => {
      themesCSS += `  --${key}: ${themeTokensByTheme.default[key]};\n`
    })
  }

  themesCSS += `}
`

  // 각 테마별 CSS 생성
  availableThemes.forEach((theme) => {
    if (theme !== 'default') {
      themesCSS += `
/* ${theme} 테마 */
:root[data-theme="${theme}"] {
`

      // 테마별 토큰 사용
      if (themeTokensByTheme[theme]) {
        Object.keys(themeTokensByTheme[theme]).forEach((key) => {
          themesCSS += `  --${key}: ${themeTokensByTheme[theme][key]};\n`
        })
      }

      themesCSS += `}
`
    }
  })

  // 3. tokens.css 생성 (통합 파일)
  const themesListForTokens = availableThemes.join(' | ')
  let tokensCSS = `/**
   * ========================================
   * Design System Tokens - CSS (통합)
   * ========================================
   * 
   * 이 파일은 모든 디자인 토큰을 포함하는 통합 CSS 파일입니다.
   * 
   * 🎯 사용법:
   * - 모드 전환: data-mode="light" | "dark"
   * - 테마 전환: data-theme="${themesListForTokens}"
   * 
   * 📁 파일 위치: @kt-cloud-front/ui-style/dist/css/tokens.css
   * 📅 생성 시간: ${new Date().toLocaleString('ko-KR')}
   * ========================================
   */

${modesCSS.replace(/\/\*\*[\s\S]*?\*\//, '/* Modes CSS */')}

${themesCSS.replace(/\/\*\*[\s\S]*?\*\//, '/* Themes CSS */')}
`

  // 4. index.css (진입점)
  // 이 파일이 dist/css/index.css의 단일 소스입니다.
  // src/configs/formats/css/에는 base.css, helpers.css 등 정적 파일만 존재합니다.
  let indexCSS = `/**
 * @kt-cloud-front/ui-style CSS Framework
 *
 * 이 파일은 빌드 스크립트(css-builder.js)에 의해 자동 생성됩니다.
 * 직접 수정하지 마세요.
 *
 * 🎯 사용법:
 * - import '@kt-cloud-front/ui-style/css'
 *
 * 생성 시간: ${new Date().toLocaleString('ko-KR')}
 */

/* 디자인 토큰 (CSS 변수 정의) */
@import "./tokens.css";

/* 추가 변수 및 설정 */
@import "./variables.css";

/* 폰트 설정 */
@import "./fonts.css";

/* 아이콘 설정 */
@import "./icons.css";

/* 일러스트레이션 설정 */
@import "./illustrations.css";

/* 기본 스타일 (reset, typography) */
@import "./base.css";

/* 유틸리티 클래스 */
@import "./utilities.css";
`

  // 파일들 저장 (콘텐츠 동일 시 write 스킵 — timestamp 만 바뀐 경우 git tree 가 dirty 해지지 않도록)
  writeIfContentChanged(path.join(outputDir, 'modes.css'), modesCSS)
  writeIfContentChanged(path.join(outputDir, 'themes.css'), themesCSS)
  writeIfContentChanged(path.join(outputDir, 'tokens.css'), tokensCSS)
  writeIfContentChanged(path.join(outputDir, 'index.css'), indexCSS)

  console.log('✅ CSS 파일들이 생성되었습니다:')
  console.log(`📄 modes.css (${Math.round(modesCSS.length / 1024)}KB)`)
  console.log(`📄 themes.css (${Math.round(themesCSS.length / 1024)}KB)`)
  console.log(`📄 tokens.css (${Math.round(tokensCSS.length / 1024)}KB)`)
  console.log(`📄 index.css (${Math.round(indexCSS.length / 1024)}KB)`)
}

module.exports = { buildCSS }
