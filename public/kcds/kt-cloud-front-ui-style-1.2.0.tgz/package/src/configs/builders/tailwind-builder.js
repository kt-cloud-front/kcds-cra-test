/**
 * Tailwind Builder - Tailwind CSS v4 @theme 방식
 *
 * 이 모듈은 Tailwind CSS v4 파일 생성을 담당합니다.
 * - tokens.css: CSS 변수 정의 (modes + themes)
 * - theme.css: Tailwind CSS v4 @theme 블록 (유틸리티 클래스 생성용)
 * - index.css: 진입점 파일
 *
 * @theme 블록에 정의된 변수는 Tailwind가 자동으로 유틸리티 클래스를 생성합니다:
 * - --color-kcds-text-primary → text-kcds-text-primary, bg-kcds-text-primary 등
 * - --spacing-kcds-md → p-kcds-md, m-kcds-md, gap-kcds-md 등
 * - --radius-kcds-lg → rounded-kcds-lg
 *
 * Tailwind v4 @theme namespace 규칙 (유틸리티가 생성되는 변수 이름):
 * - --color-*        → text-*, bg-*, border-* 등 색상 유틸리티
 * - --spacing-*      → p-*, m-*, gap-*, w-*, h-* 등 간격 유틸리티
 * - --radius-*       → rounded-* 유틸리티
 * - --shadow-*       → shadow-* 유틸리티
 * - --text-*         → text-* 폰트 크기 (--font-size-* 대신 --text-* 사용하여 namespace 충돌 방지)
 * - --font-weight-*  → font-* 폰트 굵기
 * - --opacity-*      → opacity-* 투명도
 * - --blur-*         → blur-* 블러
 * - --size-*         → size-* 크기 (w-*, h-* 에는 붙지 않음)
 * - --breakpoint-*   → 반응형 브레이크포인트
 * - --ease-*         → ease-* 이징 함수
 *
 * 아래 토큰은 위 규칙에 맞지 않는 이름으로 출력되어 유틸리티가 생기지 않는다.
 * 기존 변수 이름을 바꾸면 var() 소비처가 깨지므로, @theme 끝에 v4 이름의 별칭을 덧붙인다
 * (NAMESPACE_ALIASES). 예: --z-kcds-overlay → --z-index-kcds-overlay → z-kcds-overlay
 * - --z-*              → --z-index-*            (z-*)
 * - --duration-*       → --transition-duration-* (duration-*)
 * - --delay-*          → --transition-delay-*   (delay-*)
 * - --line-height-*    → --leading-*            (leading-*)
 * - --letter-spacing-* → --tracking-*           (tracking-*)
 * - --font-family-*    → --font-*               (font-*)
 * - --size-*           → --width-*, --height-*  (w-*, h-*)
 */

const fs = require('fs')
const path = require('path')

const { writeIfContentChanged, copyIfContentChanged } = require('../write-if-changed')

// ============================================================
// 토큰 → Tailwind @theme 매핑 규칙
// ============================================================

const TAILWIND_THEME_MAPPINGS = [
  // KCDS Semantic Tokens (시맨틱 토큰) - 우선순위 높음
  {
    pattern: /^kcds-color-text-(.+)$/,
    tailwind: 'color-kcds-text-$1',
    category: 'KCDS Text Colors',
    priority: 100,
  },
  {
    pattern: /^kcds-color-background-(.+)$/,
    tailwind: 'color-kcds-bg-$1',
    category: 'KCDS Background Colors',
    priority: 100,
  },
  {
    pattern: /^kcds-color-border-(.+)$/,
    tailwind: 'color-kcds-border-$1',
    category: 'KCDS Border Colors',
    priority: 100,
  },
  {
    pattern: /^kcds-color-icon-(.+)$/,
    tailwind: 'color-kcds-icon-$1',
    category: 'KCDS Icon Colors',
    priority: 100,
  },
  {
    pattern: /^kcds-color-status-(.+)$/,
    tailwind: 'color-kcds-status-$1',
    category: 'KCDS Status Colors',
    priority: 100,
  },
  {
    pattern: /^kcds-color-accent-(.+)$/,
    tailwind: 'color-kcds-accent-$1',
    category: 'KCDS Accent Colors',
    priority: 100,
  },
  {
    pattern: /^kcds-color-primary-(.+)$/,
    tailwind: 'color-kcds-primary-$1',
    category: 'KCDS Primary Colors',
    priority: 100,
  },
  {
    pattern: /^kcds-elevation-zIndex-(.+)$/,
    tailwind: 'z-kcds-$1',
    category: 'KCDS Z-Index',
    priority: 100,
  },
  {
    pattern: /^kcds-elevation-shadow-(.+)$/,
    tailwind: 'shadow-kcds-$1',
    category: 'KCDS Elevation Shadow',
    priority: 100,
  },
  {
    pattern: /^kcds-elevation-surface-(.+)$/,
    tailwind: 'color-kcds-surface-$1',
    category: 'KCDS Elevation Surface',
    priority: 100,
  },
  {
    pattern: /^kcds-motion-duration-(.+)$/,
    tailwind: 'duration-kcds-$1',
    category: 'KCDS Motion Duration',
    priority: 100,
  },
  {
    pattern: /^kcds-motion-easing-(.+)$/,
    tailwind: 'ease-kcds-$1',
    category: 'KCDS Motion Easing',
    priority: 100,
  },
  {
    pattern: /^kcds-motion-delay-(.+)$/,
    tailwind: 'delay-kcds-$1',
    category: 'KCDS Motion Delay',
    priority: 100,
  },
  {
    pattern: /^kcds-spacing-(.+)$/,
    tailwind: 'spacing-kcds-$1',
    category: 'KCDS Spacing',
    priority: 100,
  },
  {
    pattern: /^kcds-iconSize-(.+)$/,
    tailwind: 'size-kcds-icon-$1',
    category: 'KCDS Icon Size',
    priority: 100,
  },
  {
    pattern: /^kcds-border-radius-(.+)$/,
    tailwind: 'radius-kcds-$1',
    category: 'KCDS Border Radius',
    priority: 100,
  },
  {
    pattern: /^kcds-border-width-(.+)$/,
    tailwind: 'border-width-kcds-$1',
    category: 'KCDS Border Width',
    priority: 100,
  },
  {
    pattern: /^kcds-opacity-(.+)$/,
    tailwind: 'opacity-kcds-$1',
    category: 'KCDS Opacity',
    priority: 100,
  },
  {
    pattern: /^kcds-breakpoint-(.+)$/,
    tailwind: 'breakpoint-kcds-$1',
    category: 'KCDS Breakpoint',
    priority: 100,
  },

  // Primitive Tokens (원시 토큰) - kcds- 네임스페이스로 Tailwind 기본값 충돌 방지
  {
    pattern: /^color-(.+)$/,
    tailwind: 'color-kcds-$1',
    category: 'Primitive Colors',
    priority: 10,
  },
  {
    pattern: /^font-family-(.+)$/,
    tailwind: 'font-family-kcds-$1',
    category: 'Font Family',
    priority: 10,
  },
  { pattern: /^font-size-(.+)$/, tailwind: 'text-kcds-$1', category: 'Font Size', priority: 10 },
  {
    pattern: /^font-weight-(.+)$/,
    tailwind: 'font-weight-kcds-$1',
    category: 'Font Weight',
    priority: 10,
  },
  {
    pattern: /^font-lineHeight-(.+)$/,
    tailwind: 'line-height-kcds-$1',
    category: 'Line Height',
    priority: 10,
  },
  {
    pattern: /^font-letterSpacing-(.+)$/,
    tailwind: 'letter-spacing-kcds-$1',
    category: 'Letter Spacing',
    priority: 10,
  },
  { pattern: /^size-(.+)$/, tailwind: 'size-kcds-$1', category: 'Primitive Size', priority: 10 },
  {
    pattern: /^border-radius-(.+)$/,
    tailwind: 'radius-kcds-$1',
    category: 'Primitive Border Radius',
    priority: 10,
  },
  {
    pattern: /^border-width-(.+)$/,
    tailwind: 'border-width-kcds-$1',
    category: 'Primitive Border Width',
    priority: 10,
  },
  { pattern: /^shadow-(.+)$/, tailwind: 'shadow-kcds-$1', category: 'Shadow', priority: 10 },
  { pattern: /^background-blur-(.+)$/, tailwind: 'blur-kcds-$1', category: 'Blur', priority: 10 },
  { pattern: /^opacity-(.+)$/, tailwind: 'opacity-kcds-$1', category: 'Opacity', priority: 10 },
  { pattern: /^zIndex-(.+)$/, tailwind: 'z-kcds-$1', category: 'Z-Index', priority: 10 },
  {
    pattern: /^breakpoint-(.+)$/,
    tailwind: 'breakpoint-kcds-$1',
    category: 'Breakpoints',
    priority: 10,
  },
  {
    pattern: /^motion-duration-(.+)$/,
    tailwind: 'duration-kcds-$1',
    category: 'Animation Duration',
    priority: 10,
  },
  {
    pattern: /^motion-easing-(.+)$/,
    tailwind: 'ease-kcds-$1',
    category: 'Animation Easing',
    priority: 10,
  },
  {
    pattern: /^motion-delay-(.+)$/,
    tailwind: 'delay-kcds-$1',
    category: 'Animation Delay',
    priority: 10,
  },
]

// 우선순위 순으로 정렬
const SORTED_MAPPINGS = [...TAILWIND_THEME_MAPPINGS].sort((a, b) => b.priority - a.priority)

/**
 * tokens.css(`:root {}`)에서 제외할 패턴
 *
 * Tailwind v4는 아래 CSS 변수명을 자체적으로 사용합니다.
 * KCDS 디자인 토큰이 같은 이름을 정의하면 Tailwind 표준 유틸리티가 깨집니다.
 * 이 토큰들은 theme.css에서 --size-kcds-*, --opacity-kcds-* 형태로 이미 정의됩니다.
 */
const TOKENS_CSS_EXCLUDE_PATTERNS = [
  /^size-\d/, // size-4, size-8 … → theme.css에 --size-kcds-* 로 정의됨
  /^opacity-\d/, // opacity-50 …    → theme.css에 --opacity-kcds-* 로 정의됨
]

function shouldExcludeFromTokensCSS(key) {
  return TOKENS_CSS_EXCLUDE_PATTERNS.some((pattern) => pattern.test(key))
}

/**
 * 토큰 키를 Tailwind @theme 변수명으로 변환
 */
function mapTokenToTailwind(tokenKey) {
  for (const mapping of SORTED_MAPPINGS) {
    const match = tokenKey.match(mapping.pattern)
    if (match) {
      let tailwindKey = mapping.tailwind
      for (let i = 1; i < match.length; i++) {
        tailwindKey = tailwindKey.replace(`$${i}`, match[i])
      }
      return { tailwindKey, category: mapping.category }
    }
  }
  return null
}

/**
 * 토큰들을 Tailwind @theme 형식으로 변환하고 카테고리별로 그룹핑
 */
function categorizeTokensForTailwind(flatTokens) {
  const categorized = new Map()
  const unmapped = []

  for (const [tokenKey, tokenValue] of Object.entries(flatTokens)) {
    const result = mapTokenToTailwind(tokenKey)
    if (result) {
      if (!categorized.has(result.category)) {
        categorized.set(result.category, new Map())
      }
      categorized.get(result.category).set(result.tailwindKey, tokenValue)
      // -default suffix 없는 shorthand alias 추가 (예: text-kcds-text-status-positive)
      if (result.tailwindKey.endsWith('-default')) {
        const alias = result.tailwindKey.replace(/-default$/, '')
        categorized.get(result.category).set(alias, tokenValue)
      }
    } else {
      unmapped.push(tokenKey)
    }
  }

  if (unmapped.length > 0) {
    console.warn(`⚠️  ${unmapped.length}개의 토큰이 Tailwind @theme에 매핑되지 않았습니다:`)
    unmapped.slice(0, 10).forEach((key) => console.warn(`   - ${key}`))
    if (unmapped.length > 10) {
      console.warn(`   ... 그 외 ${unmapped.length - 10}개`)
    }
  }

  return categorized
}

/**
 * CSS 값 보정 함수
 * 원본 토큰 데이터의 잘못된 값들을 올바른 CSS 값으로 변환
 */
function sanitizeCSSValue(key, value) {
  if (typeof value !== 'string') return value

  // 1. 잘못된 cubic-bezier(0, 0, 0, 0) → linear로 변환
  if (value === 'cubic-bezier(0, 0, 0, 0)') {
    return 'linear'
  }

  // 2. 폰트 패밀리: 공백이 있는 폰트명에 따옴표 추가
  if (key.includes('font-family')) {
    if (value.startsWith('"') || value.startsWith("'")) {
      return value
    }
    if (value.includes(' ')) {
      return `"${value}"`
    }
  }

  return value
}

// ============================================================
// 빌드 함수
// ============================================================

/**
 * Tailwind 빌드 함수
 */
function buildTailwind(tokens) {
  const {
    baseFlat,
    modeFlat,
    dimensionFlat,
    themeTokensByTheme,
    modeTokensByMode,
    availableThemes,
  } = tokens
  const outputDir = path.join(__dirname, '../../../dist/tailwind')

  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true })
  }

  // 1. modes.css
  let modesCSS = generateModesCSS(baseFlat, modeFlat, modeTokensByMode, dimensionFlat)

  // 2. themes.css
  let themesCSS = generateThemesCSS(themeTokensByTheme, availableThemes)

  // 3. tokens.css (통합)
  const themesListForTokens = availableThemes.join(' | ')
  let tokensCSS = `/**
 * Design System Tokens - Tailwind v4
 *
 * 사용법:
 * - 모드 전환: data-mode="light" | "dark"
 * - 테마 전환: data-theme="${themesListForTokens}"
 *
 * 생성 시간: ${new Date().toLocaleString('ko-KR')}
 */

${modesCSS.replace(/\/\*\*[\s\S]*?\*\//, '/* Modes CSS Variables */')}

${themesCSS.replace(/\/\*\*[\s\S]*?\*\//, '/* Themes CSS Variables */')}
`

  // 4. theme.css (@theme 블록)
  const themeCSS = generateTailwindThemeCSS(baseFlat, modeFlat, dimensionFlat)

  // 5. index.css (진입점)
  // 이 파일이 dist/tailwind/index.css의 단일 소스입니다.
  // src/configs/formats/tailwind/에는 base.css, helpers.css 등 정적 파일만 존재합니다.
  let indexCSS = `/**
 * @kt-cloud-front/ui-style Tailwind CSS v4 Framework
 *
 * 이 파일은 빌드 스크립트(tailwind-builder.js)에 의해 자동 생성됩니다.
 * 직접 수정하지 마세요.
 *
 * 🎯 사용법:
 * - import '@kt-cloud-front/ui-style/tailwind'
 *
 * 생성 시간: ${new Date().toLocaleString('ko-KR')}
 */

/* Tailwind CSS v4 */
@import 'tailwindcss';

/* 디자인 토큰 (CSS 변수 정의) */
@import "./tokens.css";

/* 모드별 토큰 오버라이드 (light/dark) */
@import "./modes.css";

/* 테마별 토큰 오버라이드 */
@import "./themes.css";

/* Tailwind v4 @theme 블록 (유틸리티 클래스 생성용) */
@import "./theme.css";

/* 아이콘 설정 */
@import "./icons.css";

/* 일러스트레이션 설정 */
@import "./illustrations.css";

/* 기본 스타일 */
@import "./base.css";

/* 유틸리티 클래스 */
@import "./utilities.css";
`

  // 6. css 폴더에서 필요한 파일들을 tailwind 폴더로 복사 (독립성 보장)
  const cssDir = path.join(__dirname, '../../../dist/css')
  const filesToCopy = ['fonts.css', 'icons.css', 'variables.css']

  filesToCopy.forEach((file) => {
    const srcPath = path.join(cssDir, file)
    const destPath = path.join(outputDir, file)
    if (fs.existsSync(srcPath)) {
      copyIfContentChanged(srcPath, destPath)
      console.log(`📋 복사: ${file}`)
    } else {
      console.warn(`⚠️ 파일 없음 (css 빌드 먼저 실행 필요): ${file}`)
    }
  })

  // 파일 저장 (콘텐츠 동일 시 write 스킵)
  writeIfContentChanged(path.join(outputDir, 'modes.css'), modesCSS)
  writeIfContentChanged(path.join(outputDir, 'themes.css'), themesCSS)
  writeIfContentChanged(path.join(outputDir, 'tokens.css'), tokensCSS)
  writeIfContentChanged(path.join(outputDir, 'theme.css'), themeCSS)
  writeIfContentChanged(path.join(outputDir, 'index.css'), indexCSS)

  console.log('✅ Tailwind v4 파일들이 생성되었습니다:')
  console.log(`📄 modes.css (${Math.round(modesCSS.length / 1024)}KB)`)
  console.log(`📄 themes.css (${Math.round(themesCSS.length / 1024)}KB)`)
  console.log(`📄 tokens.css (${Math.round(tokensCSS.length / 1024)}KB)`)
  console.log(`📄 theme.css (${Math.round(themeCSS.length / 1024)}KB) - @theme 블록`)
  console.log(`📄 index.css (${Math.round(indexCSS.length / 1024)}KB)`)
}

/**
 * modes.css 생성 (light/dark 모드)
 */
function generateModesCSS(baseFlat, modeFlat, modeTokensByMode, dimensionFlat) {
  let modesCSS = `/**
 * Design System Modes (Light/Dark) - Tailwind
 *
 * 사용법:
 * - 기본값: light 모드
 * - 다크 모드: document.documentElement.setAttribute('data-mode', 'dark')
 *
 * 생성 시간: ${new Date().toLocaleString('ko-KR')}
 */

/* 기본값 (Light 모드) */
:root,
:root[data-mode="light"] {
`

  Object.keys(baseFlat).forEach((key) => {
    if (!shouldExcludeFromTokensCSS(key)) {
      modesCSS += `  --${key}: ${baseFlat[key]};\n`
    }
  })
  Object.keys(modeFlat).forEach((key) => {
    if (!shouldExcludeFromTokensCSS(key)) {
      modesCSS += `  --${key}: ${modeFlat[key]};\n`
    }
  })
  if (modeTokensByMode?.light) {
    Object.keys(modeTokensByMode.light).forEach((key) => {
      if (!shouldExcludeFromTokensCSS(key)) {
        modesCSS += `  --${key}: ${modeTokensByMode.light[key]};\n`
      }
    })
  }
  Object.keys(dimensionFlat).forEach((key) => {
    if (!shouldExcludeFromTokensCSS(key)) {
      modesCSS += `  --${key}: ${dimensionFlat[key]};\n`
    }
  })

  modesCSS += `}

/* 다크 모드 */
:root[data-mode="dark"] {
`

  Object.keys(baseFlat).forEach((key) => {
    if (!shouldExcludeFromTokensCSS(key)) {
      modesCSS += `  --${key}: ${baseFlat[key]};\n`
    }
  })
  Object.keys(modeFlat).forEach((key) => {
    if (!shouldExcludeFromTokensCSS(key)) {
      modesCSS += `  --${key}: ${modeFlat[key]};\n`
    }
  })
  if (modeTokensByMode?.dark) {
    Object.keys(modeTokensByMode.dark).forEach((key) => {
      if (!shouldExcludeFromTokensCSS(key)) {
        modesCSS += `  --${key}: ${modeTokensByMode.dark[key]};\n`
      }
    })
  }
  Object.keys(dimensionFlat).forEach((key) => {
    if (!shouldExcludeFromTokensCSS(key)) {
      modesCSS += `  --${key}: ${dimensionFlat[key]};\n`
    }
  })

  modesCSS += `}
`
  return modesCSS
}

/**
 * themes.css 생성 (동적 테마)
 */
function generateThemesCSS(themeTokensByTheme, availableThemes) {
  const themesList = availableThemes.join('/')
  let themesCSS = `/**
 * Design System Themes (${themesList}) - Tailwind
 *
 * 사용법:
 * - 기본값: default 테마
 * - 테마 전환: document.documentElement.setAttribute('data-theme', '테마명')
 *
 * 생성 시간: ${new Date().toLocaleString('ko-KR')}
 */

/* 기본값 (Default 테마) */
:root,
:root[data-theme="default"] {
`

  if (themeTokensByTheme.default) {
    Object.keys(themeTokensByTheme.default).forEach((key) => {
      themesCSS += `  --${key}: ${themeTokensByTheme.default[key]};\n`
    })
  }
  themesCSS += `}
`

  availableThemes.forEach((theme) => {
    if (theme !== 'default') {
      themesCSS += `
/* ${theme} 테마 */
:root[data-theme="${theme}"] {
`
      if (themeTokensByTheme[theme]) {
        Object.keys(themeTokensByTheme[theme]).forEach((key) => {
          themesCSS += `  --${key}: ${themeTokensByTheme[theme][key]};\n`
        })
      }
      themesCSS += `}
`
    }
  })

  return themesCSS
}

/**
 * v4 네임스페이스와 이름이 다른 토큰 → 유틸리티를 만들 별칭 접두사.
 * 원본 변수는 그대로 두고 별칭이 var() 로 참조하므로 기존 출력은 바뀌지 않는다.
 */
const NAMESPACE_ALIASES = [
  ['z-kcds-', ['z-index-kcds-']],
  ['duration-kcds-', ['transition-duration-kcds-']],
  ['delay-kcds-', ['transition-delay-kcds-']],
  ['line-height-kcds-', ['leading-kcds-']],
  ['letter-spacing-kcds-', ['tracking-kcds-']],
  ['font-family-kcds-', ['font-kcds-']],
  ['size-kcds-', ['width-kcds-', 'height-kcds-']],
]

/** 출력된 토큰 중 별칭이 필요한 것을 찾아 `--별칭: var(--원본);` 줄을 만든다. */
function buildNamespaceAliases(categorized) {
  const lines = []
  for (const tokens of categorized.values()) {
    for (const tailwindKey of tokens.keys()) {
      const rule = NAMESPACE_ALIASES.find(([from]) => tailwindKey.startsWith(from))
      if (!rule) continue
      const [from, targets] = rule
      const name = tailwindKey.slice(from.length)
      for (const to of targets) {
        lines.push(`  --${to}${name}: var(--${tailwindKey});`)
      }
    }
  }
  return lines
}

/**
 * Tailwind CSS v4 @theme 블록 생성
 */
function generateTailwindThemeCSS(baseFlat, modeFlat, dimensionFlat) {
  const allTokens = { ...baseFlat, ...modeFlat, ...dimensionFlat }
  const categorized = categorizeTokensForTailwind(allTokens)
  const parts = []

  parts.push(`/**
 * KT Cloud Design System - Tailwind CSS v4 Theme
 *
 * 이 파일은 자동 생성되었습니다. 직접 수정하지 마세요.
 * 수정이 필요한 경우 tailwind-builder.js를 수정하세요.
 *
 * 생성 시간: ${new Date().toISOString()}
 *
 * 사용 예시:
 *   - 색상: text-kcds-text-primary, bg-kcds-bg-default
 *   - 상태 색상: text-kcds-status-negative-default, bg-kcds-status-positive-subtle
 *   - 간격: p-kcds-md, m-kcds-lg
 *   - 라운드: rounded-kcds-lg
 *   - 원시 색상: text-blue-500, bg-neutral-100
 */

@theme extend {`)

  const categoryOrder = [
    'Primitive Colors',
    'Font Family',
    'Font Size',
    'Font Weight',
    'Line Height',
    'Letter Spacing',
    'Primitive Size',
    'Primitive Border Radius',
    'Primitive Border Width',
    'Shadow',
    'Blur',
    'Opacity',
    'Z-Index',
    'Breakpoints',
    'Animation Duration',
    'Animation Easing',
    'Animation Delay',
    'KCDS Text Colors',
    'KCDS Background Colors',
    'KCDS Border Colors',
    'KCDS Icon Colors',
    'KCDS Status Colors',
    'KCDS Accent Colors',
    'KCDS Primary Colors',
    'KCDS Elevation Surface',
    'KCDS Elevation Shadow',
    'KCDS Z-Index',
    'KCDS Motion Duration',
    'KCDS Motion Easing',
    'KCDS Motion Delay',
    'KCDS Spacing',
    'KCDS Icon Size',
    'KCDS Border Radius',
    'KCDS Border Width',
    'KCDS Opacity',
    'KCDS Breakpoint',
  ]

  // 모든 토큰이 kcds- 네임스페이스를 가지므로 Tailwind 기본값과 충돌하지 않음
  let isPrimitiveSection = true
  parts.push('')
  parts.push('  /* ============================================================')
  parts.push('     PRIMITIVE TOKENS (원시 토큰)')
  parts.push('     ============================================================ */')

  for (const category of categoryOrder) {
    const tokens = categorized.get(category)
    if (!tokens || tokens.size === 0) continue

    if (category.startsWith('KCDS') && isPrimitiveSection) {
      isPrimitiveSection = false
      parts.push('')
      parts.push('  /* ============================================================')
      parts.push('     KCDS SEMANTIC TOKENS (시맨틱 토큰)')
      parts.push('     ============================================================ */')
    }

    parts.push('')
    parts.push(`  /* ---------- ${category} ---------- */`)
    for (const [tailwindKey, value] of tokens) {
      parts.push(`  --${tailwindKey}: ${sanitizeCSSValue(tailwindKey, value)};`)
    }
  }

  // 정의되지 않은 카테고리
  for (const [category, tokens] of categorized) {
    if (!categoryOrder.includes(category) && tokens.size > 0) {
      parts.push('')
      parts.push(`  /* ---------- ${category} (기타) ---------- */`)
      for (const [tailwindKey, value] of tokens) {
        parts.push(`  --${tailwindKey}: ${sanitizeCSSValue(tailwindKey, value)};`)
      }
    }
  }

  const aliasLines = buildNamespaceAliases(categorized)
  if (aliasLines.length > 0) {
    parts.push('')
    parts.push('  /* ============================================================')
    parts.push('     TAILWIND NAMESPACE ALIASES (유틸리티 생성용 별칭)')
    parts.push('     ============================================================ */')
    parts.push(...aliasLines)
  }

  parts.push('}')
  return parts.join('\n')
}

module.exports = { buildTailwind }
