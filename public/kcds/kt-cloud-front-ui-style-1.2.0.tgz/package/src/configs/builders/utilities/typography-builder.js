/**
 * Typography Utilities Builder
 *
 * tokens.json의 font.kcds 섹션을 파싱하여 Typography 유틸리티 클래스 생성
 * - heading (xl~3xs)
 * - paragraph (xl~sm × regular/medium/bold)
 * - label (xl~xs × regular/medium/bold)
 * - code (lg~md × regular/bold)
 * - numeric (sm~3xl × medium/bold)
 * - unit (xm~lg)
 */

/**
 * 토큰 참조를 CSS 변수명으로 변환
 * @param {string} value - 토큰 참조 (예: {base.font.family.sans})
 * @returns {string} - CSS 변수명 (예: var(--font-family-sans))
 */
function tokenRefToVar(value) {
  if (typeof value !== 'string') return value

  // {base.font.family.sans} -> font-family-sans
  if (value.startsWith('{') && value.endsWith('}')) {
    const refPath = value.slice(1, -1) // Remove { }
    // base.font.family.sans -> font-family-sans (base. 제거)
    const parts = refPath.replace(/^base\./, '').split('.')
    const varName = parts.join('-')
    return `var(--${varName})`
  }

  return value
}

/**
 * letterSpacing 값을 CSS 유효값으로 정규화
 * - 토큰 참조({...})는 CSS 변수로 변환
 * - Figma percent 단위(예: "0%", "2%")는 em으로 변환 (letter-spacing은 %를 허용하지 않음). 0은 다른 카테고리와 통일해 "0px"
 * - 그 외(px/em 등)는 원본 유지
 * @param {string} value - letterSpacing 원본 값
 * @returns {string} - 정규화된 CSS 값
 */
function normalizeLetterSpacing(value) {
  if (typeof value !== 'string') return value

  if (value.startsWith('{') && value.endsWith('}')) {
    return tokenRefToVar(value)
  }

  if (value.endsWith('%')) {
    const num = parseFloat(value)
    if (Number.isNaN(num) || num === 0) return '0px'
    return `${num / 100}em`
  }

  return value
}

/**
 * Typography 토큰에서 CSS 클래스 생성
 * @param {Object} typographyToken - typography $value 객체
 * @returns {Object} - CSS 속성 객체
 */
function parseTypographyToken(typographyToken) {
  const { fontFamily, fontWeight, fontSize, lineHeight, letterSpacing = '0px' } = typographyToken

  // fontWeight를 토큰으로 변환 (숫자 → CSS 변수)
  const fontWeightToken =
    typeof fontWeight === 'number' ? `var(--font-weight-${fontWeight})` : tokenRefToVar(fontWeight)

  // letterSpacing 정규화: 토큰 참조 → CSS 변수, percent(%) → em (0%는 다른 카테고리와 0px 통일)
  const letterSpacingToken = normalizeLetterSpacing(letterSpacing)

  return {
    fontFamily: tokenRefToVar(fontFamily),
    fontWeight: fontWeightToken,
    fontSize: tokenRefToVar(fontSize),
    lineHeight: tokenRefToVar(lineHeight),
    letterSpacing: letterSpacingToken,
  }
}

/**
 * CSS 클래스 문자열 생성
 * @param {string} className - 클래스명
 * @param {Object} styles - CSS 속성 객체
 * @returns {string} - CSS 클래스 문자열
 */
function generateCSSClass(className, styles) {
  const props = []
  if (styles.fontFamily) props.push(`font-family: ${styles.fontFamily};`)
  if (styles.fontWeight) props.push(`font-weight: ${styles.fontWeight};`)
  if (styles.fontSize) props.push(`font-size: ${styles.fontSize};`)
  if (styles.lineHeight) props.push(`line-height: ${styles.lineHeight};`)
  if (styles.letterSpacing) props.push(`letter-spacing: ${styles.letterSpacing};`)

  return `  .${className} {\n    ${props.join('\n    ')}\n  }`
}

/**
 * Typography 유틸리티 클래스 빌드
 * @param {Object} fontKcds - tokens.json의 font.kcds 섹션
 * @param {string} framework - 프레임워크 타입 (css, scss, tailwind)
 * @returns {string} - 생성된 CSS 문자열
 */
function buildTypographyClasses(fontKcds, framework = 'css') {
  const classes = []

  // Heading 클래스 생성 (7개)
  if (fontKcds.heading) {
    classes.push('\n  /* ━━━ Heading ━━━ */')
    const sizes = ['xl', 'lg', 'md', 'sm', 'xs', '2xs', '3xs']
    for (const size of sizes) {
      if (fontKcds.heading[size] && fontKcds.heading[size].$value) {
        const styles = parseTypographyToken(fontKcds.heading[size].$value)
        const className = `kcds-heading-${size}`
        classes.push(generateCSSClass(className, styles))
      }
    }
  }

  // Paragraph 클래스 생성 (12개: 4 sizes × 3 weights)
  if (fontKcds.paragraph) {
    classes.push('\n  /* ━━━ Paragraph ━━━ */')
    const sizes = ['xl', 'lg', 'md', 'sm']
    const weights = ['regular', 'medium', 'bold']
    for (const size of sizes) {
      if (fontKcds.paragraph[size]) {
        for (const weight of weights) {
          if (fontKcds.paragraph[size][weight] && fontKcds.paragraph[size][weight].$value) {
            const styles = parseTypographyToken(fontKcds.paragraph[size][weight].$value)
            const className = `kcds-paragraph-${size}-${weight}`
            classes.push(generateCSSClass(className, styles))
          }
        }
      }
    }
  }

  // Label 클래스 생성 (15개: 5 sizes × 3 weights)
  if (fontKcds.label) {
    classes.push('\n  /* ━━━ Label ━━━ */')
    const sizes = ['xl', 'lg', 'md', 'sm', 'xs']
    const weights = ['regular', 'medium', 'bold']
    for (const size of sizes) {
      if (fontKcds.label[size]) {
        for (const weight of weights) {
          if (fontKcds.label[size][weight] && fontKcds.label[size][weight].$value) {
            const styles = parseTypographyToken(fontKcds.label[size][weight].$value)
            const className = `kcds-label-${size}-${weight}`
            classes.push(generateCSSClass(className, styles))
          }
        }
      }
    }
  }

  // Code 클래스 생성 (4개: 2 sizes × 2 weights)
  if (fontKcds.code) {
    classes.push('\n  /* ━━━ Code ━━━ */')
    const sizes = ['lg', 'md']
    const weights = ['regular', 'bold']
    for (const size of sizes) {
      if (fontKcds.code[size]) {
        for (const weight of weights) {
          if (fontKcds.code[size][weight] && fontKcds.code[size][weight].$value) {
            const styles = parseTypographyToken(fontKcds.code[size][weight].$value)
            const className = `kcds-code-${size}-${weight}`
            classes.push(generateCSSClass(className, styles))
          }
        }
      }
    }
  }

  // Numeric 클래스 생성 (12개: 6 sizes × 2 weights)
  if (fontKcds.numeric) {
    classes.push('\n  /* ━━━ Numeric ━━━ */')
    const sizes = ['sm', 'md', 'lg', 'xl', '2xl', '3xl']
    const weights = ['medium', 'bold']
    for (const size of sizes) {
      if (fontKcds.numeric[size]) {
        for (const weight of weights) {
          if (fontKcds.numeric[size][weight] && fontKcds.numeric[size][weight].$value) {
            const styles = parseTypographyToken(fontKcds.numeric[size][weight].$value)
            const className = `kcds-numeric-${size}-${weight}`
            classes.push(generateCSSClass(className, styles))
          }
        }
      }
    }
  }

  // Unit 클래스 생성 (4개: xm/sm/md/lg, weight 단일)
  if (fontKcds.unit) {
    classes.push('\n  /* ━━━ Unit ━━━ */')
    const sizes = ['xm', 'sm', 'md', 'lg']
    for (const size of sizes) {
      if (fontKcds.unit[size] && fontKcds.unit[size].$value) {
        const styles = parseTypographyToken(fontKcds.unit[size].$value)
        const className = `kcds-unit-${size}`
        classes.push(generateCSSClass(className, styles))
      }
    }
  }

  // 프레임워크별 래핑
  const classesContent = classes.join('\n')

  if (framework === 'tailwind') {
    return `@layer utilities {\n${classesContent}\n}`
  }

  return `@layer utilities {\n${classesContent}\n}`
}

/**
 * SCSS mixin 생성
 * @param {Object} fontKcds - tokens.json의 font.kcds 섹션
 * @returns {string} - 생성된 SCSS 문자열
 */
function buildTypographySCSS(fontKcds) {
  const mixins = []
  const classes = []

  // Heading mixin & 클래스 생성
  if (fontKcds.heading) {
    mixins.push('\n// ━━━ Heading Mixins ━━━')
    const sizes = ['xl', 'lg', 'md', 'sm', 'xs', '2xs', '3xs']
    for (const size of sizes) {
      if (fontKcds.heading[size] && fontKcds.heading[size].$value) {
        const styles = parseTypographyToken(fontKcds.heading[size].$value)
        const mixinName = `heading-${size}`
        mixins.push(`@mixin ${mixinName} {
  font-family: ${styles.fontFamily};
  font-weight: ${styles.fontWeight};
  font-size: ${styles.fontSize};
  line-height: ${styles.lineHeight};
  letter-spacing: ${styles.letterSpacing};
}`)
        classes.push(`.kcds-heading-${size} { @include ${mixinName}; }`)
      }
    }
  }

  // Paragraph mixin & 클래스 생성
  if (fontKcds.paragraph) {
    mixins.push('\n// ━━━ Paragraph Mixins ━━━')
    const sizes = ['xl', 'lg', 'md', 'sm']
    const weights = ['regular', 'medium', 'bold']
    for (const size of sizes) {
      if (fontKcds.paragraph[size]) {
        for (const weight of weights) {
          if (fontKcds.paragraph[size][weight] && fontKcds.paragraph[size][weight].$value) {
            const styles = parseTypographyToken(fontKcds.paragraph[size][weight].$value)
            const mixinName = `paragraph-${size}-${weight}`
            mixins.push(`@mixin ${mixinName} {
  font-family: ${styles.fontFamily};
  font-weight: ${styles.fontWeight};
  font-size: ${styles.fontSize};
  line-height: ${styles.lineHeight};
  letter-spacing: ${styles.letterSpacing};
}`)
            classes.push(`.kcds-paragraph-${size}-${weight} { @include ${mixinName}; }`)
          }
        }
      }
    }
  }

  // Label mixin & 클래스 생성
  if (fontKcds.label) {
    mixins.push('\n// ━━━ Label Mixins ━━━')
    const sizes = ['xl', 'lg', 'md', 'sm', 'xs']
    const weights = ['regular', 'medium', 'bold']
    for (const size of sizes) {
      if (fontKcds.label[size]) {
        for (const weight of weights) {
          if (fontKcds.label[size][weight] && fontKcds.label[size][weight].$value) {
            const styles = parseTypographyToken(fontKcds.label[size][weight].$value)
            const mixinName = `label-${size}-${weight}`
            mixins.push(`@mixin ${mixinName} {
  font-family: ${styles.fontFamily};
  font-weight: ${styles.fontWeight};
  font-size: ${styles.fontSize};
  line-height: ${styles.lineHeight};
  letter-spacing: ${styles.letterSpacing};
}`)
            classes.push(`.kcds-label-${size}-${weight} { @include ${mixinName}; }`)
          }
        }
      }
    }
  }

  // Code mixin & 클래스 생성
  if (fontKcds.code) {
    mixins.push('\n// ━━━ Code Mixins ━━━')
    const sizes = ['lg', 'md']
    const weights = ['regular', 'bold']
    for (const size of sizes) {
      if (fontKcds.code[size]) {
        for (const weight of weights) {
          if (fontKcds.code[size][weight] && fontKcds.code[size][weight].$value) {
            const styles = parseTypographyToken(fontKcds.code[size][weight].$value)
            const mixinName = `code-${size}-${weight}`
            mixins.push(`@mixin ${mixinName} {
  font-family: ${styles.fontFamily};
  font-weight: ${styles.fontWeight};
  font-size: ${styles.fontSize};
  line-height: ${styles.lineHeight};
  letter-spacing: ${styles.letterSpacing};
}`)
            classes.push(`.kcds-code-${size}-${weight} { @include ${mixinName}; }`)
          }
        }
      }
    }
  }

  // Numeric mixin & 클래스 생성
  if (fontKcds.numeric) {
    mixins.push('\n// ━━━ Numeric Mixins ━━━')
    const sizes = ['sm', 'md', 'lg', 'xl', '2xl', '3xl']
    const weights = ['medium', 'bold']
    for (const size of sizes) {
      if (fontKcds.numeric[size]) {
        for (const weight of weights) {
          if (fontKcds.numeric[size][weight] && fontKcds.numeric[size][weight].$value) {
            const styles = parseTypographyToken(fontKcds.numeric[size][weight].$value)
            const mixinName = `numeric-${size}-${weight}`
            mixins.push(`@mixin ${mixinName} {
  font-family: ${styles.fontFamily};
  font-weight: ${styles.fontWeight};
  font-size: ${styles.fontSize};
  line-height: ${styles.lineHeight};
  letter-spacing: ${styles.letterSpacing};
}`)
            classes.push(`.kcds-numeric-${size}-${weight} { @include ${mixinName}; }`)
          }
        }
      }
    }
  }

  // Unit mixin & 클래스 생성
  if (fontKcds.unit) {
    mixins.push('\n// ━━━ Unit Mixins ━━━')
    const sizes = ['xm', 'sm', 'md', 'lg']
    for (const size of sizes) {
      if (fontKcds.unit[size] && fontKcds.unit[size].$value) {
        const styles = parseTypographyToken(fontKcds.unit[size].$value)
        const mixinName = `unit-${size}`
        mixins.push(`@mixin ${mixinName} {
  font-family: ${styles.fontFamily};
  font-weight: ${styles.fontWeight};
  font-size: ${styles.fontSize};
  line-height: ${styles.lineHeight};
  letter-spacing: ${styles.letterSpacing};
}`)
        classes.push(`.kcds-unit-${size} { @include ${mixinName}; }`)
      }
    }
  }

  return `/**
 * Typography Mixins & Utilities
 * Auto-generated from tokens.json
 */

${mixins.join('\n\n')}

// ━━━ Utility Classes ━━━
${classes.join('\n')}`
}

module.exports = {
  buildTypographyClasses,
  buildTypographySCSS,
  parseTypographyToken,
  tokenRefToVar,
}
