/**
 * Effects Utilities Builder
 *
 * tokens.json의 Effect-styles.kcds 섹션을 파싱하여 Effect 유틸리티 클래스 생성
 * - elevation.shadow (sm, md, lg)
 * - elevation.blur
 * - focusRing (sm, md)
 */

/**
 * 토큰 참조를 실제 값으로 변환
 * @param {string} value - 토큰 참조 또는 값
 * @param {Object} baseTokens - base 토큰 객체
 * @returns {string} - 실제 값
 */
function resolveTokenRef(value, baseTokens) {
  if (typeof value !== 'string') return value

  // {base.shadow.offset.0} -> 실제 값
  if (value.startsWith('{') && value.endsWith('}')) {
    const refPath = value.slice(1, -1) // Remove { }
    const parts = refPath.replace(/^base\./, '').split('.')

    let current = baseTokens
    for (const part of parts) {
      if (current && current[part]) {
        current = current[part]
      } else {
        console.warn(`Token reference not found: ${refPath}`)
        return '0'
      }
    }

    if (current && current.$value !== undefined) {
      return current.$value
    }

    return current || '0'
  }

  return value
}

/**
 * 색상 토큰 참조를 CSS 변수로 변환 (모드 전환 대응)
 *
 * shadow/focusRing 의 color 는 mode 토큰을 참조하므로, 실제 값으로 고정하지 않고
 * `var(--...)` 로 남겨 light/dark 모드 전환이 런타임에 반영되도록 한다.
 * 시맨틱 변수(`--kcds-*`)는 css/scss/tailwind 산출물에 동일하게 존재한다.
 *
 * @param {string} value - color 값 (토큰 참조 `{mode.kcds...}` 또는 hex 등 직접값)
 * @returns {string} - `var(--kcds-...)` 또는 원본 값
 * @example
 * colorRefToCssVar('{mode.kcds.elevation.shadow.subtle}') // 'var(--kcds-elevation-shadow-subtle)'
 * colorRefToCssVar('#1018280d') // '#1018280d'
 */
function colorRefToCssVar(value) {
  if (typeof value !== 'string') return value

  // 토큰 참조가 아니면(hex/rgba 등 직접값) 그대로 유지
  if (!value.startsWith('{') || !value.endsWith('}')) return value

  const varName = value
    .slice(1, -1) // { } 제거
    .replace(/^mode\./, '') // mode.kcds.elevation.shadow.subtle -> kcds.elevation.shadow.subtle
    .replace(/^base\./, '') // base.color.x -> color.x
    .replace(/\./g, '-')

  return `var(--${varName})`
}

/**
 * Shadow 토큰을 CSS box-shadow 값으로 변환
 * @param {Array} shadowLayers - shadow $value 배열
 * @param {Object} baseTokens - base 토큰 객체
 * @returns {string} - CSS box-shadow 값
 */
function parseShadowToken(shadowLayers, baseTokens) {
  if (!Array.isArray(shadowLayers)) return 'none'

  const shadows = shadowLayers.map((layer) => {
    const inset = layer.inset ? 'inset ' : ''
    const offsetX = resolveTokenRef(layer.offsetX, baseTokens) || '0'
    const offsetY = resolveTokenRef(layer.offsetY, baseTokens) || '0'
    const blur = layer.blur || '0'
    const spread = resolveTokenRef(layer.spread, baseTokens) || '0'
    const color = colorRefToCssVar(layer.color) || 'rgba(0, 0, 0, 0.1)'

    // 숫자만 있는 경우 px 추가
    const formatValue = (val) => {
      if (typeof val === 'number') return `${val}px`
      if (typeof val === 'string' && /^-?\d+$/.test(val)) return `${val}px`
      return val
    }

    return `${inset}${formatValue(offsetX)} ${formatValue(offsetY)} ${blur} ${formatValue(spread)} ${color}`
  })

  return shadows.join(', ')
}

/**
 * Blur 토큰을 CSS backdrop-filter 값으로 변환
 * @param {Object} blurToken - blur $value 객체
 * @param {Object} baseTokens - base 토큰 객체
 * @returns {string} - CSS backdrop-filter 값
 */
function parseBlurToken(blurToken, baseTokens) {
  if (!blurToken || !blurToken.blur) return 'blur(0)'

  const blurValue = resolveTokenRef(blurToken.blur, baseTokens)
  if (typeof blurValue === 'number') {
    return `blur(${blurValue}px)`
  }

  // CSS 변수 참조인 경우
  if (blurValue && blurValue.startsWith('{')) {
    const refPath = blurValue
      .slice(1, -1)
      .replace(/^base\./, '')
      .split('.')
      .join('-')
    return `blur(var(--${refPath}))`
  }

  return `blur(${blurValue})`
}

/**
 * CSS 클래스 문자열 생성
 * @param {string} className - 클래스명
 * @param {string} property - CSS 속성명
 * @param {string} value - CSS 값
 * @returns {string} - CSS 클래스 문자열
 */
function generateCSSClass(className, property, value) {
  return `  .${className} {\n    ${property}: ${value};\n  }`
}

/**
 * Effects 유틸리티 클래스 빌드
 * @param {Object} effectStyles - tokens.json의 Effect-styles.kcds 섹션
 * @param {Object} baseTokens - tokens.json의 base 섹션
 * @param {string} framework - 프레임워크 타입 (css, scss, tailwind)
 * @returns {string} - 생성된 CSS 문자열
 */
function buildEffectsClasses(effectStyles, baseTokens, framework = 'css') {
  const classes = []

  // Shadow 클래스 생성
  if (effectStyles.elevation && effectStyles.elevation.shadow) {
    classes.push('\n  /* ━━━ Shadow ━━━ */')
    const shadowTokens = effectStyles.elevation.shadow
    const sizes = ['sm', 'md', 'lg', 'xl']

    for (const size of sizes) {
      if (shadowTokens[size] && shadowTokens[size].$value) {
        const shadowValue = parseShadowToken(shadowTokens[size].$value, baseTokens)
        const className = `kcds-shadow-${size}`
        classes.push(generateCSSClass(className, 'box-shadow', shadowValue))
      }
    }
  }

  // Focus Ring 클래스 생성
  if (effectStyles.focusRing) {
    classes.push('\n  /* ━━━ Focus Ring ━━━ */')
    const focusRingTokens = effectStyles.focusRing
    const sizes = ['md', 'sm']

    for (const size of sizes) {
      if (focusRingTokens[size] && focusRingTokens[size].$value) {
        const shadowValue = parseShadowToken(focusRingTokens[size].$value, baseTokens)
        const className = `kcds-focus-ring-${size}`
        classes.push(generateCSSClass(className, 'box-shadow', shadowValue))
      }
    }
  }

  // Blur 클래스 생성
  if (effectStyles.elevation && effectStyles.elevation.blur) {
    classes.push('\n  /* ━━━ Blur ━━━ */')
    const blurToken = effectStyles.elevation.blur
    if (blurToken.$value) {
      const blurValue = parseBlurToken(blurToken.$value, baseTokens)
      classes.push(generateCSSClass('kcds-blur-background', 'backdrop-filter', blurValue))
    }
  }

  // 프레임워크별 래핑
  const classesContent = classes.join('\n')

  if (framework === 'tailwind') {
    return `@layer utilities {\n${classesContent}\n}`
  }

  return `@layer utilities {\n${classesContent}\n}`
}

/**
 * SCSS mixin 생성
 * @param {Object} effectStyles - tokens.json의 Effect-styles.kcds 섹션
 * @param {Object} baseTokens - tokens.json의 base 섹션
 * @returns {string} - 생성된 SCSS 문자열
 */
function buildEffectsSCSS(effectStyles, baseTokens) {
  const mixins = []
  const classes = []

  // Shadow mixin & 클래스 생성
  if (effectStyles.elevation && effectStyles.elevation.shadow) {
    mixins.push('\n// ━━━ Shadow Mixins ━━━')
    const shadowTokens = effectStyles.elevation.shadow
    const sizes = ['sm', 'md', 'lg', 'xl']

    for (const size of sizes) {
      if (shadowTokens[size] && shadowTokens[size].$value) {
        const shadowValue = parseShadowToken(shadowTokens[size].$value, baseTokens)
        const mixinName = `shadow-${size}`
        mixins.push(`@mixin ${mixinName} {\n  box-shadow: ${shadowValue};\n}`)
        classes.push(`.kcds-shadow-${size} { @include ${mixinName}; }`)
      }
    }
  }

  // Focus Ring mixin & 클래스 생성
  if (effectStyles.focusRing) {
    mixins.push('\n// ━━━ Focus Ring Mixins ━━━')
    const focusRingTokens = effectStyles.focusRing
    const sizes = ['md', 'sm']

    for (const size of sizes) {
      if (focusRingTokens[size] && focusRingTokens[size].$value) {
        const shadowValue = parseShadowToken(focusRingTokens[size].$value, baseTokens)
        const mixinName = `focus-ring-${size}`
        mixins.push(`@mixin ${mixinName} {\n  box-shadow: ${shadowValue};\n}`)
        classes.push(`.kcds-focus-ring-${size} { @include ${mixinName}; }`)
      }
    }
  }

  // Blur mixin & 클래스 생성
  if (effectStyles.elevation && effectStyles.elevation.blur) {
    mixins.push('\n// ━━━ Blur Mixins ━━━')
    const blurToken = effectStyles.elevation.blur
    if (blurToken.$value) {
      const blurValue = parseBlurToken(blurToken.$value, baseTokens)
      mixins.push(`@mixin blur-background {\n  backdrop-filter: ${blurValue};\n}`)
      classes.push(`.kcds-blur-background { @include blur-background; }`)
    }
  }

  return `/**
 * Effects Mixins & Utilities
 * Auto-generated from tokens.json
 */

${mixins.join('\n\n')}

// ━━━ Utility Classes ━━━
${classes.join('\n')}`
}

module.exports = {
  buildEffectsClasses,
  buildEffectsSCSS,
  parseShadowToken,
  parseBlurToken,
  resolveTokenRef,
}
