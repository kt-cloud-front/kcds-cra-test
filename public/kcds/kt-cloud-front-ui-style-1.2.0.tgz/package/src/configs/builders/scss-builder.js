/**
 * SCSS Builder - 하이브리드 레이어링 방식
 *
 * 이 모듈은 SCSS 파일 생성을 담당합니다.
 * _modes.scss, _themes.scss, _tokens.scss를 생성합니다.
 */

const fs = require('fs')
const path = require('path')

const { writeIfContentChanged } = require('../write-if-changed')

/**
 * SCSS 빌드 함수
 * @param {Object} tokens - 플랫한 토큰 객체들
 * @param {Object} config - 빌드 설정
 */
function buildSCSS(tokens, config) {
  const {
    baseFlat,
    themeFlat,
    modeFlat,
    dimensionFlat,
    themeTokensByTheme,
    modeTokensByMode,
    useDTCGKeys,
    colorMode,
    variableCollections,
    availableThemes,
    tokensData,
  } = tokens
  const outputDir = path.join(__dirname, '../../../dist/scss')

  // 출력 디렉토리 생성
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true })
  }

  // 1. _modes.scss 생성 (light/dark 모드)
  let modesSCSS = `/**
 * ========================================
 * Design System Modes (Light/Dark) - SCSS
 * ========================================
 * 
 * 이 파일은 라이트/다크 모드별 SCSS 변수를 정의합니다.
 * 
 * 🎯 사용법:
 * - 기본값: light 모드
 * - 다크 모드: @import 'modes'; 후 [data-mode="dark"] 사용
 * 
 * 📁 파일 위치: @kt-cloud-front/ui-style/dist/scss/_modes.scss
 * 📅 생성 시간: ${new Date().toLocaleString('ko-KR')}
 * ========================================
 */

/* 기본값 (Light 모드) */
:root,
:root[data-mode="light"] {
`

  // 기본 토큰들 추가 (base + mode + dimension light 모드)
  Object.keys(baseFlat).forEach((key) => {
    modesSCSS += `  --${key}: ${baseFlat[key]};\n`
  })

  // mode 토큰들 추가 (light 모드)
  Object.keys(modeFlat).forEach((key) => {
    modesSCSS += `  --${key}: ${modeFlat[key]};\n`
  })

  // 모드별 토큰들 추가 (light 모드)
  if (modeTokensByMode && modeTokensByMode.light) {
    Object.keys(modeTokensByMode.light).forEach((key) => {
      modesSCSS += `  --${key}: ${modeTokensByMode.light[key]};\n`
    })
  }

  // dimension 토큰들 추가 (light 모드)
  Object.keys(dimensionFlat).forEach((key) => {
    modesSCSS += `  --${key}: ${dimensionFlat[key]};\n`
  })

  modesSCSS += `}

/* 다크 모드 */
:root[data-mode="dark"] {
`

  // 다크 모드 토큰들 추가 (base + mode + dimension dark 모드)
  Object.keys(baseFlat).forEach((key) => {
    modesSCSS += `  --${key}: ${baseFlat[key]};\n`
  })

  // mode 토큰들 추가 (dark 모드)
  Object.keys(modeFlat).forEach((key) => {
    modesSCSS += `  --${key}: ${modeFlat[key]};\n`
  })

  // 모드별 토큰들 추가 (dark 모드)
  if (modeTokensByMode && modeTokensByMode.dark) {
    Object.keys(modeTokensByMode.dark).forEach((key) => {
      modesSCSS += `  --${key}: ${modeTokensByMode.dark[key]};\n`
    })
  }

  // dimension 토큰들 추가 (dark 모드)
  Object.keys(dimensionFlat).forEach((key) => {
    modesSCSS += `  --${key}: ${dimensionFlat[key]};\n`
  })

  modesSCSS += `}
`

  // 2. _themes.scss 생성 (동적 테마 처리)
  const themesList = availableThemes.join('/')
  let themesSCSS = `/**
   * ========================================
   * Design System Themes (${themesList}) - SCSS
   * ========================================
   * 
   * 이 파일은 테마별 SCSS 변수를 정의합니다.
   * 
   * 🎯 사용법:
   * - 기본값: default 테마
   * - 테마 전환: @import 'themes'; 후 [data-theme="테마명"] 사용
   * 
   * 📁 파일 위치: @kt-cloud-front/ui-style/dist/scss/_themes.scss
   * 📅 생성 시간: ${new Date().toLocaleString('ko-KR')}
   * ========================================
   */

/* 기본값 (Default 테마) */
:root,
:root[data-theme="default"] {
`

  // Default 테마 토큰들 추가
  if (themeTokensByTheme.default) {
    Object.keys(themeTokensByTheme.default).forEach((key) => {
      themesSCSS += `  --${key}: ${themeTokensByTheme.default[key]};\n`
    })
  }

  themesSCSS += `}
`

  // 각 테마별 SCSS 생성
  availableThemes.forEach((theme) => {
    if (theme !== 'default') {
      themesSCSS += `
/* ${theme} 테마 */
:root[data-theme="${theme}"] {
`

      // 테마별 토큰 사용
      if (themeTokensByTheme[theme]) {
        Object.keys(themeTokensByTheme[theme]).forEach((key) => {
          themesSCSS += `  --${key}: ${themeTokensByTheme[theme][key]};\n`
        })
      }

      themesSCSS += `}
`
    }
  })

  // 3. tokens.scss 생성 (통합 파일)
  const themesListForTokens = availableThemes.join(' | ')
  let tokensSCSS = `/**
   * ========================================
   * Design System Tokens - SCSS (통합)
   * ========================================
   * 
   * 이 파일은 모든 디자인 토큰을 포함하는 통합 SCSS 파일입니다.
   * 
   * 🎯 사용법:
   * - 모드 전환: data-mode="light" | "dark"
   * - 테마 전환: data-theme="${themesListForTokens}"
   * 
   * 📁 파일 위치: @kt-cloud-front/ui-style/dist/scss/tokens.scss
   * 📅 생성 시간: ${new Date().toLocaleString('ko-KR')}
   * ========================================
   */

${modesSCSS.replace(/\/\*\*[\s\S]*?\*\//, '/* Modes SCSS */')}

${themesSCSS.replace(/\/\*\*[\s\S]*?\*\//, '/* Themes SCSS */')}
`

  // 4. index.scss (진입점)
  // 이 파일이 dist/scss/index.scss의 단일 소스입니다.
  // src/configs/formats/scss/에는 _base.scss, _helpers.scss 등 정적 파일만 존재합니다.
  let indexSCSS = `/**
 * @kt-cloud-front/ui-style SCSS Framework
 *
 * 이 파일은 빌드 스크립트(scss-builder.js)에 의해 자동 생성됩니다.
 * 직접 수정하지 마세요.
 *
 * 🎯 사용법:
 * - @import '@kt-cloud-front/ui-style/scss'
 *
 * 생성 시간: ${new Date().toLocaleString('ko-KR')}
 */

@forward './tokens';
@forward '_variables';
@forward '_mixins';
@forward '_fonts';
@forward '_icons';
@forward '_base';
@forward '_helpers';
@forward '_utilities';
`

  // 파일들 저장
  // 콘텐츠 동일 시 write 스킵
  writeIfContentChanged(path.join(outputDir, '_modes.scss'), modesSCSS)
  writeIfContentChanged(path.join(outputDir, '_themes.scss'), themesSCSS)
  writeIfContentChanged(path.join(outputDir, 'tokens.scss'), tokensSCSS)
  writeIfContentChanged(path.join(outputDir, 'index.scss'), indexSCSS)

  console.log('✅ SCSS 파일들이 생성되었습니다:')
  console.log(`📄 _modes.scss (${Math.round(modesSCSS.length / 1024)}KB)`)
  console.log(`📄 _themes.scss (${Math.round(themesSCSS.length / 1024)}KB)`)
  console.log(`📄 tokens.scss (${Math.round(tokensSCSS.length / 1024)}KB)`)
  console.log(`📄 index.scss (${Math.round(indexSCSS.length / 1024)}KB)`)
}

module.exports = { buildSCSS }
