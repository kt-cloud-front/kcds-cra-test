# @kt-cloud-front/ui-react-grid

## 1.2.0

### Minor Changes

- **마이너 릴리즈**: 디자인 시스템 1.2.0 버전 업데이트

  #### ✨ 신규 기능
  - **레이아웃 킷 정식 출시**: 콘솔 화면을 셸·페이지·프리미티브 3계층으로 짜는 레이아웃 킷을 정식 배포. 스타일 엔트리(`dist/styles`)가 함께 배포되어 외부 프로젝트에서 바로 사용 가능
    - **shell**(`@kt-cloud-front/ui-react/shell`) — `SShell`·`SShellHeader`·`SShellLnb`·`SShellBody`·`SShellFooter`: 앱 프레임(GNB·LNB·Footer·거터), 앱에 한 번만 사용
    - **page**(`@kt-cloud-front/ui-react/page`) — `SPageArea`·`SPageMain`·`SPageSide`·`SPageBar`·`SPageBody`: `SShellBody` 안쪽 콘텐츠 배치, 라우트마다 사용
    - **primitives**(`@kt-cloud-front/ui-react/primitives`) — `SBox`·`SCenter`·`SContainer`·`SFlex`·`SGrid`·`SStack`(`SVStack`·`SHStack` 프리셋 포함): 위젯 내부 배치 도구, 어디서나 사용
    - 그룹 단위 서브패스로만 import(최상위 배럴 미노출)
    - ([1a9cb4ccd](https://github.com/kt-cloud-platform/front/commit/1a9cb4ccdfb7ea1a22e7051b9d0145cda49e46b2), [80e410983](https://github.com/kt-cloud-platform/front/commit/80e410983933df2586e65e589320aad95141461b), [d51991f39](https://github.com/kt-cloud-platform/front/commit/d51991f3945d931abb13852ea33e042961789242)) @dhoh-ktc
  - **연구소 컴포넌트 8종 정식 승격**: `SCalendar`·`SDatePicker`·`SDateRangePicker`·`SDateTimePicker`·`SDateTimeRangePicker`·`STimePicker`·`SPopover`·`SValidationMessage` 의 experimental 표기를 떼고 사용 문서를 추가. 캘린더·피커는 Storybook `Forms` 카테고리로 이동
    - ([c4988673d](https://github.com/kt-cloud-platform/front/commit/c4988673dae3b36ca914613bf7c85400e772c5bb), [3114e5b6b](https://github.com/kt-cloud-platform/front/commit/3114e5b6b3f9eed6791676826100a7911df6e87d)) @ktc-stephen-k
  - **SDrawer**: 본문 옆에 붙는 인라인 드로어를 추가. `mode="overlay"` 로 본문 위에 띄울 수도 있음 (`SDrawerHeader`·`SDrawerTitle`·`SDrawerBody`·`SDrawerAction`·`SDrawerClose`, `useSDrawerContext`·`useSDrawerMode`)
    - ([9df2c42d5](https://github.com/kt-cloud-platform/front/commit/9df2c42d580e10cb1a9890da07e199201c6fe3e2), [0d67506d4](https://github.com/kt-cloud-platform/front/commit/0d67506d453c4c12d1cc45b05b69d455a77aa9c9)) @dhoh-ktc
  - **파일 업로드 세트**(`@kt-cloud-front/ui-react/file-upload`): `SFileUpload`·`SFilePicker`·`SFileList`·`SFileItem`·`SDropzone`·`SFileDropTextarea` 추가. 서브패스로만 import(최상위 배럴 미노출)
    - ([0138c50e7](https://github.com/kt-cloud-platform/front/commit/0138c50e7c5f7b8920711500886bbc087c4963da), [d49843a20](https://github.com/kt-cloud-platform/front/commit/d49843a20e09b981d4bd71c733e7dc9949c35017), [f2fb71ffc](https://github.com/kt-cloud-platform/front/commit/f2fb71ffc700c1d1f9ecc9a18674078626661668)) @dhoh-ktc
  - **SCreateWizard**(`@kt-cloud-front/ui-react/create-wizard`, experimental): 생성·설정 화면용 위저드. 스텝별 보조 컬럼 섹션(`SCreateWizardSide`), 앞 스텝부터 검증하고 실패한 스텝으로 되돌리는 흐름, `useSCreateWizard` 훅 제공. 서브패스로만 import
    - ([9c8358ff9](https://github.com/kt-cloud-platform/front/commit/9c8358ff9bb194544c72f2aadeb666e327ee5765), [66d2b8dcc](https://github.com/kt-cloud-platform/front/commit/66d2b8dcc9d4cec67e73dcad07d66ae73c69bab9), [e9eeedeba](https://github.com/kt-cloud-platform/front/commit/e9eeedebadf69f6942f98ce5ce5d86e6a57e396e), [3bb6522f3](https://github.com/kt-cloud-platform/front/commit/3bb6522f3518d1804141e5137fdf27b1ac6d9e09), [c487fc97e](https://github.com/kt-cloud-platform/front/commit/c487fc97e9312ececd048574b47738e0440d3777)) @dhoh-ktc
  - **SValidationMessage**: 필드 밖에서도 쓸 수 있는 단독 컴포넌트로 분리(`@kt-cloud-front/ui-react/validation-message`), `status="neutral"` 추가. 기존 루트 import 는 그대로 동작
    - ([6ddfb102e](https://github.com/kt-cloud-platform/front/commit/6ddfb102e152b4cde5081cc3b2e42fd8f632052a)) @ktc-stephen-k
  - **Data Grid**: 칼럼 필터 서버 모드, 칼럼 정렬(`meta.align`), 칼럼 정의에서 행·셀 값 타입을 추론하는 `defineColumn` 추가
    - ([6a6bccf89](https://github.com/kt-cloud-platform/front/commit/6a6bccf89085b3680825fba81110f121053e49fe), [bf3b5f8a4](https://github.com/kt-cloud-platform/front/commit/bf3b5f8a4a2fa838d2150b66610b361b36db976e), [24d12fe6f](https://github.com/kt-cloud-platform/front/commit/24d12fe6f572c98d916ecaf88d69ddebe2aba689), [5c0d4c7e2](https://github.com/kt-cloud-platform/front/commit/5c0d4c7e2b33666a2e2d82379eb6e3cb54ad49f1)) @nspark, @dhoh-ktc

  #### 🚀 주요 개선
  - **레이아웃 킷 옵션**: `SPageArea` `type`(`card`/`clear`)·`scroll`(`body`/`page`, 기본 `body`) 추가, `SPageBody` `fill`·`fluid`·`flush` 추가, `SPageBar` `divider` 추가, `SShellBody` `contentClassName` 추가. 스크롤 영역을 셸 슬롯이 갖도록 정리하고 여백을 KCP Console UX Guide 에 맞춤
    - ([b3e3fee7f](https://github.com/kt-cloud-platform/front/commit/b3e3fee7f7d080bf4b1f50ea7baf6cfba958a4a8), [652dddc91](https://github.com/kt-cloud-platform/front/commit/652dddc9120fb818da2b46b5bba1dad67352bece), [aef58f650](https://github.com/kt-cloud-platform/front/commit/aef58f65034114502a93098fe2064cee2346247b), [d84b1c27f](https://github.com/kt-cloud-platform/front/commit/d84b1c27ff07023d3ee03443c6d30fdc8166d66d), [4e8220740](https://github.com/kt-cloud-platform/front/commit/4e8220740b45c588f1caf2f4ed4a7eba5dfde2b6), [b63ccb0eb](https://github.com/kt-cloud-platform/front/commit/b63ccb0eb155b4f4b685bc6bdc1046c077a31351), [1a9cb4ccd](https://github.com/kt-cloud-platform/front/commit/1a9cb4ccdfb7ea1a22e7051b9d0145cda49e46b2), [80e410983](https://github.com/kt-cloud-platform/front/commit/80e410983933df2586e65e589320aad95141461b)) @dhoh-ktc
  - **STabs**: `variant="filled"` 추가(`constrained` deprecated), 스타일을 컴포넌트 자체 Tailwind 클래스로 전환
    - ([eb9c92c27](https://github.com/kt-cloud-platform/front/commit/eb9c92c276f2a011329e7451a54b6efef2368ea5), [5d8fe31be](https://github.com/kt-cloud-platform/front/commit/5d8fe31be08ea6543e98689d4a9321b3707fd7b4)) @dhoh-ktc
  - **SScrollArea / 스크롤바**: KCDS 스크롤바 스펙(두께 4px, 트랙 투명) 적용, 썸 길이가 콘텐츠 비율을 따르도록 수정. `SScrollAreaScrollbar` 는 자식이 없으면 썸을 직접 그림
    - ([985f2784f](https://github.com/kt-cloud-platform/front/commit/985f2784f6acfe5d9a412ac724d8868b81d12228), [cee2f6b0b](https://github.com/kt-cloud-platform/front/commit/cee2f6b0b4e45944a5cbe8ba8bbef808c9b37364), [9a7507178](https://github.com/kt-cloud-platform/front/commit/9a750717865c5e17180e361e739fc041d626330e), [49695bf0b](https://github.com/kt-cloud-platform/front/commit/49695bf0b20a7985d2dc52f0b2112d5a4f741c08), [654793043](https://github.com/kt-cloud-platform/front/commit/654793043bdefdd750f334ffe805a8cf62d92b8a)) @dhoh-ktc
  - **SStatus**: `status="in-progress"`·`pending`·`neutral` 추가(`in-active`·`ready` deprecated)
    - ([76ceab1c4](https://github.com/kt-cloud-platform/front/commit/76ceab1c453e849b02263770bb265b38383c1238)) @ktc-stephen-k
  - **SDropdownMenu**: 트리거 슬롯(`SDropdownMenuTriggerPrefixSlot`·`SDropdownMenuTriggerSuffixSlot`) 추가, 트리거·항목 간격과 눌림 배경 토큰 조정
    - ([6d7d93d94](https://github.com/kt-cloud-platform/front/commit/6d7d93d940ac812097899ff7e004d25aad3186d2)) @ktc-stephen-k
  - **SSelect**: `noData` 에 노드 전달 허용, `filterOption` 추가, 배경을 스크롤하면 드롭다운이 닫힘
    - ([dc7056946](https://github.com/kt-cloud-platform/front/commit/dc70569468e2d8a3e4c7f511f2339386b799ddb9), [6ffb7263f](https://github.com/kt-cloud-platform/front/commit/6ffb7263fec4a238d342a7d31e11d94d3d0e72a4)) @dhoh-ktc, @ktc-stephen-k
  - **STextButton**: `appearance="static"` 추가
    - ([2fcd20a12](https://github.com/kt-cloud-platform/front/commit/2fcd20a122b13ffedc16b806b247367d5135c139)) @ktc-stephen-k
  - **cn 유틸리티**: KCDS 토큰 클래스(색·간격 등)를 속성별로 병합
    - ([4d243ae7c](https://github.com/kt-cloud-platform/front/commit/4d243ae7c2f31afab42a459ef2128bc6e27c3101), [028a022b9](https://github.com/kt-cloud-platform/front/commit/028a022b91500d07974fd1629d7c93986da71bb7)) @dhoh-ktc
  - **디자인 토큰**: Tailwind v4 네임스페이스 별칭 추가, 아이콘 accent 컬러 참조값 수정
    - ([d640a20b6](https://github.com/kt-cloud-platform/front/commit/d640a20b60e00a3ec90208cb4476fe359989c5ae), [384eb2c6b](https://github.com/kt-cloud-platform/front/commit/384eb2c6b8731beacb033eb9c315a774e027ca64)) @dhoh-ktc, @ktc-stephen-k

  #### 🐛 버그 수정
  - **SPopover / SDropdownMenu**: `collisionBoundary` 가 props 스프레드에 덮이던 문제 수정
    - ([386b2b61f](https://github.com/kt-cloud-platform/front/commit/386b2b61fa7b0dcd0b1ea04224b1ea8de1da587a)) @ktc-stephen-k
  - **SSelect**: 오버레이 안에서 옵션 목록이 모달 경계에 갇히던 문제 수정
    - ([ab1d2990b](https://github.com/kt-cloud-platform/front/commit/ab1d2990b373ba5ae14c2e850c7e89c9e407cdf4)) @ktc-stephen-k
  - **SRadioGroup**: indicator 점 위치가 어긋나던 문제 수정
    - ([f42928348](https://github.com/kt-cloud-platform/front/commit/f42928348135bc2201a49f0e27d7994d35e44999)) @ktc-stephen-k
  - **SCheckbox**: `id` 를 주지 않아도 라벨이 체크박스와 연결되도록 id 를 자동 생성
    - ([b00d92e48](https://github.com/kt-cloud-platform/front/commit/b00d92e485950120922212580a8d7c1fae349786)) @dhoh-ktc
  - **SRadioGroup**: 항목 id 를 값(`radio-<값>`) 대신 고유 id 로 생성 — 같은 값을 쓰는 다른 그룹과 id 가 겹치지 않음. `radio-<값>` id 에 의존하던 코드는 `id` 를 직접 지정하세요
    - ([2efeef293](https://github.com/kt-cloud-platform/front/commit/2efeef293b9fd13d29bcaf044cb2794b53184640)) @dhoh-ktc
  - **SCheckbox / SRadioGroup / SSelect**: `status="danger"` 일 때 `aria-invalid` 를 지정 — 검증 실패 필드로 포커스 이동 가능
    - ([b00d92e48](https://github.com/kt-cloud-platform/front/commit/b00d92e485950120922212580a8d7c1fae349786)) @dhoh-ktc
  - **STable**: 행간을 간격 토큰 대신 행간 토큰으로 지정
    - ([89546feca](https://github.com/kt-cloud-platform/front/commit/89546feca1174f3d7c7d305efd45d79208d7ce73)) @dhoh-ktc
  - **SDrawer**: `SDrawerBody` 본문 기본 글자 스타일이 적용되지 않던 문제 수정 — `paragraph/md/regular`(14px / 20px) 적용
    - ([03513a433](https://github.com/kt-cloud-platform/front/commit/03513a433e4c0297f99598af8be1441257685360)) @ktc-stephen-k
  - **레이아웃 킷**: `SPageBody`·`SShellBody` 안에서 자식이 눌려 겹치거나 거터가 사라지던 문제 수정
    - ([d4a075576](https://github.com/kt-cloud-platform/front/commit/d4a075576662a2490c1919c61f4abb5fdc9fbd44), [b2b3ab1b7](https://github.com/kt-cloud-platform/front/commit/b2b3ab1b7fff5de51991c9d13b60f52256aba54f)) @dhoh-ktc
  - **레이아웃 킷**: 페이지 카드 표면을 테두리에서 그림자로 변경, 콘텐츠 바깥 거터를 스펙에 맞춰 조정, 카드가 브라우저 폭을 따라 줄고 가로 스크롤은 카드 안에서 생기도록 수정
    - ([2203b0d90](https://github.com/kt-cloud-platform/front/commit/2203b0d9007fd8309d4170fdb3481d93f2b976cc), [2d20143dc](https://github.com/kt-cloud-platform/front/commit/2d20143dc6ce99184b06344dd89fc440a275fc53), [cc5ec7ea4](https://github.com/kt-cloud-platform/front/commit/cc5ec7ea4ea1675a8d804c2394969a1c3b837642), [a86ccef21](https://github.com/kt-cloud-platform/front/commit/a86ccef2180b9a960a5de5de740a0478203f55a1)) @dhoh-ktc
  - **SInlineNotification**: 닫기 버튼이 없을 때 오른쪽에 남던 빈 여백 제거
    - ([f1812897b](https://github.com/kt-cloud-platform/front/commit/f1812897b5cf871652aad42dbdb39d2919b9fc12)) @dhoh-ktc
  - **Data Grid**: 막대·툴바가 넘칠 때 잘리던 문제와 세로 스크롤이 사라지던 문제 수정, 페이지네이션을 표 바로 아래에 배치
    - ([125a225b2](https://github.com/kt-cloud-platform/front/commit/125a225b2e6a72bd4e2a7f572f55f40beef0a619), [792b5545b](https://github.com/kt-cloud-platform/front/commit/792b5545b6f151b275dfc8a96d38eb11d29a3499), [1494afcfd](https://github.com/kt-cloud-platform/front/commit/1494afcfd458628f1a72d461ac0953993963ee18)) @dhoh-ktc

  #### ⚠️ 호환성 변경
  - **`@kt-cloud-front/ui-core-react` 의 `CScrollArea`·`CTabs` 계열 제거**: `CScrollArea`·`CScrollAreaViewport`·`CScrollAreaScrollbar`·`CScrollAreaThumb`·`CScrollAreaCorner`, `CTabs`·`CTabsList`·`CTabsTrigger`·`CTabsContent` 와 `@kt-cloud-front/ui-style-react` 의 `scroll-area.css`·`tabs.css`(`kcds-scroll-area-*`·`kcds-tabs-*` 클래스)를 제거. `@kt-cloud-front/ui-react` 의 `SScrollArea`·`STabs` 계열로 대체하세요
    - ([49695bf0b](https://github.com/kt-cloud-platform/front/commit/49695bf0b20a7985d2dc52f0b2112d5a4f741c08), [5d8fe31be](https://github.com/kt-cloud-platform/front/commit/5d8fe31be08ea6543e98689d4a9321b3707fd7b4)) @dhoh-ktc
  - **`SVerticalNavigationMenuProvider` 가 DOM 을 렌더하지 않음**: `kcds-vertical-navigation-layout` div 를 더 이상 그리지 않고 `ref`·HTML 속성도 받지 않습니다. 화면 골격은 `SShell`(`@kt-cloud-front/ui-react/shell`)로 배치하세요
    - ([3ea11247e](https://github.com/kt-cloud-platform/front/commit/3ea11247ea8fba815f4b6167250ed05f74962d55)) @dhoh-ktc

  #### 📌 참고 (하위호환 유지되는 Deprecated)
  - `SAccordion`·`CAccordion` `orientation` → deprecated. 세로 배치만 지원하므로 넘겨도 동작이 같습니다. 넘기던 곳에서는 prop 을 지우세요
  - `STabs` `variant="constrained"` → `variant="filled"`
  - `SStatus` `status="in-active"` → `status="pending"`, `status="ready"` → `status="neutral"`
  - 위 항목의 기존 prop 은 그대로 동작합니다

- Updated dependencies
  - @kt-cloud-front/ui-react@1.2.0

## 1.1.0

### Minor Changes

- **마이너 릴리즈**: 디자인 시스템 1.1.0 버전 업데이트

  #### ✨ 신규 기능
  - **레이아웃 킷** (UIUXNC-1771): 콘솔 화면을 셸·페이지·프리미티브 3계층으로 짜는 레이아웃 킷을 먼저 공개 (스타일 엔트리가 함께 배포되지 않아 정식 출시는 1.2.0)
    - **shell**(`@kt-cloud-front/ui-react/shell`) — `SShell`·`SShellHeader`·`SShellLnb`·`SShellBody`·`SShellFooter`: 앱 프레임(GNB·LNB·Footer·거터), 앱에 한 번만 사용
    - **page**(`@kt-cloud-front/ui-react/page`) — `SPageArea`·`SPageMain`·`SPageSide`·`SPageBar`·`SPageBody`: `SShellBody` 안쪽 콘텐츠 배치, 라우트마다 사용
    - **primitives**(`@kt-cloud-front/ui-react/primitives`) — `SBox`·`SCenter`·`SContainer`·`SFlex`·`SGrid`·`SStack`(`SVStack`·`SHStack` 프리셋 포함): 위젯 내부 배치 도구, 어디서나 사용
    - 그룹 단위 서브패스로만 import(최상위 배럴 미노출)
    - ([ae0c7637b](https://github.com/kt-cloud-platform/front/commit/ae0c7637be0dcc62bed7c34b2bde1e5366b2ba99)) @dhoh-ktc
  - **Data Grid 정식 릴리즈** (UIUXNC-1583, `@kt-cloud-front/data-grid`): 내부 전용이던 데이터 그리드(SGrid)를 npm 패키지로 배포
    - ([1642babb7](https://github.com/kt-cloud-platform/front/commit/1642babb7cfdcba9d1f6a766e9caae7503767db3), [7b434f37c](https://github.com/kt-cloud-platform/front/commit/7b434f37ccb3ba9836017d5cbc2c42008992b803), [5d64b6929](https://github.com/kt-cloud-platform/front/commit/5d64b6929b39479b80514b15a4219d9e22856597)) @ktc-stephen-k

  #### 🚀 주요 개선
  - **오버레이 레이어 시스템** (UIUXDS-887): 모달·오버레이 패널이 딤과 콘텐츠를 하나의 스택 레이어로 묶어, 그 안에서 연 `SSelect`·`SDropdownMenu`·`SPopover` 가 항상 그 레이어 위에 렌더되고 밖에 열려 있던 팝업은 딤에 가려짐(`SModal`·`SOverlayPanel`·`SPopover`·`SDropdownMenu`·`SSelect`·`SVerticalNavigationMenu` 전반 적용)
    - ([0d1143cf0](https://github.com/kt-cloud-platform/front/commit/0d1143cf0d4b41318ea05bda2b8f4c9931526ab0)) @ktc-stephen-k
  - **SSelect**: `prefixSlot`(트리거 앞 아이콘 등 삽입) · `isReadOnly`(읽기 전용 상태) · `position`(12방향 드롭다운 위치, 기본 `bottom-start`) · `SSelectContent` `container`(Portal 대상 지정) 추가. 전체 선택 표기 "전체 선택 (N)" → "전체 (N)"
    - ([3aec15c96](https://github.com/kt-cloud-platform/front/commit/3aec15c9631e60f149dbb6c3899817e212a78642), [598d190e2](https://github.com/kt-cloud-platform/front/commit/598d190e2f4fe9e80c907b6ad2aa7af5bf58c071), [f776d6093](https://github.com/kt-cloud-platform/front/commit/f776d609357cc57864199e1a6935b548f3069874), [efca98679](https://github.com/kt-cloud-platform/front/commit/efca98679966693fa6688d0004809d4d2a1e2b53)) @ktc-stephen-k, @so--hyun.kim
  - **SDropdownMenu**: `isDisabled`(기존 `disabled` deprecated) · `SDropdownMenuTriggerButton`/`SDropdownMenuTriggerIconButton`(버튼형 트리거) · `SDropdownMenuContent` `container` 추가
    - ([1069fbacd](https://github.com/kt-cloud-platform/front/commit/1069fbacda4186d0b0e23f0c16bd11bc93fab5a1), [0b34397bb](https://github.com/kt-cloud-platform/front/commit/0b34397bb9e2ad22fd65178b9c4b0514271b5f60)) @ktc-stephen-k
  - **SModal**: `closeOnBackdropClick` 추가 — `false` 면 백드롭 클릭으로 닫히지 않고 명시적 닫기 액션으로만 닫힘
    - ([699a75e46](https://github.com/kt-cloud-platform/front/commit/699a75e4649f5faebadd3bb27dd3e19edce1fe03)) @dhoh-ktc
  - **SOverlayPanel**: `fullAnimation` 추가 — `size="full"` 전환을 `fade`(기본)/`slide` 중 선택
    - ([68fbf12e6](https://github.com/kt-cloud-platform/front/commit/68fbf12e616d1ae9d01e385ae8173b81a12691a5)) @so--hyun.kim
  - **SImage**: `state`(loading/error 강제 지정) · `fallbackSrc`(로드 실패 시 대체 이미지) 추가, 로딩 중 스켈레톤·`aria-busy` 적용
    - ([4c9a2cc9d](https://github.com/kt-cloud-platform/front/commit/4c9a2cc9d95ce8199dc2e36ffe42eab65f4ce238), [89b5687c6](https://github.com/kt-cloud-platform/front/commit/89b5687c65b7563b8bb5545bc2b18dc236981ba9)) @ktc-stephen-k
  - **SInlineNotification**: `open`/`defaultOpen`/`onOpenChange` 추가(controlled, `onDismiss` deprecated) · `Content`/`Title`/`Description` `asChild` 추가(Radix Slot), 닫기 버튼 축소(`SIconButton` xsmall/tertiary)
    - ([4cd00e9a3](https://github.com/kt-cloud-platform/front/commit/4cd00e9a36dcb4a46e5b0770374a47e67ecd036c), [8be768ca5](https://github.com/kt-cloud-platform/front/commit/8be768ca5b475822c1c3d19060c9da0619db3dcb), [592e53873](https://github.com/kt-cloud-platform/front/commit/592e5387376ed019d505ca3fdd2835c77362c060)) @dhoh-ktc
  - **SIconButton**: `size="xsmall"`(18×18px) 추가, `variant="compact"` deprecated(`tertiary` + `xsmall` 로 대체)
    - ([ac299aec3](https://github.com/kt-cloud-platform/front/commit/ac299aec3dee06161de8ebfd8efbb758b2f6e859)) @ktc-stephen-k
  - **SSpinner**: `size="xsmall"`(12×12px) 추가
    - ([caeceb994](https://github.com/kt-cloud-platform/front/commit/caeceb994706c079b94ff592c21de7a3d49b15ca)) @ktc-stephen-k
  - **STabs**: `STabsTrigger` `isDisabled` 추가(기존 `disabled` deprecated), 비활성 탭 스타일 추가
    - ([6ae343222](https://github.com/kt-cloud-platform/front/commit/6ae343222e086c807b3ca2494108fd15aca2830d)) @ktc-stephen-k
  - **STextButton**: `suffixIconVisibility`(`always`/`hover`/`never`) 추가, `static-light` 텍스트·아이콘 색상 및 hover 배경 강조 조정, prefix·suffix 아이콘 크기 정리
    - ([c2d423a09](https://github.com/kt-cloud-platform/front/commit/c2d423a097d58f541d1fbac0a21e96721d9d48bf), [d6fca1e1d](https://github.com/kt-cloud-platform/front/commit/d6fca1e1de440194af198b383db320184a667fa4)) @ktc-stephen-k
  - **SCalendar / SDateRangePicker / SDateTimeRangePicker**: `anchor` 추가(더블 캘린더 기준 판 지정, `end`/`start`), `SCalendar` `focusMonth` 추가, 범위 선택을 미완성 상태로 닫으면 이전 값으로 복원
    - ([d2c07250d](https://github.com/kt-cloud-platform/front/commit/d2c07250d5aec2d9309a1b01c26cd59315bfd602), [69a192488](https://github.com/kt-cloud-platform/front/commit/69a19248857d5701c68d51ce32c9bcf9238847a8), [c49ef9d83](https://github.com/kt-cloud-platform/front/commit/c49ef9d83771f2e8eac267c8787c746fc87f4e68), [f33dae37e](https://github.com/kt-cloud-platform/front/commit/f33dae37e871782b4344211134afa315d0cd4a24)) @Jaehee Song, @nspark
  - **디자인 토큰**: veil hover bold/inverse 투명도, icon accent dark 모드, disabled 불투명도 참조값 수정. `border-width-xl`·`shadow-blur-48`·`elevation-shadow-xl` 신규 추가
    - ([28513b69b](https://github.com/kt-cloud-platform/front/commit/28513b69b30557eb176cf9133ec4fa67f8baab57)) @ktc-stephen-k
  - **Data Grid**: 행 클릭 어포던스 및 상태별 배경 적용, 칼럼 필터를 Figma 스펙에 맞춰 `SPopover` 기반으로 정리
    - ([adec47130](https://github.com/kt-cloud-platform/front/commit/adec471305e5ee34a58c19754fdd4cc371122cf8), [d48266cd7](https://github.com/kt-cloud-platform/front/commit/d48266cd72d042c778f07919b3e1ed6099a033b5)) @ktc-stephen-k

  #### 🐛 버그 수정
  - **Data Grid**: 칼럼 필터 초기 전체선택/전부 해제 시 빈 결과 처리, 필터 0건 안내 및 상태 본문 높이 보정, 상태 전환 시 헤더 언마운트로 필터 드롭다운이 닫히던 문제, 리사이즈 불가 칼럼의 핸들 오버레이 제거, 배경 재조회 실패 시 목록 유지, 그리드 말줄임 1줄 변경 및 검색창 clear 버튼 넘침 수정
    - ([d94fbe3f7](https://github.com/kt-cloud-platform/front/commit/d94fbe3f76d4506adae5f920c824b2df3f05d984), [ac18f0d26](https://github.com/kt-cloud-platform/front/commit/ac18f0d263379313326760a854b22130372a8ba0), [eeb841f73](https://github.com/kt-cloud-platform/front/commit/eeb841f73db85041bebb5202dd2c7abde7b6adb0), [0a9a761f2](https://github.com/kt-cloud-platform/front/commit/0a9a761f2fcb3b36580fde2868c2b85dacb99938), [b98b8abcb](https://github.com/kt-cloud-platform/front/commit/b98b8abcb3392dc2ddc2e1a44ac6fbff835176c0), [17e64b94c](https://github.com/kt-cloud-platform/front/commit/17e64b94c1e955c4a209fda111b5f13b7bef5bf9)) @ktc-stephen-k, @dhoh-ktc, @sjkim-clush
  - **SSearchInput**: `SSelectOptionList` 안에서 검색창 여백이 아래 항목과 어긋나던 문제 수정
    - ([5be4ef23d](https://github.com/kt-cloud-platform/front/commit/5be4ef23d38918cb7ad8da630feede46032508cb)) @ktc-stephen-k
  - **SToast**: z-index 를 KCDS feedback 계층으로 조정 — 모달·드롭다운·팝오버(overlay 계층) 위에 표시
    - ([df8a2a85d](https://github.com/kt-cloud-platform/front/commit/df8a2a85dcbb163fa26e7d32b91a3a16267a7b00)) @ktc-stephen-k
  - **STable**: `STableRow` 선택/활성 상태 배경 재정렬 — 활성(`data-active`)이 선택(`data-state="selected"`)보다 진하게 표시되도록 구분
    - ([adec47130](https://github.com/kt-cloud-platform/front/commit/adec471305e5ee34a58c19754fdd4cc371122cf8)) @ktc-stephen-k
  - **SVerticalNavigationMenu**: 접힘 상태에서 hover 로 뜨는 서브메뉴가 모달·딤을 뚫고 최상단에 그려지던 문제 수정
    - ([0d1143cf0](https://github.com/kt-cloud-platform/front/commit/0d1143cf0d4b41318ea05bda2b8f4c9931526ab0)) @ktc-stephen-k

  #### 📌 참고 (하위호환 유지되는 Deprecated)
  - `SIconButton` `variant="compact"` → `variant="tertiary"` + `size="xsmall"`
  - `SDropdownMenu`/`STabsTrigger` `disabled` → `isDisabled`
  - `SInlineNotification` `onDismiss` → `onOpenChange`
  - 기존 prop은 그대로 동작하며 Breaking Change 는 없습니다

- Updated dependencies
  - @kt-cloud-front/ui-react@1.1.0

## 1.0.8

### Patch Changes

- **버전 동기화**: 배포 인프라상 버전 번호만 1.0.8로 동기화(changeset 미사용, 기능 변경 없음)
  - ([33ad44d4a](https://github.com/kt-cloud-platform/front/commit/33ad44d4af5c68585e42d9535eeb28eda2c691df)) @ktc-stephen-k

## 1.0.7

### Patch Changes

- **패치 릴리즈**: 디자인 시스템 1.0.7 버전 업데이트

  #### ⚠️ Breaking Changes
  - **STimePicker**: Compound 패턴(`Object.assign`) 제거 → Named Export로 전환
    - `STimePicker.TimeSelect` → `STimePickerTimeSelect`
    - `STimePicker.Footer` → `STimePickerFooter`
    - 이유: 트리쉐이킹 및 타입 추론 개선
    - ([4aaa67e6e](https://github.com/kt-cloud-platform/front/commit/4aaa67e6eb0e483d9a344dc8c650a59ac14ea0da)) @Jaehee Song

  - **SDescriptionCell**: `direction` prop이 Cell에서 `SDescriptionListRow`로 이동
    - Before
      ```tsx
      <SDescriptionListRow>
        <SDescriptionCell direction="vertical" label="이름" value="홍길동" />
      </SDescriptionListRow>
      ```
    - After
      ```tsx
      <SDescriptionListRow direction="vertical">
        <SDescriptionCell label="이름" value="홍길동" />
      </SDescriptionListRow>
      ```
    - 이유: Row가 column 수를 결정하므로 `direction`은 Row 레벨 관심사
    - ([2c8cb4dfd](https://github.com/kt-cloud-platform/front/commit/2c8cb4dfd5b3167f146935252b0439899405ae9a)) @ktc-stephen-k

  - **Tailwind 토큰 네임스페이스**: 기본 Tailwind 충돌 방지를 위해 KCDS 토큰에 `kcds-` 접두사 추가
    - 예: `color-primary` → `color-kcds-primary`, `spacing-4` → `spacing-kcds-4`
    - 단, font-size 토큰은 접두사 없이 유지 (`text-14` 등 그대로 사용)
    - `@theme` → `@theme extend`로 변경되어 Tailwind 기본 테마와 공존
    - 영향: 앱 코드에서 커스텀 토큰 클래스 사용부는 `bg-primary` → `bg-kcds-primary` 등으로 교체 필요
    - ([6e071b147](https://github.com/kt-cloud-platform/front/commit/6e071b147971bb9d71ab265760d2beba1cb7438d)) @stephen.k, ([83682a638](https://github.com/kt-cloud-platform/front/commit/83682a638cd5690b2baeca2298606e367fc10a02)) @dhoh-ktc

  #### ✨ 신규 컴포넌트
  - **SPopover** (UIUXDS-859): 클릭 트리거 Popover 신규 추가
    - @radix-ui/react-popover 기반 3계층 아키텍처(`CPopover` → `popover.css` → `SPopover`)
    - 12개 위치 지정(`position` prop), 기본값 `bottom-start`
    - 서브컴포넌트: `SPopoverTrigger`, `SPopoverContent`, `SPopoverHeader`, `SPopoverBody`, `SPopoverFooter`, `SPopoverClose`
    - 예시
      ```tsx
      <SPopover>
        <SPopoverTrigger asChild>
          <button>열기</button>
        </SPopoverTrigger>
        <SPopoverContent position="bottom-start">
          <SPopoverHeader>제목</SPopoverHeader>
          <SPopoverBody>본문</SPopoverBody>
          <SPopoverFooter>
            <SPopoverClose>닫기</SPopoverClose>
          </SPopoverFooter>
        </SPopoverContent>
      </SPopover>
      ```
    - ([e786da787](https://github.com/kt-cloud-platform/front/commit/e786da78756c94fdc9825b0531c5bb698c58b0c7), [97de9be58](https://github.com/kt-cloud-platform/front/commit/97de9be580d2c110a6459dbdcabc362cdd86665f), [b6aea1243](https://github.com/kt-cloud-platform/front/commit/b6aea1243727a8f1002ceb1ac8d6638b85849ef9), [e30d970b5](https://github.com/kt-cloud-platform/front/commit/e30d970b57b4f8ef41500358cf5ae670e71ed062), [57547eab5](https://github.com/kt-cloud-platform/front/commit/57547eab5ff40f459ee1c1a3667e4c9fad72abf1)) @ktc-stephen-k

  - **DateTimePicker 4종** (UIUXNC-800): 날짜/시간 입력 컴포넌트 세트
    - `STimePicker` / `SDatePicker` / `SDateTimePicker` / `SDateRangePicker`
    - SCalendar 기반, context / footer / time-select 공유 모듈로 구성
    - ([fecee7054](https://github.com/kt-cloud-platform/front/commit/fecee70546d0ecc042d03789c42b41202c04c908)) @Jaehee Song
    - 후속 리팩토링 (UIUXNC-874): [bb63800ba](https://github.com/kt-cloud-platform/front/commit/bb63800ba883c9d783025444e45b44be62549b2a) @Jaehee Song

  - **StepWizard**: `future/widgets/step-wizard`에 Stepper/Wizard 위젯 추가
    - 구성: `StepWizardRoot`, `StepWizardStep`, `StepWizardFooter`, `StepWizardPager`, `StepWizardContext`
    - ⚠️ `future/` 경로는 실험적 API — 추후 위치/시그니처 변경 가능
    - ([ed6c447f6](https://github.com/kt-cloud-platform/front/commit/ed6c447f685e83fb5d9362ad770387d581c4ba99)) @dhoh-ktc

  - **KCPIcon**: kt cloud 서비스 전용 아이콘 컴포넌트
    - SUIIcon Props 기반, Tailwind 유틸리티 클래스만 사용 (별도 CSS 없음)
    - 서비스별 SVG 레지스트리 (mono / duotone)
    - LNB 서비스 아이콘에 적용됨
    - ([ed6bcff57](https://github.com/kt-cloud-platform/front/commit/ed6bcff570b7dd2b6213a225bdd33decb13a7fc3)) @ktc-stephen-k

  #### 🚀 주요 개선
  - **SGrid: flex 레이아웃 기반 칼럼 너비 관리로 전환**
    - `table-layout: fixed` → flex 기반으로 전환 (STable `[&_tr]:flex`, STableHead `flex items-center`)
    - 고정 칼럼 (pinned 또는 `minSize === maxSize`): `flex: 0 0 [size]px`
    - 유연 칼럼: `flex: [size] 1 0px` (size 비율 배분)
    - `getColumnSizeStyle`에 `isPinned` 파라미터 추가
    - ([10f45cebc](https://github.com/kt-cloud-platform/front/commit/10f45cebcb55dba97afe9c808a9ce27a22801f71), [f9615ad1d](https://github.com/kt-cloud-platform/front/commit/f9615ad1d40d498689fc950363a0c7d6dfb2e0d0), [00f936fc7](https://github.com/kt-cloud-platform/front/commit/00f936fc702fc939044d5baed8487a8a79ab16f6)) @dhoh-ktc

  - **Tailwind v4 전환** (UIUXNC-878)
    - KCDS 디자인 토큰을 Tailwind v4 `@theme extend` 기반으로 통합
    - 아이콘 크기 정의를 `@apply` 유틸리티 클래스 방식으로 전환
    - `tailwind-builder`: `-default` suffix shorthand alias 자동 생성 (예: `color-kcds-bg-default` → `bg-kcds-bg`)
    - ([8ea5608ab](https://github.com/kt-cloud-platform/front/commit/8ea5608ab43af8f5edfcc4ae939bd46e18c68d93), [a9946fbc6](https://github.com/kt-cloud-platform/front/commit/a9946fbc6f4070188f3a6d96f8476defe7d697a5), [4249d10b3](https://github.com/kt-cloud-platform/front/commit/4249d10b3dc7d15a8ac8606423a5191049ccd80c), [69d17033c](https://github.com/kt-cloud-platform/front/commit/69d17033c43a1fa27600cac0cc1782f19e0d6937)) @dhoh-ktc

  - **SCalendar 선택 기능**: 단일/범위 날짜 선택 props + 콜백 지원 ([d3ff889c4](https://github.com/kt-cloud-platform/front/commit/d3ff889c4a92be7e3960a552557fb13c92ad65ff)) @dhoh-ktc

  - **SDescriptionCell `direction` prop 추가** (UIUXDS-862): 피그마 1Column / 2+Columns 레이아웃 지원, 긴 텍스트 ellipsis 처리 ([c499ef343](https://github.com/kt-cloud-platform/front/commit/c499ef3432af99c10aa4f77214cb23ee1d03434a)) @ktc-stephen-k _(위치 변경 내역은 Breaking Changes 참고)_

  - **STableRow 높이 variant 추가** 및 내부 별칭 누수 문제 처리 (UIUXNC-878) ([ea9278736](https://github.com/kt-cloud-platform/front/commit/ea92787361fa5ad7309f058a854eb888b6b7f5d1)) @dhoh-ktc

  #### 🐛 버그 수정
  - **Input 계열 readOnly 스타일 Figma 일치화** (UIUXDS-852)
    - STextInput / SNumberInput / SPasswordInput: `background-color` 제거, hover/focus 억제
    - STextArea: `background-color` 제거, focus 억제
    - STextInput: readOnly 시 clear 버튼 미표시
    - SSearchInput · SPasswordInput: readOnly 미지원이므로 관련 스타일/스토리 제거
    - ([aedc91f42](https://github.com/kt-cloud-platform/front/commit/aedc91f42e40c18c57bc6baed064fd8ca9a907f8), [b925e4706](https://github.com/kt-cloud-platform/front/commit/b925e4706d105c52b8d7775e82bd403dfa23e57a)) @ktc-stephen-k

  - **SGrid 관련**
    - 행 높이·스켈레톤·액션 칼럼 스타일 개선 ([ab124d14a](https://github.com/kt-cloud-platform/front/commit/ab124d14a8aa7c1694d62bad214dad881c34bdba)) @dhoh-ktc
    - 테이블 행 높이 산정 방식 및 Sticky 헤더 로직 수정 ([035819a4b](https://github.com/kt-cloud-platform/front/commit/035819a4b4d691ecb263881f91e0491a091e5e7b)) @dhoh-ktc
    - state variant 셀 패딩 제거, 에러 상태 전체 너비 중앙 정렬 ([aa1e93992](https://github.com/kt-cloud-platform/front/commit/aa1e9399210577142a0ea615dc80498de5f99bfb)) @dhoh-ktc
    - pinned 셀 hover/selected 배경 동기화 및 transition 제거 ([e1ae735ae](https://github.com/kt-cloud-platform/front/commit/e1ae735ae372411dd166316bdae02a459d3645f7)) @dhoh-ktc
    - 열너비 조정 손잡이 디자인 수정 (UIUXNC-933) ([62b80fa8e](https://github.com/kt-cloud-platform/front/commit/62b80fa8eec1029e6f678759973e1462ede4ea0f)) @dhoh-ktc
    - 로딩(Skeleton) 상태 컬럼 너비 스타일 수정 ([20185f51d](https://github.com/kt-cloud-platform/front/commit/20185f51d69379a4dfd79d428da9e1eb8de588a7)) @dhoh-ktc
    - DataGrid 헤더 정렬 아이콘 크기 수정 (xsmall → xs) ([23fa3a44a](https://github.com/kt-cloud-platform/front/commit/23fa3a44ab232e1ed26be0229be97611059ae7d8)) @ktc-stephen-k

  - **STimePicker z-index 수정**: SModal 위에 팝오버가 표시되도록 `date-time-picker.css`에 z-index 추가 ([4aaa67e6e](https://github.com/kt-cloud-platform/front/commit/4aaa67e6eb0e483d9a344dc8c650a59ac14ea0da)) @Jaehee Song

  - **SAccordion 애니메이션 토큰화**: 300ms → `animation-fast`(200ms) / easeOut, chevron 회전 `interaction-default`(150ms) / easeOut, chevron 크기 `iconSize-md` → `xs`(Figma 일치), 중복 height transition 제거 ([196e8526a](https://github.com/kt-cloud-platform/front/commit/196e8526a8ce1af21824f29c694afb12ba9d9e94)) @ktc-stephen-k

  - **SAccordion 스타일**: 수직 패딩 적용 ([efabbef6c](https://github.com/kt-cloud-platform/front/commit/efabbef6c685c7a7ae61d3b6aab53811cbd629b0)) @dhoh-ktc

  - **SDescriptionList 피그마 디자인 토큰 불일치 수정** ([4418537b0](https://github.com/kt-cloud-platform/front/commit/4418537b006e92922d7a03ed647d1939b65dc967)) @ktc-stephen-k

  - **SIllustration 스타일 버그 수정** ([e6833d82b](https://github.com/kt-cloud-platform/front/commit/e6833d82b5cfe9efce6adbc63fdbfc5304d8245d)) @Jaehee Song

  - **SEmptyStateSubTitle export 누락 수정** ([e37db57ad](https://github.com/kt-cloud-platform/front/commit/e37db57adb020132480c5fde110f98daab8f20be)) @ktc-stephen-k

  - **SVerticalNavigationMenu (LNB) UI/UX 개선** ([08922fa9c](https://github.com/kt-cloud-platform/front/commit/08922fa9c613261952b2c3a4d55886965b6e8d4f)) @so--hyun.kim

  - **GNB 디자인 버그 수정** ([22c9aa779](https://github.com/kt-cloud-platform/front/commit/22c9aa779780ac91107d4375e460d3710fd5ba19)) @Jaehee Song

  - **SimpleTable Body 상단 border-top 추가** (UIUXDS-844) ([b57ed06c8](https://github.com/kt-cloud-platform/front/commit/b57ed06c84b93b9530509043768d3e9c7b7de514)) @ktc-stephen-k

  - **Dialog z-index 및 레이아웃 수정**: DialogContent 레이아웃을 grid → flex로, z-index 조정 ([37f885fce](https://github.com/kt-cloud-platform/front/commit/37f885fce8750338c415fc8ddc3b75e901a86b57), [9643880061](https://github.com/kt-cloud-platform/front/commit/96438800613e5151fee26ae205d5e30f1a3604a7)) @dhoh-ktc

  - **globals.css**: 사이드바 CSS 변수 중복 정의 제거 ([da90a72d7](https://github.com/kt-cloud-platform/front/commit/da90a72d77c362f44ac84aa5f57128b4b4adeb45)) @dhoh-ktc

  #### 🎨 Figma 아이콘 동기화
  - SUIIcon Figma 동기화 ([aec16a9df](https://github.com/kt-cloud-platform/front/commit/aec16a9df8ed948b1ad82724614fe564b88b5ede)) @Jaehee Song
  - 신규 아이콘 7종: bank, receipt, popup, power-restart, storage 계열 ([130849eb1](https://github.com/kt-cloud-platform/front/commit/130849eb14a554755e0c243e785bf72b98ab693e)) @stephen.k
  - 추가 아이콘 6종 ([705b8ee68](https://github.com/kt-cloud-platform/front/commit/705b8ee688feaec58046bd3753160b48569bbbb4)) @ktc-stephen-k

  #### 📦 디펜던시
  - `recharts` 버전 업 ([3738a08aa](https://github.com/kt-cloud-platform/front/commit/3738a08aac882de3188abe3c6834c6a25b6b33b7)) @Siyeop

  #### 🧭 마이그레이션 가이드
  1. **STimePicker** — `STimePicker.TimeSelect` / `STimePicker.Footer` 사용 중이면 named export로 교체

     ```tsx
     // Before
     import { STimePicker } from '@kt-cloud-front/ui-react/TimePicker';
     <STimePicker.TimeSelect />
     <STimePicker.Footer />

     // After
     import { STimePicker, STimePickerTimeSelect, STimePickerFooter } from '@kt-cloud-front/ui-react/TimePicker';
     <STimePickerTimeSelect />
     <STimePickerFooter />
     ```

  2. **SDescriptionCell** — `direction` prop을 상위 `SDescriptionListRow`로 이동

  3. **Tailwind 토큰** — 앱에서 사용 중인 커스텀 토큰 클래스에 `kcds-` 접두사 추가 (font-size 제외)

- Updated dependencies
  - @kt-cloud-front/ui-react@1.0.7

## 1.0.6

### Patch Changes

- **패치 릴리즈**: 디자인 시스템 1.0.6 버전 업데이트

  ### 주요 변경사항
  - refactor(ui-react): Input 컴포넌트 네이밍 일관성 개선 및 deprecated 항목 제거 ([2459d5913](https://github.com/kt-cloud-platform/front/commit/2459d59136a26fb43e4f47aa54207e540f4d0ded)) @ktc-stephen-k
  - fix(ui-react): isDisabled 상태에서 clear 버튼 제거 및 MaskingToggle 네이밍 변경 ([71cb3619e](https://github.com/kt-cloud-platform/front/commit/71cb3619e1ada099b69c89e01f3455bfbb61f390)) @ktc-stephen-k
  - fix(security): EMPTY_CATCH_BLOCK 보안 위반사항 조치 ([b4ee6470f](https://github.com/kt-cloud-platform/front/commit/b4ee6470f487e3dc8df95c3e1eea1e85a1277185)) @ktc-stephen-k
  - fix(ui-react): SVerticalNavigationMenu 컴포넌트 예시 코드 개선 및 불필요 prop 제거 ([f937187a0](https://github.com/kt-cloud-platform/front/commit/f937187a0b41dab81543aaddbee24f4158cbd447)) @ktc-stephen-k

- Updated dependencies
  - @kt-cloud-front/ui-react@1.0.6

## 1.0.5

### Patch Changes

- **패치 릴리즈**: 디자인 시스템 1.0.5 버전 업데이트

  ### 주요 변경사항
  - refactor(ui-style): 빌드 파이프라인 고도화 - index 단일 소스 정리 ([9588e11](https://github.com/kt-cloud-platform/front/commit/9588e11ba5145015d06b4222b3581171f5823db0)) @ktc-stephen-k
  - fix(ui-style): Tailwind v4 KCDS 토큰 통합 및 font-size namespace 충돌 해결 ([d31fb57](https://github.com/kt-cloud-platform/front/commit/d31fb57cd0fbe52e1a96008815a58ea64eaaa34e)) @ktc-stephen-k
  - fix: SVerticalNavigationMenu에서 GlobalNavigation 의존성 제거 ([ff5539b](https://github.com/kt-cloud-platform/front/commit/ff5539be2e97ad9a41aab1c202c2bde5fbe777ae)) @ktc-stephen-k

- Updated dependencies
  - @kt-cloud-front/ui-react@1.0.5

## 1.0.4

### Patch Changes

- **패치 릴리즈**: 디자인 시스템 1.0.4 버전 업데이트

  ### 주요 변경사항
  - fix(ui-style): Tailwind CSS 폰트 경로를 상대 경로로 수정 ([301e6afde](https://github.com/kt-cloud-platform/front/commit/301e6afde12abb99ec1134b38b8145254c83fc25)) @ktc-stephen-k

- Updated dependencies
  - @kt-cloud-front/ui-react@1.0.4

## 1.0.3

### Patch Changes

- **패치 릴리즈**: 디자인 시스템 1.0.3 버전 업데이트

  ### 주요 변경사항
  - feat(ui-style): Tailwind CSS v4 @theme 블록 생성 및 독립 빌드 구조 개선 ([7019531](https://github.com/kt-cloud-platform/front/commit/701953182098dddc2042dd3331040f98792e8ce1)) @ktc-stephen-k
  - feat(SEmptyState): SubTitle 추가 및 Figma 스펙 동기화 ([f38dfc5](https://github.com/kt-cloud-platform/front/commit/f38dfc5c79df5f5ea2a1ce6d53c3bc217f3fc393)) @ktc-stephen-k
  - feat: Figma 아이콘 동기화 - clock, envelope, phone 추가 ([f9d2f4a](https://github.com/kt-cloud-platform/front/commit/f9d2f4ac23573da3428049a4f6c843ac7b76bc85)) @ktc-stephen-k
  - fix(ui): SSelect size prop을 Figma 디자인과 일치하도록 수정 ([1efedbaf](https://github.com/kt-cloud-platform/front/commit/1efedbaf1915f9690697ce00d67180741b280281)) @ktc-stephen-k
  - fix(ui): SPagination의 SSelect size prop 수정 ([a02312f](https://github.com/kt-cloud-platform/front/commit/a02312fadad76f68d31f30d0e01de3c6aa60ec23)) @ktc-stephen-k
  - fix(ui-common): Vite 빌드로 전환하여 ESM 확장자 문제 해결 ([e49fee4](https://github.com/kt-cloud-platform/front/commit/e49fee404ebbf42713d5d4a426ec785ca6050953)) @ktc-stephen-k
  - fix(ui-style): CSS/SCSS import 경로 변환 버그 수정 ([c1ca02d](https://github.com/kt-cloud-platform/front/commit/c1ca02de237552c29b605ce1584196bab0d41a7f)) @ktc-stephen-k
  - style: SSelectOptionListItem 선택 표시 방식 변경 - 체크 아이콘에서 배경색으로 ([1e54361](https://github.com/kt-cloud-platform/front/commit/1e54361987ebb1337f1b5cae76796a1065142b5a)) @ktc-stephen-k

- Updated dependencies
  - @kt-cloud-front/ui-react@1.0.3

## 1.0.2

### Patch Changes

- **패치 릴리즈**: 디자인 시스템 1.0.2 버전 업데이트

  ### 주요 변경사항
  - feat: SSelectOptionList 검색어 하이라이트 기능 추가 (064a32d)
  - feat: SSelect 검색 기능 추가 (95e4cb2)
  - fix: SInlineNotification 스토리북 예시 css 수정 (75b9432)
  - fix: SModal 내부 z-index css 수정 (5352a31)
  - fix: SVerticalNavigationMenu 내부 로고 이미지 깨짐 버그 수정 (d70378e)

- Updated dependencies
  - @kt-cloud-front/ui-react@1.0.2

## 1.0.1

### Patch Changes

- **패치 릴리즈**: 디자인 시스템 1.0.1 버전 업데이트

  ### 주요 변경사항
  - CSS 변수 fallback 원시값 및 주석 원시값 제거
  - 타입 체크 설정 정리 및 개선
  - 컴포넌트 버그 수정 및 개선
  - 접근성 개선

- Updated dependencies
  - @kt-cloud-front/ui-react@1.0.1

## 1.0.0

### Major Changes

- **정식 릴리즈**: 디자인 시스템 1.0.0 정식 버전 출시

### Patch Changes

- Updated dependencies
  - @kt-cloud-front/ui-react@1.0.0
